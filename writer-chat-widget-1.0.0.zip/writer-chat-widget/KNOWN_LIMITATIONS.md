# Known Limitations

1. The included syntax highlighter is deliberately small and dependency-free. It provides lightweight highlighting for common JavaScript, TypeScript, JSON, CSS, HTML/XML, shell, SQL, and Python tokens rather than a full language grammar.
2. Very long conversations are paginated and DOM updates are batched, but full viewport virtualization is left as an adapter/integration optimization if transcripts regularly exceed several hundred rendered messages.
3. Attachments are architecture-complete and demonstrated by the mock adapter. Production file policy, storage, malware scanning, signed URLs, and previews belong in the host adapter.
4. Response branches are represented as separate linear threads and response alternatives as variants. The component intentionally does not render a visual conversation tree.
5. The demo mock adapter stores canonical records in memory. Refreshing the demo resets them.
6. The package does not include a Supabase adapter because provider authentication, authorization, schema policy, Edge Function behavior, and deployment details are host-specific.
7. Native browser spellcheck behavior varies by browser and operating system.
