# Adapter Integration Guide

`WriterChatWidget` never talks directly to Supabase, OpenRouter, Gemini, or another provider. A host adapter translates the widget’s generic contracts into the host’s authentication, database, and provider APIs.

## Required methods

```ts
interface WriterChatAdapter {
  listThreads(input): Promise<Paginated<ChatThread>>;
  createThread(input): Promise<ChatThread>;
  updateThread(id, patch): Promise<ChatThread>;
  deleteThread(id): Promise<void>;
  listMessages(input): Promise<Paginated<ChatMessage>>;
  sendMessage(input, { signal }): AsyncIterable<ChatStreamEvent>;
}
```

Optional methods activate corresponding UI capabilities:

```ts
duplicateThread(id, options?)
editMessage(input)
regenerateMessage(input, { signal })
saveMessageExternally(input)
saveConversationExternally(input)
listModels(input?)
submitFeedback(input)
uploadAttachment(file, { signal, onProgress })
deleteMessage(input)
getCapabilities()
```

See `types/writer-chat-widget.d.ts` for complete types.

## Stream contract

A normal stream emits:

```text
start → zero or more delta events → optional usage → complete
```

Cancellation should emit `stopped` when practical or throw an `AbortError`. A partial network failure should emit `error` with `partialMessage` so generated text survives.

Every event must use one opaque request ID. Every delta must identify one assistant message ID. The adapter should return the canonical persisted assistant message on completion whenever possible.

## Supabase Writer mapping

Suggested thread mapping:

```text
writer_ai_chat_threads.id          → ChatThread.id
writer_ai_chat_threads.story_id    → ChatThread.scopeId
writer_ai_chat_threads.title       → ChatThread.title
writer_ai_chat_threads.model_id    → ChatThread.modelId
writer_ai_chat_threads.settings    → ChatThread.settings
writer_ai_chat_threads.created_at  → ChatThread.createdAt
writer_ai_chat_threads.updated_at  → ChatThread.updatedAt
```

Suggested message mapping:

```text
writer_ai_chat_messages.id          → ChatMessage.id
writer_ai_chat_messages.thread_id   → ChatMessage.threadId
writer_ai_chat_messages.role        → ChatMessage.role
writer_ai_chat_messages.content     → ChatMessage.content
writer_ai_chat_messages.sequence    → ChatMessage.sequence
writer_ai_chat_messages.model_id    → ChatMessage.modelId
writer_ai_chat_messages.metadata    → ChatMessage.metadata
writer_ai_chat_messages.created_at  → ChatMessage.createdAt
```

Translate external role names into canonical `system`, `user`, `assistant`, `tool`, or `notice`. Do not store `ai` as the canonical role.

## Error normalization

Return or throw errors shaped as:

```ts
{
  code: string;
  message: string;
  retryable: boolean;
  status?: number;
  details?: unknown;
}
```

Recommended codes include `authentication_expired`, `permission_denied`, `provider_key_not_configured`, `model_unavailable`, `model_access_denied`, `rate_limited`, `quota_exceeded`, `region_unavailable`, `request_too_large`, `context_length_exceeded`, `network_offline`, `network_timeout`, `stream_interrupted`, `persistence_failed`, `invalid_provider_response`, and `unknown_server_error`.

## Persistence failure after successful generation

When provider streaming succeeds but database persistence fails, complete the stream with the response content and set:

```js
message.metadata.persistenceFailed = true;
```

The widget displays the response as unsaved and exposes a retry-save action when `saveMessageExternally` is available.

## Capability negotiation

`configure({ capabilities })` supplies host defaults. `adapter.getCapabilities()` may refine them. Unsupported controls are hidden or disabled instead of calling absent methods.

## Privacy

Adapter methods receive message content only for explicit user sends and save actions. Widget analytics events omit message content. Provider credentials must remain entirely inside the host adapter or backend.
