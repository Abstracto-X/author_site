export type ChatRole = 'system' | 'user' | 'assistant' | 'tool' | 'notice';
export type ChatMessageStatus = 'pending' | 'sending' | 'streaming' | 'complete' | 'stopped' | 'failed' | 'edited' | 'superseded';

export interface ChatScope {
  id: string;
  type: 'story' | 'project' | 'workspace' | string;
  title?: string;
  surface?: string;
  activeEntityId?: string | null;
}

export interface ChatCapabilities {
  streaming: boolean;
  stop: boolean;
  threadSearch: boolean;
  threadRename: boolean;
  threadDelete: boolean;
  threadArchive: boolean;
  threadPin: boolean;
  threadDuplicate: boolean;
  editMessage: boolean;
  regenerate: boolean;
  branching: boolean;
  responseVariants: boolean;
  messageCopy: boolean;
  conversationExport: boolean;
  scratchpadSave: boolean;
  messageFeedback: boolean;
  attachments: boolean;
  images: boolean;
  tools: boolean;
  modelCatalog: boolean;
  advancedSettings: boolean;
}

export interface ChatThreadSettings {
  temperature?: number;
  maxTokens?: number;
  systemInstruction?: string;
  [key: string]: unknown;
}

export interface ChatThread {
  id: string;
  scopeId: string;
  title: string;
  modelId: string;
  settings: ChatThreadSettings;
  createdAt: string;
  updatedAt: string;
  pinned?: boolean;
  archivedAt?: string | null;
  parentThreadId?: string | null;
  branchFromMessageId?: string | null;
  streaming?: boolean;
  unreadCount?: number;
  metadata?: Record<string, unknown>;
}

export interface ChatUsage {
  inputTokens?: number;
  outputTokens?: number;
  totalTokens?: number;
  cost?: number;
  currency?: string;
}

export interface ChatError {
  code: string;
  message: string;
  retryable: boolean;
  status?: number;
  details?: unknown;
}

export type ChatContentPart =
  | { type: 'text'; text: string }
  | { type: 'code'; code: string; language?: string }
  | { type: 'image'; url: string; alt?: string }
  | { type: 'file'; id: string; name: string; size?: number }
  | { type: 'notice'; text: string; severity?: string }
  | { type: 'tool-status'; name: string; status: string };

export interface ChatAttachment {
  id: string;
  name: string;
  size?: number;
  type?: string;
  url?: string;
  [key: string]: unknown;
}

export interface ChatMessage {
  id: string;
  clientId?: string;
  threadId: string;
  role: ChatRole;
  content: string;
  parts?: ChatContentPart[];
  sequence: number;
  status: ChatMessageStatus;
  modelId?: string | null;
  createdAt: string;
  editedAt?: string | null;
  parentMessageId?: string | null;
  variantGroupId?: string | null;
  variantIndex?: number;
  variantCount?: number;
  error?: ChatError | null;
  usage?: ChatUsage | null;
  metadata?: Record<string, unknown>;
}

export interface ChatModel {
  id: string;
  name: string;
  provider?: string;
  description?: string;
  contextWindow?: number;
  free?: boolean;
  available?: boolean;
  modalities?: string[];
  favourite?: boolean;
  recent?: boolean;
  metadata?: Record<string, unknown>;
}

export interface Paginated<T> {
  items: T[];
  nextCursor?: string | null;
}

export type ChatStreamEvent =
  | { type: 'start'; requestId: string; message: ChatMessage }
  | { type: 'delta'; requestId: string; messageId: string; text: string }
  | { type: 'usage'; requestId: string; usage: ChatUsage }
  | { type: 'complete'; requestId: string; message: ChatMessage }
  | { type: 'stopped'; requestId: string; message: ChatMessage }
  | { type: 'error'; requestId: string; error: ChatError; partialMessage?: ChatMessage };

export interface WriterChatAdapter {
  getCapabilities?(): Promise<Partial<ChatCapabilities>>;
  listThreads(input: {
    scope: ChatScope;
    scopeId: string;
    query?: string;
    archived?: boolean;
    cursor?: string;
    limit?: number;
    signal?: AbortSignal;
  }): Promise<Paginated<ChatThread> | ChatThread[]>;
  createThread(input: {
    scope: ChatScope;
    scopeId: string;
    title: string;
    modelId: string;
    settings: ChatThreadSettings;
  }): Promise<ChatThread>;
  updateThread(id: string, patch: Partial<ChatThread>): Promise<ChatThread>;
  deleteThread(id: string): Promise<void>;
  duplicateThread?(id: string, options?: { branchFromMessageId?: string }): Promise<ChatThread>;
  listMessages(input: {
    scopeId: string;
    threadId: string;
    cursor?: string;
    limit?: number;
    signal?: AbortSignal;
  }): Promise<Paginated<ChatMessage> | ChatMessage[]>;
  sendMessage(input: {
    scope: ChatScope;
    scopeId: string;
    threadId: string;
    content: string;
    clientId: string;
    modelId: string;
    settings: ChatThreadSettings;
    attachments: ChatAttachment[];
    retryOfMessageId?: string | null;
    branchFromMessageId?: string | null;
  }, options: { signal: AbortSignal }): AsyncIterable<ChatStreamEvent>;
  editMessage?(input: {
    scope: ChatScope;
    scopeId: string;
    threadId: string;
    messageId: string;
    content?: string | null;
    mode: 'replace' | 'branch';
  }): Promise<{ thread?: ChatThread; message?: ChatMessage; messages?: ChatMessage[]; branchCreated?: boolean }>;
  regenerateMessage?(input: {
    scope: ChatScope;
    scopeId: string;
    threadId: string;
    messageId: string;
    content: string;
    modelId: string;
    settings: ChatThreadSettings;
    variantGroupId: string;
    variantIndex: number;
    retry?: boolean;
  }, options: { signal: AbortSignal }): AsyncIterable<ChatStreamEvent>;
  saveMessageExternally?(input: Record<string, unknown>): Promise<void>;
  saveConversationExternally?(input: Record<string, unknown>): Promise<void>;
  listModels?(input?: { scope?: ChatScope }): Promise<Paginated<ChatModel> | ChatModel[]>;
  submitFeedback?(input: { scopeId: string; threadId: string; messageId: string; rating: 'up' | 'down' }): Promise<void>;
  uploadAttachment?(file: File, options: { signal: AbortSignal; onProgress?: (progress: number) => void }): Promise<ChatAttachment>;
  deleteMessage?(input: { threadId: string; messageId: string }): Promise<void>;
}

export interface WriterChatConfiguration {
  adapter?: WriterChatAdapter;
  scope?: ChatScope;
  capabilities?: Partial<ChatCapabilities>;
  userId?: string;
  instanceId?: string;
  theme?: 'dark' | 'light';
  placement?: 'left' | 'right';
  contextAction?: boolean;
}

export interface WriterChatState {
  version: string;
  open: boolean;
  minimized: boolean;
  maximized: boolean;
  placement: 'left' | 'right';
  width: number;
  theme: 'dark' | 'light';
  railVisible: boolean;
  scope: ChatScope;
  activeThreadId: string | null;
  threadCount: number;
  streamingThreadIds: string[];
  pendingWork: boolean;
}

export declare class WriterChatWidget extends HTMLElement {
  configure(configuration?: WriterChatConfiguration): Promise<void>;
  open(): void;
  close(): void;
  toggle(): void;
  minimize(): void;
  maximize(): void;
  restore(): void;
  focusComposer(): void;
  setScope(scope: ChatScope): Promise<void>;
  setDraft(text: string, options?: { mode?: 'replace' | 'append'; send?: false }): void;
  hasPendingWork(): boolean;
  getState(): WriterChatState;
  destroy(): void;
  send(options?: { content?: string; threadId?: string }): Promise<void>;
  loadThreads(options?: { append?: boolean }): Promise<void>;
  loadModels(): Promise<void>;
}

export declare const DEFAULT_CAPABILITIES: Readonly<ChatCapabilities>;
export declare const VERSION: string;
export declare const WIDGET_CSS: string;
export declare function createId(prefix?: string): string;
export declare function escapeHtml(value?: unknown): string;
export declare function safeUrl(value?: string): string | null;
export declare function markdownToHtml(markdown?: string): string;

declare global {
  interface HTMLElementTagNameMap {
    'writer-chat-widget': WriterChatWidget;
  }
}
