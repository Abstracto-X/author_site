import { copyFile, readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const src = path.join(root, 'src', 'writer-chat-widget.js');
const dist = path.join(root, 'dist', 'writer-chat-widget.js');
await copyFile(src, dist);
const code = await readFile(src, 'utf8');
const match = code.match(/const WIDGET_CSS = String\.raw`([\s\S]*?)`;\n/);
if (!match) throw new Error('Unable to extract embedded stylesheet.');
await writeFile(path.join(root, 'dist', 'writer-chat-widget.css'), match[1]);
console.log('Built dist/writer-chat-widget.js and dist/writer-chat-widget.css');
