# Third-Party Dependency and License Inventory

## Runtime

No third-party runtime dependencies are included. The widget uses browser-native Web Components, Shadow DOM, CSS, JavaScript modules, async iterables, `AbortController`, and inline SVG icons authored for this package.

## Development and tests

No npm development dependencies are required by the supplied build or test scripts. Browser tests use an installed Chromium executable when available.

## Package license

The package source is provided under the MIT License in `LICENSE`.
