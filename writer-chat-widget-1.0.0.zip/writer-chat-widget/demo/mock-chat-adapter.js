const wait = (ms, signal) => new Promise((resolve, reject) => {
  if (signal?.aborted) { reject(new DOMException('Aborted', 'AbortError')); return; }
  const timer = setTimeout(resolve, ms);
  signal?.addEventListener('abort', () => {
    clearTimeout(timer);
    reject(new DOMException('Aborted', 'AbortError'));
  }, { once: true });
});

const id = prefix => `${prefix}-${crypto.randomUUID()}`;
const now = () => new Date().toISOString();
const clone = value => structuredClone(value);

export class MockWriterChatAdapter extends EventTarget {
  constructor() {
    super();
    this.threads = new Map();
    this.messages = new Map();
    this.simulation = {
      latency: 28,
      failure: 'none',
      offline: false,
      emptyModels: false,
      persistenceFailure: false
    };
    this.seed();
  }

  seed() {
    const scopeId = 'story-demo';
    const thread = {
      id: 'thread-welcome', scopeId, title: 'Welcome to Writer AI', modelId: 'mock/quick-pen',
      settings: { temperature: 0.7, maxTokens: 2048, systemInstruction: '' },
      createdAt: new Date(Date.now() - 86_400_000).toISOString(), updatedAt: new Date(Date.now() - 3_600_000).toISOString(),
      pinned: true, archivedAt: null, unreadCount: 0, metadata: {}
    };
    this.threads.set(thread.id, thread);
    this.messages.set(thread.id, [
      {
        id: 'welcome-user', threadId: thread.id, role: 'user', content: 'Show me what this standalone widget can render.', sequence: 1,
        status: 'complete', modelId: thread.modelId, createdAt: new Date(Date.now() - 3_700_000).toISOString()
      },
      {
        id: 'welcome-assistant', threadId: thread.id, role: 'assistant', sequence: 2, status: 'complete', modelId: thread.modelId,
        createdAt: new Date(Date.now() - 3_600_000).toISOString(),
        content: `## A compact tour\n\nThis demo supports **safe Markdown**, tables, code, streaming, thread management, variants, and scope isolation.\n\n| Feature | Status |\n|---|---|\n| Background streams | Ready |\n| Per-thread drafts | Ready |\n| Unsafe links | Blocked |\n\n\`\`\`javascript\nconst widget = document.querySelector('writer-chat-widget');\nwidget.open();\nwidget.setDraft('Review this scene', { mode: 'replace' });\n\`\`\`\n\n> Context is inserted only after an explicit host action.`
      }
    ]);
  }

  setSimulation(patch) {
    Object.assign(this.simulation, patch);
    this.dispatchEvent(new CustomEvent('simulation-change', { detail: clone(this.simulation) }));
  }

  async getCapabilities() {
    return {
      streaming: true, stop: true, threadSearch: true, threadRename: true, threadDelete: true,
      threadArchive: true, threadPin: true, threadDuplicate: true, editMessage: true, regenerate: true,
      branching: true, responseVariants: true, messageCopy: true, conversationExport: true,
      scratchpadSave: true, messageFeedback: true, attachments: true, images: false, tools: false,
      modelCatalog: true, advancedSettings: true
    };
  }

  async listThreads({ scopeId, query = '', archived = false, cursor, limit = 50 }) {
    await this.guard();
    const normalized = query.toLowerCase();
    const all = [...this.threads.values()]
      .filter(thread => thread.scopeId === scopeId)
      .filter(thread => archived ? Boolean(thread.archivedAt) : !thread.archivedAt)
      .filter(thread => !normalized || `${thread.title} ${thread.modelId}`.toLowerCase().includes(normalized))
      .sort((a, b) => Number(Boolean(b.pinned)) - Number(Boolean(a.pinned)) || new Date(b.updatedAt) - new Date(a.updatedAt));
    const start = cursor ? Number(cursor) : 0;
    const items = all.slice(start, start + limit).map(clone);
    return { items, nextCursor: start + limit < all.length ? String(start + limit) : null };
  }

  async createThread({ scopeId, title, modelId = 'auto', settings = {} }) {
    await this.guard();
    const thread = {
      id: id('thread'), scopeId, title: title || 'New chat', modelId,
      settings: { temperature: 0.7, maxTokens: 2048, systemInstruction: '', ...settings },
      createdAt: now(), updatedAt: now(), pinned: false, archivedAt: null, unreadCount: 0, metadata: {}
    };
    this.threads.set(thread.id, thread);
    this.messages.set(thread.id, []);
    return clone(thread);
  }

  async updateThread(threadId, patch) {
    await this.guard();
    const current = this.requireThread(threadId);
    const next = { ...current, ...clone(patch), updatedAt: now() };
    this.threads.set(threadId, next);
    return clone(next);
  }

  async deleteThread(threadId) {
    await this.guard();
    this.requireThread(threadId);
    this.threads.delete(threadId);
    this.messages.delete(threadId);
  }

  async duplicateThread(threadId, options = {}) {
    await this.guard();
    const source = this.requireThread(threadId);
    const thread = {
      ...clone(source), id: id('thread'), title: `${source.title} copy`, createdAt: now(), updatedAt: now(),
      parentThreadId: source.id, branchFromMessageId: options.branchFromMessageId || null, pinned: false, archivedAt: null
    };
    const sourceMessages = this.messages.get(threadId) || [];
    const boundary = options.branchFromMessageId ? sourceMessages.find(message => message.id === options.branchFromMessageId)?.sequence : Infinity;
    const copied = sourceMessages.filter(message => (message.sequence || 0) <= (boundary ?? Infinity)).map((message, index) => ({
      ...clone(message), id: id('message'), threadId: thread.id, sequence: index + 1, createdAt: message.createdAt
    }));
    this.threads.set(thread.id, thread);
    this.messages.set(thread.id, copied);
    return clone(thread);
  }

  async listMessages({ threadId, limit = 100 }) {
    await this.guard();
    this.requireThread(threadId);
    const items = (this.messages.get(threadId) || []).slice(-limit).map(clone);
    return { items, nextCursor: null };
  }

  async *sendMessage(input, { signal }) {
    const { threadId, content, clientId, modelId } = input;
    this.requireThread(threadId);
    await this.guard(signal);
    const list = this.messages.get(threadId) || [];
    const sequence = list.reduce((max, message) => Math.max(max, message.sequence || 0), 0);
    const user = {
      id: id('message'), clientId, threadId, role: 'user', content, sequence: sequence + 1,
      status: 'complete', modelId, createdAt: now(), metadata: {}
    };
    const assistant = {
      id: id('message'), threadId, role: 'assistant', content: '', sequence: sequence + 2,
      status: 'streaming', modelId, createdAt: now(), parentMessageId: user.id, metadata: {}
    };
    list.push(user, assistant);
    this.messages.set(threadId, list);
    this.touch(threadId);
    const requestId = id('request');
    yield { type: 'start', requestId, message: clone(assistant) };

    const response = this.responseFor(content, input);
    const chunks = response.match(/.{1,18}(?:\s|$)|.{1,18}/gs) || [response];
    let emitted = '';
    try {
      for (let index = 0; index < chunks.length; index += 1) {
        await wait(this.simulation.latency, signal);
        if (this.simulation.failure === 'stream' && index === Math.max(2, Math.floor(chunks.length / 3))) {
          const error = this.errorFor('stream');
          assistant.content = emitted;
          assistant.status = 'failed';
          assistant.error = error;
          yield { type: 'error', requestId, error, partialMessage: clone(assistant) };
          return;
        }
        emitted += chunks[index];
        assistant.content = emitted;
        yield { type: 'delta', requestId, messageId: assistant.id, text: chunks[index] };
      }
    } catch (error) {
      if (error.name !== 'AbortError') throw error;
      assistant.content = emitted;
      assistant.status = 'stopped';
      yield { type: 'stopped', requestId, message: clone(assistant) };
      return;
    }

    assistant.status = 'complete';
    assistant.usage = {
      inputTokens: Math.ceil(content.length / 4), outputTokens: Math.ceil(response.length / 4),
      totalTokens: Math.ceil((content.length + response.length) / 4), cost: 0, currency: 'USD'
    };
    if (this.simulation.failure === 'persistence' || this.simulation.persistenceFailure) assistant.metadata.persistenceFailed = true;
    yield { type: 'usage', requestId, usage: clone(assistant.usage) };
    yield { type: 'complete', requestId, message: clone(assistant) };
  }

  async *regenerateMessage(input, { signal }) {
    this.requireThread(input.threadId);
    await this.guard(signal);
    const list = this.messages.get(input.threadId) || [];
    const source = list.find(message => message.id === input.messageId);
    const user = [...list].reverse().find(message => message.role === 'user' && (message.sequence || 0) < (source?.sequence || Infinity));
    if (!source || !user) throw this.errorFor('invalid');
    const groupId = input.variantGroupId || source.variantGroupId || id('variant');
    source.variantGroupId = groupId;
    source.variantIndex ||= 1;
    const siblings = list.filter(message => message.variantGroupId === groupId);
    const variantIndex = input.variantIndex || siblings.length + 1;
    for (const sibling of siblings) sibling.variantCount = variantIndex;
    source.variantCount = variantIndex;
    const assistant = {
      id: id('message'), threadId: input.threadId, role: 'assistant', content: '',
      sequence: (source.sequence || list.length + 1) + variantIndex / 1000, status: 'streaming', modelId: input.modelId,
      createdAt: now(), parentMessageId: user.id, variantGroupId: groupId, variantIndex, variantCount: variantIndex, metadata: {}
    };
    list.push(assistant);
    list.sort((a, b) => (a.sequence || 0) - (b.sequence || 0));
    const requestId = id('request');
    yield { type: 'start', requestId, message: clone(assistant) };
    const response = `### Alternate response ${variantIndex}\n\n${this.responseFor(user.content, input)}\n\n_This is a separately preserved response variant._`;
    const chunks = response.match(/.{1,20}(?:\s|$)|.{1,20}/gs) || [response];
    let emitted = '';
    try {
      for (const chunk of chunks) {
        await wait(this.simulation.latency, signal);
        emitted += chunk;
        assistant.content = emitted;
        yield { type: 'delta', requestId, messageId: assistant.id, text: chunk };
      }
    } catch (error) {
      if (error.name !== 'AbortError') throw error;
      assistant.status = 'stopped';
      yield { type: 'stopped', requestId, message: clone(assistant) };
      return;
    }
    assistant.status = 'complete';
    yield { type: 'complete', requestId, message: clone(assistant) };
  }

  async editMessage({ threadId, messageId, content, mode }) {
    await this.guard();
    const sourceThread = this.requireThread(threadId);
    const sourceMessages = this.messages.get(threadId) || [];
    const source = sourceMessages.find(message => message.id === messageId);
    if (!source) throw this.errorFor('invalid');
    if (mode === 'replace') {
      source.content = content;
      source.editedAt = now();
      this.touch(threadId);
      return { message: clone(source), messages: clone(sourceMessages) };
    }
    const thread = {
      ...clone(sourceThread), id: id('thread'), title: `${sourceThread.title} branch`, createdAt: now(), updatedAt: now(),
      parentThreadId: sourceThread.id, branchFromMessageId: messageId, pinned: false, archivedAt: null
    };
    const copied = sourceMessages.filter(message => (message.sequence || 0) < (source.sequence || 0)).map((message, index) => ({
      ...clone(message), id: id('message'), threadId: thread.id, sequence: index + 1
    }));
    this.threads.set(thread.id, thread);
    this.messages.set(thread.id, copied);
    return { thread: clone(thread), messages: clone(copied), branchCreated: true, requiresSend: Boolean(content) };
  }

  async saveMessageExternally(input) {
    await this.guard();
    this.dispatchEvent(new CustomEvent('scratchpad-save', { detail: { kind: 'message', input: clone(input) } }));
  }

  async saveConversationExternally(input) {
    await this.guard();
    this.dispatchEvent(new CustomEvent('scratchpad-save', { detail: { kind: 'conversation', input: clone(input) } }));
  }

  async submitFeedback(input) {
    await this.guard();
    this.dispatchEvent(new CustomEvent('feedback', { detail: clone(input) }));
  }

  async listModels() {
    await this.guard();
    if (this.simulation.emptyModels) return [];
    return [
      { id: 'mock/quick-pen', name: 'Quick Pen', provider: 'Mock Foundry', contextWindow: 32_000, free: true, available: true, modalities: ['text'] },
      { id: 'mock/deep-draft', name: 'Deep Draft', provider: 'Mock Foundry', contextWindow: 128_000, free: false, available: true, modalities: ['text'] },
      { id: 'local/quiet-quill', name: 'Quiet Quill', provider: 'Local', contextWindow: 16_000, free: true, available: true, modalities: ['text'] }
    ];
  }

  async uploadAttachment(file, { signal, onProgress } = {}) {
    await this.guard(signal);
    for (const progress of [20, 45, 70, 100]) {
      await wait(35, signal);
      onProgress?.(progress);
    }
    return { id: id('attachment'), name: file.name, size: file.size, type: file.type };
  }

  responseFor(content, input) {
    const compact = content.replace(/\s+/g, ' ').trim();
    return `I received your request in the **${input.scope?.title || input.scopeId}** scope.\n\nHere is a safe streaming response for:\n\n> ${compact}\n\n- The thread remains isolated by scope and thread ID.\n- Switching conversations will not redirect this response.\n- Markdown is escaped before rendering.\n\n\`\`\`text\nscopeId: ${input.scopeId}\nthreadId: ${input.threadId}\nmodel: ${input.modelId}\n\`\`\`\n\nYou can stop this response, regenerate it, branch from it, or save it through the mock Scratchpad callback.`;
  }

  async guard(signal) {
    if (signal?.aborted) throw new DOMException('Aborted', 'AbortError');
    if (this.simulation.offline || this.simulation.failure === 'offline') throw this.errorFor('offline');
    if (this.simulation.failure !== 'none' && !['stream', 'persistence', 'offline'].includes(this.simulation.failure)) throw this.errorFor(this.simulation.failure);
  }

  errorFor(kind) {
    const errors = {
      auth: { code: 'authentication_expired', message: 'Your demo authentication has expired.', retryable: false, status: 401 },
      rate: { code: 'rate_limited', message: 'The mock provider is rate limited. Retry after changing the simulation.', retryable: true, status: 429 },
      timeout: { code: 'network_timeout', message: 'The mock request timed out.', retryable: true, status: 504 },
      offline: { code: 'network_offline', message: 'The mock adapter is offline.', retryable: true },
      provider: { code: 'model_unavailable', message: 'The selected mock model is unavailable.', retryable: true },
      stream: { code: 'stream_interrupted', message: 'The mock stream was interrupted after a partial response.', retryable: true },
      invalid: { code: 'invalid_provider_response', message: 'The mock adapter could not resolve the requested message.', retryable: false }
    };
    return clone(errors[kind] || errors.invalid);
  }

  requireThread(threadId) {
    const thread = this.threads.get(threadId);
    if (!thread) throw this.errorFor('invalid');
    return thread;
  }

  touch(threadId) {
    const thread = this.requireThread(threadId);
    thread.updatedAt = now();
  }
}
