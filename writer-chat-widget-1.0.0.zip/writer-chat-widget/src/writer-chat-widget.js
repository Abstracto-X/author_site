const VERSION = '1.0.0';

export const DEFAULT_CAPABILITIES = Object.freeze({
  streaming: true,
  stop: true,
  threadSearch: true,
  threadRename: true,
  threadDelete: true,
  threadArchive: true,
  threadPin: true,
  threadDuplicate: true,
  editMessage: true,
  regenerate: true,
  branching: true,
  responseVariants: true,
  messageCopy: true,
  conversationExport: true,
  scratchpadSave: true,
  messageFeedback: true,
  attachments: false,
  images: false,
  tools: false,
  modelCatalog: true,
  advancedSettings: true
});

const DEFAULT_SETTINGS = Object.freeze({
  temperature: 0.7,
  maxTokens: 2048,
  systemInstruction: ''
});

const DEFAULT_STATE = Object.freeze({
  open: false,
  minimized: false,
  maximized: false,
  railVisible: true,
  width: 760,
  placement: 'right',
  theme: 'dark',
  archivedVisible: false
});

const UNSAFE_PROTOCOL = /^(?:javascript|vbscript|data\s*:\s*text\/html)/i;
const EXTERNAL_PROTOCOL = /^(?:https?:|mailto:|tel:)/i;

export function createId(prefix = 'id') {
  if (globalThis.crypto?.randomUUID) return `${prefix}-${globalThis.crypto.randomUUID()}`;
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

export function escapeHtml(value = '') {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

export function safeUrl(value = '') {
  const raw = String(value).trim();
  if (!raw || UNSAFE_PROTOCOL.test(raw)) return null;
  if (raw.startsWith('#') || raw.startsWith('/') || raw.startsWith('./') || raw.startsWith('../')) return raw;
  if (EXTERNAL_PROTOCOL.test(raw)) return raw;
  try {
    const parsed = new URL(raw, globalThis.location?.href || 'https://example.invalid/');
    return ['http:', 'https:', 'mailto:', 'tel:'].includes(parsed.protocol) ? raw : null;
  } catch {
    return null;
  }
}

function inlineMarkdown(text) {
  let html = escapeHtml(text);
  const code = [];
  html = html.replace(/`([^`\n]+)`/g, (_, value) => {
    const token = `\u0000CODE${code.length}\u0000`;
    code.push(`<code>${value}</code>`);
    return token;
  });
  html = html.replace(/\[([^\]]+)\]\(([^)\s]+)(?:\s+&quot;([^&]*)&quot;)?\)/g, (_, label, url, title) => {
    const safe = safeUrl(url);
    if (!safe) return label;
    const external = /^(?:https?:)/i.test(safe);
    return `<a href="${escapeHtml(safe)}"${title ? ` title="${escapeHtml(title)}"` : ''}${external ? ' target="_blank" rel="noopener noreferrer"' : ''}>${label}</a>`;
  });
  html = html.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  html = html.replace(/__([^_]+)__/g, '<strong>$1</strong>');
  html = html.replace(/(?<!\*)\*([^*\n]+)\*(?!\*)/g, '<em>$1</em>');
  html = html.replace(/(?<!_)_([^_\n]+)_(?!_)/g, '<em>$1</em>');
  html = html.replace(/~~([^~]+)~~/g, '<s>$1</s>');
  html = html.replace(/\u0000CODE(\d+)\u0000/g, (_, index) => code[Number(index)] || '');
  return html;
}

function highlightCode(code, language = '') {
  const lang = language.toLowerCase();
  if (!/^(js|javascript|ts|typescript|json|css|html|xml|bash|sh|shell|sql|python|py)$/.test(lang)) return escapeHtml(code);

  const protectedTokens = [];
  const toLetters = index => {
    let value = index + 1;
    let result = '';
    while (value > 0) {
      value -= 1;
      result = String.fromCharCode(65 + (value % 26)) + result;
      value = Math.floor(value / 26);
    }
    return result;
  };

  const tokenized = String(code).replace(/(\/\/[^\n]*|#[^\n]*|--[^\n]*|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|`(?:\\.|[^`\\])*`)/g, value => {
    const isComment = /^(?:\/\/|#|--)/.test(value);
    const token = `\u0001${toLetters(protectedTokens.length)}\u0002`;
    protectedTokens.push(`<span class="tok-${isComment ? 'comment' : 'str'}">${escapeHtml(value)}</span>`);
    return token;
  });

  let highlighted = escapeHtml(tokenized)
    .replace(/\b(const|let|var|function|class|return|if|else|for|while|async|await|import|export|from|new|throw|try|catch|interface|type|extends|implements|def|in|and|or|not|SELECT|FROM|WHERE|INSERT|UPDATE|DELETE|CREATE|ALTER|true|false|null|undefined|None)\b/g, token => {
      const literal = /^(?:true|false|null|undefined|None)$/.test(token);
      return `<span class="tok-${literal ? 'lit' : 'key'}">${token}</span>`;
    })
    .replace(/\b(-?\d+(?:\.\d+)?)\b/g, '<span class="tok-num">$1</span>');

  highlighted = highlighted.replace(/\u0001([A-Z]+)\u0002/g, (_, letters) => {
    let index = 0;
    for (const letter of letters) index = index * 26 + letter.charCodeAt(0) - 64;
    return protectedTokens[index - 1] || '';
  });
  return highlighted;
}

export function markdownToHtml(markdown = '') {
  const source = String(markdown).replace(/\r\n?/g, '\n');
  const codeBlocks = [];
  const tokenized = source.replace(/```([^\n`]*)\n([\s\S]*?)```/g, (_, rawLanguage, code) => {
    const language = rawLanguage.trim().split(/\s+/)[0] || 'text';
    const token = `\u0000BLOCK${codeBlocks.length}\u0000`;
    codeBlocks.push(`<div class="code-block" data-language="${escapeHtml(language)}"><div class="code-toolbar"><span>${escapeHtml(language)}</span><button type="button" data-action="copy-code" aria-label="Copy code">Copy</button></div><pre tabindex="0"><code>${highlightCode(code.replace(/\n$/, ''), language)}</code></pre></div>`);
    return token;
  });

  const lines = tokenized.split('\n');
  const out = [];
  let paragraph = [];
  let listType = null;
  let listItems = [];
  let quoteLines = [];

  const flushParagraph = () => {
    if (paragraph.length) {
      out.push(`<p>${inlineMarkdown(paragraph.join('\n')).replaceAll('\n', '<br>')}</p>`);
      paragraph = [];
    }
  };
  const flushList = () => {
    if (listType) {
      out.push(`<${listType}>${listItems.map(item => `<li>${inlineMarkdown(item)}</li>`).join('')}</${listType}>`);
      listType = null;
      listItems = [];
    }
  };
  const flushQuote = () => {
    if (quoteLines.length) {
      out.push(`<blockquote>${quoteLines.map(line => inlineMarkdown(line)).join('<br>')}</blockquote>`);
      quoteLines = [];
    }
  };
  const flushAll = () => { flushParagraph(); flushList(); flushQuote(); };

  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i];
    if (/^\u0000BLOCK\d+\u0000$/.test(line)) {
      flushAll();
      out.push(line);
      continue;
    }
    if (!line.trim()) {
      flushAll();
      continue;
    }
    const tableSeparator = i + 1 < lines.length && /^\s*\|?\s*:?-{3,}:?\s*(?:\|\s*:?-{3,}:?\s*)+\|?\s*$/.test(lines[i + 1]);
    if (line.includes('|') && tableSeparator) {
      flushAll();
      const headers = line.replace(/^\||\|$/g, '').split('|').map(v => v.trim());
      i += 1;
      const rows = [];
      while (i + 1 < lines.length && lines[i + 1].includes('|') && lines[i + 1].trim()) {
        i += 1;
        rows.push(lines[i].replace(/^\||\|$/g, '').split('|').map(v => v.trim()));
      }
      out.push(`<div class="table-wrap"><table><thead><tr>${headers.map(v => `<th>${inlineMarkdown(v)}</th>`).join('')}</tr></thead><tbody>${rows.map(row => `<tr>${headers.map((_, index) => `<td>${inlineMarkdown(row[index] || '')}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`);
      continue;
    }
    const heading = line.match(/^(#{1,6})\s+(.+)$/);
    if (heading) {
      flushAll();
      const level = heading[1].length;
      out.push(`<h${level}>${inlineMarkdown(heading[2])}</h${level}>`);
      continue;
    }
    if (/^\s*(?:-{3,}|\*{3,}|_{3,})\s*$/.test(line)) {
      flushAll();
      out.push('<hr>');
      continue;
    }
    const quote = line.match(/^>\s?(.*)$/);
    if (quote) {
      flushParagraph();
      flushList();
      quoteLines.push(quote[1]);
      continue;
    }
    const unordered = line.match(/^\s*[-+*]\s+(.+)$/);
    const ordered = line.match(/^\s*\d+[.)]\s+(.+)$/);
    if (unordered || ordered) {
      flushParagraph();
      flushQuote();
      const nextType = unordered ? 'ul' : 'ol';
      if (listType && listType !== nextType) flushList();
      listType = nextType;
      listItems.push((unordered || ordered)[1]);
      continue;
    }
    flushList();
    flushQuote();
    paragraph.push(line);
  }
  flushAll();
  return out.join('\n').replace(/\u0000BLOCK(\d+)\u0000/g, (_, index) => codeBlocks[Number(index)] || '');
}

function relativeTime(iso) {
  if (!iso) return '';
  const value = new Date(iso).getTime();
  if (!Number.isFinite(value)) return '';
  const seconds = Math.round((value - Date.now()) / 1000);
  const formatter = new Intl.RelativeTimeFormat(undefined, { numeric: 'auto' });
  const ranges = [
    ['year', 31536000],
    ['month', 2592000],
    ['week', 604800],
    ['day', 86400],
    ['hour', 3600],
    ['minute', 60]
  ];
  for (const [unit, size] of ranges) {
    if (Math.abs(seconds) >= size) return formatter.format(Math.round(seconds / size), unit);
  }
  return formatter.format(seconds, 'second');
}

function formatTime(iso) {
  try { return new Intl.DateTimeFormat(undefined, { hour: 'numeric', minute: '2-digit' }).format(new Date(iso)); }
  catch { return ''; }
}

function formatDate(iso) {
  try { return new Intl.DateTimeFormat(undefined, { dateStyle: 'medium' }).format(new Date(iso)); }
  catch { return ''; }
}

function debounce(fn, delay = 180) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function normalizeError(error) {
  if (error?.code && error?.message) return error;
  if (error?.name === 'AbortError') return { code: 'stopped', message: 'Generation was stopped.', retryable: true, details: error };
  return {
    code: 'unknown_server_error',
    message: error?.message || 'The request failed for an unknown reason.',
    retryable: true,
    details: error
  };
}

function icon(name) {
  const common = 'viewBox="0 0 24 24" aria-hidden="true" focusable="false"';
  const paths = {
    chat: '<path d="M7 18.5 3.5 21v-4.2A8.5 8.5 0 1 1 7 18.5Z"/><path d="M8 9h8M8 13h5"/>',
    close: '<path d="m6 6 12 12M18 6 6 18"/>',
    minus: '<path d="M5 12h14"/>',
    maximize: '<path d="M5 5h14v14H5z"/>',
    restore: '<path d="M8 8h11v11H8z"/><path d="M5 16V5h11"/>',
    rail: '<path d="M4 5h16v14H4zM9 5v14"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    search: '<circle cx="11" cy="11" r="6"/><path d="m16 16 4 4"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3 1.7 1.7 0 0 0 1-1.6v-.2h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z"/>',
    more: '<circle cx="5" cy="12" r="1" fill="currentColor"/><circle cx="12" cy="12" r="1" fill="currentColor"/><circle cx="19" cy="12" r="1" fill="currentColor"/>',
    send: '<path d="m4 4 16 8-16 8 3-8-3-8Z"/><path d="M7 12h13"/>',
    stop: '<rect x="6" y="6" width="12" height="12" rx="1"/>',
    copy: '<rect x="8" y="8" width="11" height="11" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/>',
    edit: '<path d="m4 20 4.5-1 10-10a2.1 2.1 0 0 0-3-3l-10 10L4 20Z"/><path d="m14 7 3 3"/>',
    retry: '<path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/>',
    quote: '<path d="M9 11H4a5 5 0 0 1 5-5v5Zm11 0h-5a5 5 0 0 1 5-5v5Z"/><path d="M4 11v6h5v-6M15 11v6h5v-6"/>',
    save: '<path d="M5 4h12l2 2v14H5z"/><path d="M8 4v6h8V4M8 20v-6h8v6"/>',
    branch: '<circle cx="6" cy="5" r="2"/><circle cx="18" cy="7" r="2"/><circle cx="6" cy="19" r="2"/><path d="M6 7v10M8 10h5a5 5 0 0 0 5-5"/>',
    thumbsUp: '<path d="M7 10v10H4V10h3Zm0 8h9a2 2 0 0 0 2-1.6l1-5A2 2 0 0 0 17 9h-4l1-4a2 2 0 0 0-2-2l-5 7v8Z"/>',
    thumbsDown: '<path d="M7 14V4H4v10h3Zm0-8h9a2 2 0 0 1 2 1.6l1 5A2 2 0 0 1 17 15h-4l1 4a2 2 0 0 1-2 2l-5-7V6Z"/>',
    pin: '<path d="m9 3 6 6-2 2 3 3-2 2-3-3-2 2-6-6 6-6Z"/><path d="m9 15-5 5"/>',
    archive: '<path d="M4 7h16v13H4zM3 3h18v4H3zM9 11h6"/>',
    trash: '<path d="M4 7h16M9 3h6l1 4H8l1-4ZM7 7l1 14h8l1-14"/>',
    download: '<path d="M12 3v12M7 10l5 5 5-5M4 21h16"/>',
    chevronDown: '<path d="m7 10 5 5 5-5"/>',
    chevronLeft: '<path d="m14 7-5 5 5 5"/>',
    chevronRight: '<path d="m10 7 5 5-5 5"/>',
    check: '<path d="m5 12 4 4L19 6"/>',
    warning: '<path d="M12 3 2 21h20L12 3Z"/><path d="M12 9v5M12 18h.01"/>',
    paperclip: '<path d="m8 12 6-6a3 3 0 0 1 4 4l-8 8a5 5 0 0 1-7-7l8-8"/>',
    context: '<path d="M4 5h16v14H4zM8 9h8M8 13h5"/>',
    clear: '<path d="M5 5h14v14H5zM8 8l8 8M16 8l-8 8"/>'
  };
  return `<svg ${common}>${paths[name] || paths.more}</svg>`;
}

const WIDGET_CSS = String.raw`
:host {
  --writer-chat-bg: #09090b;
  --writer-chat-surface: #111114;
  --writer-chat-surface-raised: #18181b;
  --writer-chat-border: #27272a;
  --writer-chat-text: #f4f4f5;
  --writer-chat-muted: #a1a1aa;
  --writer-chat-subtle: #71717a;
  --writer-chat-accent: #6366f1;
  --writer-chat-accent-hover: #4f46e5;
  --writer-chat-danger: #f43f5e;
  --writer-chat-success: #10b981;
  --writer-chat-warning: #f59e0b;
  --writer-chat-z-index: 900;
  --writer-chat-launcher-size: 52px;
  --writer-chat-right: 16px;
  --writer-chat-left: 16px;
  --writer-chat-bottom: 16px;
  --writer-chat-radius: 16px;
  --writer-chat-font: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
  color-scheme: dark;
  font-family: var(--writer-chat-font);
  position: fixed;
  inset: 0;
  z-index: var(--writer-chat-z-index);
  pointer-events: none;
}
:host([theme="light"]), :host(.theme-light) {
  --writer-chat-bg: #ffffff;
  --writer-chat-surface: #f8fafc;
  --writer-chat-surface-raised: #ffffff;
  --writer-chat-border: #dbe2ea;
  --writer-chat-text: #111827;
  --writer-chat-muted: #4b5563;
  --writer-chat-subtle: #6b7280;
  --writer-chat-accent: #4f46e5;
  --writer-chat-accent-hover: #4338ca;
  color-scheme: light;
}
* { box-sizing: border-box; }
button, input, textarea, select { font: inherit; color: inherit; }
button { border: 0; }
button:focus-visible, input:focus-visible, textarea:focus-visible, [tabindex]:focus-visible {
  outline: 2px solid var(--writer-chat-accent);
  outline-offset: 2px;
}
svg { width: 18px; height: 18px; fill: none; stroke: currentColor; stroke-width: 1.8; stroke-linecap: round; stroke-linejoin: round; }
.launcher {
  pointer-events: auto;
  position: fixed;
  bottom: calc(var(--writer-chat-bottom) + env(safe-area-inset-bottom));
  width: var(--writer-chat-launcher-size);
  height: var(--writer-chat-launcher-size);
  border-radius: 999px;
  display: grid;
  place-items: center;
  background: var(--writer-chat-accent);
  color: white;
  box-shadow: 0 14px 38px rgb(0 0 0 / .35);
  cursor: pointer;
  transition: transform .18s ease, background .18s ease;
}
:host([placement="left"]) .launcher { left: calc(var(--writer-chat-left) + env(safe-area-inset-left)); }
:host(:not([placement="left"])) .launcher { right: calc(var(--writer-chat-right) + env(safe-area-inset-right)); }
.launcher:hover { background: var(--writer-chat-accent-hover); transform: translateY(-2px); }
.launcher[hidden] { display: none; }
.launcher svg { width: 24px; height: 24px; }
.launcher-status {
  position: absolute;
  width: 12px;
  height: 12px;
  border-radius: 50%;
  right: 0;
  top: 0;
  background: var(--writer-chat-success);
  border: 2px solid var(--writer-chat-bg);
}
.launcher-status.error { background: var(--writer-chat-danger); }
.launcher-status.streaming { animation: pulse 1.4s infinite; }
.drawer {
  pointer-events: auto;
  position: fixed;
  bottom: calc(var(--writer-chat-bottom) + env(safe-area-inset-bottom));
  width: min(var(--drawer-width, 760px), calc(100vw - 24px));
  height: min(800px, calc(100dvh - 32px - env(safe-area-inset-top) - env(safe-area-inset-bottom)));
  display: grid;
  grid-template-columns: auto 1fr;
  overflow: hidden;
  background: var(--writer-chat-bg);
  color: var(--writer-chat-text);
  border: 1px solid var(--writer-chat-border);
  border-radius: var(--writer-chat-radius);
  box-shadow: 0 26px 70px rgb(0 0 0 / .42);
  transform-origin: bottom right;
  animation: drawer-in .16s ease-out;
}
:host([placement="left"]) .drawer { left: calc(var(--writer-chat-left) + env(safe-area-inset-left)); }
:host(:not([placement="left"])) .drawer { right: calc(var(--writer-chat-right) + env(safe-area-inset-right)); }
.drawer[hidden] { display: none; }
.drawer.maximized {
  inset: env(safe-area-inset-top) env(safe-area-inset-right) env(safe-area-inset-bottom) env(safe-area-inset-left);
  width: auto;
  height: auto;
  max-width: none;
  border-radius: 0;
}
.drawer.minimized {
  width: 340px;
  height: 58px;
  grid-template-columns: 1fr;
}
.drawer.minimized .thread-rail,
.drawer.minimized .conversation,
.drawer.minimized .resize-handle,
.drawer.minimized .banner,
.drawer.minimized .scope-row { display: none; }
.drawer.minimized .main-panel { min-width: 0; }
.drawer.minimized .header { border-bottom: 0; }
.main-panel { min-width: 0; min-height: 0; display: grid; grid-template-rows: auto auto 1fr; }
.header {
  min-height: 58px;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 10px;
  background: color-mix(in srgb, var(--writer-chat-bg) 92%, transparent);
  border-bottom: 1px solid var(--writer-chat-border);
}
.header-title { min-width: 0; flex: 1; }
.header-title strong { display: block; font-size: 14px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.header-title small { display: flex; gap: 7px; align-items: center; color: var(--writer-chat-muted); font-size: 11px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.connection-dot { width: 7px; height: 7px; border-radius: 50%; background: var(--writer-chat-success); flex: 0 0 auto; }
.connection-dot.streaming { animation: pulse 1.3s infinite; }
.connection-dot.offline, .connection-dot.error { background: var(--writer-chat-danger); }
.icon-button, .text-button, .primary-button, .danger-button {
  min-width: 36px;
  min-height: 36px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  border-radius: 9px;
  cursor: pointer;
  background: transparent;
  color: var(--writer-chat-muted);
}
.icon-button:hover, .text-button:hover { background: var(--writer-chat-surface-raised); color: var(--writer-chat-text); }
.icon-button[disabled], .text-button[disabled], .primary-button[disabled] { opacity: .45; cursor: not-allowed; }
.text-button { padding: 0 10px; }
.primary-button { background: var(--writer-chat-accent); color: white; padding: 0 14px; }
.primary-button:hover { background: var(--writer-chat-accent-hover); }
.danger-button { background: color-mix(in srgb, var(--writer-chat-danger) 16%, transparent); color: var(--writer-chat-danger); padding: 0 14px; }
.model-button { max-width: 190px; justify-content: flex-start; padding: 0 10px; }
.model-button span { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.scope-row { min-height: 29px; display: flex; align-items: center; gap: 6px; padding: 4px 12px; border-bottom: 1px solid var(--writer-chat-border); color: var(--writer-chat-muted); font-size: 11px; }
.scope-row strong { color: var(--writer-chat-text); font-weight: 600; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.banner { padding: 9px 12px; display: flex; align-items: center; gap: 8px; background: color-mix(in srgb, var(--writer-chat-warning) 14%, var(--writer-chat-bg)); border-bottom: 1px solid color-mix(in srgb, var(--writer-chat-warning) 38%, var(--writer-chat-border)); color: var(--writer-chat-text); font-size: 12px; }
.banner[hidden] { display: none; }
.banner svg { color: var(--writer-chat-warning); flex: 0 0 auto; }
.thread-rail {
  width: 228px;
  min-width: 228px;
  min-height: 0;
  display: grid;
  grid-template-rows: auto auto 1fr auto;
  background: var(--writer-chat-surface);
  border-inline-end: 1px solid var(--writer-chat-border);
}
.thread-rail[hidden] { display: none; }
.rail-header { display: flex; align-items: center; justify-content: space-between; padding: 10px; }
.new-chat { width: 100%; justify-content: flex-start; background: var(--writer-chat-accent); color: white; }
.search-wrap { position: relative; margin: 0 10px 8px; }
.search-wrap svg { position: absolute; left: 9px; top: 50%; transform: translateY(-50%); color: var(--writer-chat-subtle); width: 15px; }
.search-wrap input { width: 100%; height: 34px; padding: 0 9px 0 32px; border: 1px solid var(--writer-chat-border); border-radius: 9px; background: var(--writer-chat-bg); color: var(--writer-chat-text); }
.thread-list { min-height: 0; overflow: auto; padding: 0 7px 10px; scrollbar-width: thin; }
.thread-section-title { padding: 10px 7px 5px; color: var(--writer-chat-subtle); font-size: 10px; font-weight: 700; letter-spacing: .08em; text-transform: uppercase; }
.thread-item { position: relative; display: grid; grid-template-columns: 1fr auto; gap: 5px; align-items: center; min-height: 52px; padding: 7px 4px 7px 9px; border-radius: 9px; cursor: pointer; }
.thread-item:hover { background: color-mix(in srgb, var(--writer-chat-surface-raised) 75%, transparent); }
.thread-item.active { background: var(--writer-chat-surface-raised); box-shadow: inset 2px 0 var(--writer-chat-accent); }
.thread-copy { min-width: 0; }
.thread-title { display: flex; align-items: center; gap: 5px; min-width: 0; font-size: 12px; color: var(--writer-chat-text); }
.thread-title span { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.thread-meta { display: flex; align-items: center; gap: 5px; margin-top: 4px; font-size: 10px; color: var(--writer-chat-subtle); }
.thread-indicator { width: 6px; height: 6px; border-radius: 50%; background: var(--writer-chat-accent); }
.thread-indicator.error { background: var(--writer-chat-danger); }
.thread-indicator.streaming { animation: pulse 1.2s infinite; }
.thread-menu-button { min-width: 32px; min-height: 32px; opacity: 0; }
.thread-item:hover .thread-menu-button, .thread-menu-button:focus-visible, .thread-item.active .thread-menu-button { opacity: 1; }
.rail-footer { display: flex; border-top: 1px solid var(--writer-chat-border); padding: 6px; }
.archived-toggle { width: 100%; justify-content: flex-start; font-size: 12px; }
.empty-state { display: grid; place-items: center; align-content: center; gap: 10px; min-height: 180px; padding: 25px; text-align: center; color: var(--writer-chat-muted); }
.empty-state strong { color: var(--writer-chat-text); }
.empty-state p { margin: 0; max-width: 38ch; font-size: 13px; line-height: 1.55; }
.conversation { min-height: 0; display: grid; grid-template-rows: 1fr auto; background: var(--writer-chat-bg); }
.timeline-wrap { position: relative; min-height: 0; }
.timeline { height: 100%; overflow: auto; padding: 18px clamp(14px, 3vw, 36px) 28px; scroll-behavior: smooth; overscroll-behavior: contain; scrollbar-width: thin; }
.date-separator { display: flex; align-items: center; gap: 8px; margin: 16px 0; color: var(--writer-chat-subtle); font-size: 10px; }
.date-separator::before, .date-separator::after { content: ''; flex: 1; height: 1px; background: var(--writer-chat-border); }
.message { position: relative; margin: 0 0 20px; }
.message-row { display: flex; gap: 10px; align-items: flex-start; }
.message.user .message-row { flex-direction: row-reverse; }
.avatar { width: 28px; height: 28px; flex: 0 0 auto; display: grid; place-items: center; border-radius: 9px; font-size: 11px; font-weight: 700; background: var(--writer-chat-surface-raised); color: var(--writer-chat-muted); }
.message.user .avatar { background: var(--writer-chat-accent); color: white; }
.message-main { min-width: 0; max-width: min(82%, 720px); }
.message.user .message-main { display: flex; flex-direction: column; align-items: flex-end; }
.message-bubble { position: relative; min-width: 0; padding: 12px 14px; border-radius: 14px; background: var(--writer-chat-surface-raised); border: 1px solid transparent; line-height: 1.58; font-size: 14px; overflow-wrap: anywhere; }
.message.user .message-bubble { background: color-mix(in srgb, var(--writer-chat-accent) 21%, var(--writer-chat-surface-raised)); border-color: color-mix(in srgb, var(--writer-chat-accent) 32%, transparent); }
.message.failed .message-bubble { border-color: color-mix(in srgb, var(--writer-chat-danger) 60%, transparent); }
.message.stopped .message-bubble { border-color: color-mix(in srgb, var(--writer-chat-warning) 48%, transparent); }
.message.unsaved .message-bubble { border-style: dashed; border-color: var(--writer-chat-warning); }
.message-content > :first-child { margin-top: 0; }
.message-content > :last-child { margin-bottom: 0; }
.message-content p { margin: 0 0 10px; }
.message-content h1, .message-content h2, .message-content h3, .message-content h4, .message-content h5, .message-content h6 { margin: 18px 0 8px; line-height: 1.28; }
.message-content h1 { font-size: 1.45em; }.message-content h2 { font-size: 1.3em; }.message-content h3 { font-size: 1.15em; }
.message-content ul, .message-content ol { margin: 8px 0; padding-left: 24px; }
.message-content blockquote { margin: 12px 0; padding: 8px 13px; border-left: 3px solid var(--writer-chat-accent); background: color-mix(in srgb, var(--writer-chat-surface) 70%, transparent); color: var(--writer-chat-muted); }
.message-content a { color: #8b8df8; text-underline-offset: 2px; }
.message-content code { padding: .15em .35em; border-radius: 5px; background: color-mix(in srgb, var(--writer-chat-border) 75%, transparent); font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-size: .9em; }
.message-content .code-block { margin: 12px 0; overflow: hidden; border: 1px solid var(--writer-chat-border); border-radius: 10px; background: #08080a; }
.code-toolbar { min-height: 34px; display: flex; align-items: center; justify-content: space-between; padding: 0 7px 0 11px; color: #a1a1aa; background: #141417; border-bottom: 1px solid #27272a; font-size: 11px; }
.code-toolbar button { min-height: 28px; padding: 0 8px; border-radius: 6px; background: transparent; color: #d4d4d8; cursor: pointer; }
.code-toolbar button:hover { background: #27272a; }
.code-block pre { margin: 0; padding: 14px; overflow: auto; line-height: 1.55; tab-size: 2; }
.code-block pre code { padding: 0; background: transparent; color: #e4e4e7; white-space: pre; }
.tok-key { color: #c4b5fd; }.tok-str { color: #86efac; }.tok-num { color: #fdba74; }.tok-lit { color: #7dd3fc; }.tok-comment { color: #71717a; }.tok-key { color: #f0abfc; }
.table-wrap { max-width: 100%; overflow-x: auto; margin: 12px 0; }
table { width: 100%; border-collapse: collapse; font-size: 13px; }
th, td { border: 1px solid var(--writer-chat-border); padding: 7px 9px; text-align: left; }
th { background: var(--writer-chat-surface); }
.message-meta { display: flex; align-items: center; flex-wrap: wrap; gap: 6px; margin-top: 6px; color: var(--writer-chat-subtle); font-size: 10px; }
.message.user .message-meta { justify-content: flex-end; }
.message-status { display: inline-flex; align-items: center; gap: 4px; }
.streaming-cursor { display: inline-block; width: 7px; height: 15px; margin-left: 2px; vertical-align: -2px; background: var(--writer-chat-accent); animation: blink 1s steps(2, start) infinite; }
.message-actions { display: flex; align-items: center; gap: 2px; margin-top: 5px; opacity: 0; transition: opacity .12s ease; }
.message:hover .message-actions, .message:focus-within .message-actions { opacity: 1; }
.message.user .message-actions { justify-content: flex-end; }
.message-actions .icon-button { min-width: 30px; min-height: 30px; }
.variant-nav { display: inline-flex; align-items: center; gap: 2px; margin-inline-start: 3px; }
.variant-nav button { min-width: 25px; min-height: 25px; }
.inline-error { margin-top: 8px; padding: 9px 10px; border-radius: 8px; background: color-mix(in srgb, var(--writer-chat-danger) 12%, transparent); color: var(--writer-chat-text); font-size: 12px; }
.inline-error summary { cursor: pointer; color: var(--writer-chat-danger); }
.inline-error pre { max-height: 170px; overflow: auto; white-space: pre-wrap; color: var(--writer-chat-muted); }
.scroll-button { position: absolute; right: 18px; bottom: 16px; min-width: 38px; height: 38px; border-radius: 999px; background: var(--writer-chat-surface-raised); color: var(--writer-chat-text); border: 1px solid var(--writer-chat-border); box-shadow: 0 8px 24px rgb(0 0 0 / .25); cursor: pointer; }
.scroll-button[hidden] { display: none; }
.composer-area { padding: 10px 12px calc(10px + env(safe-area-inset-bottom)); border-top: 1px solid var(--writer-chat-border); background: color-mix(in srgb, var(--writer-chat-bg) 96%, transparent); }
.attachment-list { display: flex; flex-wrap: wrap; gap: 6px; margin: 0 0 7px; }
.attachment-chip { display: inline-flex; align-items: center; gap: 6px; padding: 5px 7px; border: 1px solid var(--writer-chat-border); border-radius: 8px; background: var(--writer-chat-surface); font-size: 11px; }
.composer-shell { display: grid; grid-template-columns: auto 1fr auto; align-items: end; gap: 7px; padding: 7px; border: 1px solid var(--writer-chat-border); border-radius: 13px; background: var(--writer-chat-surface-raised); }
.composer-shell:focus-within { border-color: color-mix(in srgb, var(--writer-chat-accent) 65%, var(--writer-chat-border)); box-shadow: 0 0 0 3px color-mix(in srgb, var(--writer-chat-accent) 15%, transparent); }
.composer-tools { display: flex; gap: 2px; }
.composer { width: 100%; min-height: 36px; max-height: 180px; resize: none; overflow-y: auto; padding: 8px 2px; border: 0; outline: none; background: transparent; color: var(--writer-chat-text); line-height: 1.45; }
.composer::placeholder { color: var(--writer-chat-subtle); }
.send-button { min-width: 38px; height: 38px; border-radius: 10px; background: var(--writer-chat-accent); color: white; cursor: pointer; }
.send-button:hover { background: var(--writer-chat-accent-hover); }
.send-button.stop { background: var(--writer-chat-danger); }
.composer-meta { min-height: 22px; display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 5px 3px 0; color: var(--writer-chat-subtle); font-size: 10px; }
.resize-handle { position: absolute; top: 10%; bottom: 10%; width: 9px; cursor: ew-resize; touch-action: none; }
:host([placement="left"]) .resize-handle { right: -5px; }
:host(:not([placement="left"])) .resize-handle { left: -5px; }
.popover, .menu {
  position: fixed;
  z-index: calc(var(--writer-chat-z-index) + 5);
  min-width: 190px;
  max-width: min(360px, calc(100vw - 24px));
  max-height: min(480px, calc(100dvh - 30px));
  overflow: auto;
  padding: 6px;
  border: 1px solid var(--writer-chat-border);
  border-radius: 12px;
  background: var(--writer-chat-surface-raised);
  color: var(--writer-chat-text);
  box-shadow: 0 18px 50px rgb(0 0 0 / .42);
}
.popover[hidden], .menu[hidden] { display: none; }
.menu button, .model-option { width: 100%; min-height: 38px; display: flex; align-items: center; gap: 9px; padding: 7px 9px; border-radius: 8px; background: transparent; color: var(--writer-chat-text); text-align: left; cursor: pointer; }
.menu button:hover, .model-option:hover, .model-option.active { background: var(--writer-chat-surface); }
.menu button.danger { color: var(--writer-chat-danger); }
.menu-separator { height: 1px; margin: 5px 3px; background: var(--writer-chat-border); }
.model-popover { width: 340px; }
.popover-search { position: sticky; top: 0; padding: 4px; background: var(--writer-chat-surface-raised); }
.popover-search input { width: 100%; height: 36px; padding: 0 10px; border: 1px solid var(--writer-chat-border); border-radius: 8px; background: var(--writer-chat-bg); }
.model-group-title { padding: 10px 8px 5px; color: var(--writer-chat-subtle); font-size: 10px; text-transform: uppercase; letter-spacing: .07em; font-weight: 700; }
.model-option-copy { flex: 1; min-width: 0; }
.model-option-copy strong, .model-option-copy small { display: block; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.model-option-copy strong { font-size: 12px; }.model-option-copy small { margin-top: 2px; color: var(--writer-chat-subtle); font-size: 10px; }
.badge { display: inline-flex; align-items: center; min-height: 19px; padding: 0 6px; border-radius: 999px; background: var(--writer-chat-surface); color: var(--writer-chat-muted); font-size: 9px; }
.settings-panel { width: 330px; padding: 12px; }
.settings-panel h3 { margin: 0 0 12px; font-size: 14px; }
.field { display: grid; gap: 5px; margin: 0 0 12px; }
.field label { color: var(--writer-chat-muted); font-size: 11px; }
.field input, .field textarea, .field select { width: 100%; border: 1px solid var(--writer-chat-border); border-radius: 8px; background: var(--writer-chat-bg); padding: 8px 9px; }
.field textarea { min-height: 80px; resize: vertical; }
.field-row { display: grid; grid-template-columns: 1fr 1fr; gap: 9px; }
.settings-footer { display: flex; justify-content: space-between; align-items: center; gap: 8px; margin-top: 10px; }
.save-state { color: var(--writer-chat-subtle); font-size: 10px; }
.dialog-backdrop { position: fixed; inset: 0; z-index: calc(var(--writer-chat-z-index) + 10); display: grid; place-items: center; padding: 20px; background: rgb(0 0 0 / .58); pointer-events: auto; }
.dialog-backdrop[hidden] { display: none; }
.dialog { width: min(430px, 100%); max-height: min(650px, calc(100dvh - 40px)); overflow: auto; border: 1px solid var(--writer-chat-border); border-radius: 14px; background: var(--writer-chat-surface-raised); color: var(--writer-chat-text); box-shadow: 0 24px 70px rgb(0 0 0 / .5); }
.dialog-header { display: flex; align-items: center; justify-content: space-between; padding: 14px 15px; border-bottom: 1px solid var(--writer-chat-border); }
.dialog-header h2 { margin: 0; font-size: 15px; }
.dialog-body { padding: 15px; color: var(--writer-chat-muted); font-size: 13px; line-height: 1.5; }
.dialog-body strong { color: var(--writer-chat-text); }
.dialog-body input, .dialog-body textarea { width: 100%; margin-top: 10px; padding: 9px 10px; border: 1px solid var(--writer-chat-border); border-radius: 9px; background: var(--writer-chat-bg); color: var(--writer-chat-text); }
.dialog-body textarea { min-height: 120px; resize: vertical; }
.dialog-footer { display: flex; justify-content: flex-end; gap: 8px; padding: 12px 15px; border-top: 1px solid var(--writer-chat-border); }
.toast-region { position: fixed; right: 18px; bottom: 18px; z-index: calc(var(--writer-chat-z-index) + 20); display: grid; gap: 8px; pointer-events: none; }
.toast { max-width: min(380px, calc(100vw - 36px)); padding: 10px 12px; border: 1px solid var(--writer-chat-border); border-radius: 9px; background: var(--writer-chat-surface-raised); color: var(--writer-chat-text); box-shadow: 0 12px 35px rgb(0 0 0 / .4); font-size: 12px; animation: toast-in .18s ease-out; }
.sr-only { position: absolute !important; width: 1px !important; height: 1px !important; padding: 0 !important; margin: -1px !important; overflow: hidden !important; clip: rect(0, 0, 0, 0) !important; white-space: nowrap !important; border: 0 !important; }
.loading-skeleton { display: grid; gap: 8px; padding: 10px; }
.loading-skeleton span { height: 42px; border-radius: 8px; background: linear-gradient(90deg, var(--writer-chat-surface) 25%, var(--writer-chat-surface-raised) 45%, var(--writer-chat-surface) 65%); background-size: 220% 100%; animation: shimmer 1.4s infinite; }
@keyframes drawer-in { from { opacity: 0; transform: translateY(8px) scale(.985); } }
@keyframes pulse { 50% { opacity: .35; transform: scale(.82); } }
@keyframes blink { 50% { opacity: 0; } }
@keyframes toast-in { from { opacity: 0; transform: translateY(7px); } }
@keyframes shimmer { to { background-position: -220% 0; } }
@media (max-width: 700px) {
  .drawer, :host([placement="left"]) .drawer, :host(:not([placement="left"])) .drawer {
    inset: 0;
    width: 100vw;
    height: 100dvh;
    max-width: none;
    border: 0;
    border-radius: 0;
    grid-template-columns: 1fr;
  }
  .drawer.minimized { inset: auto 10px calc(10px + env(safe-area-inset-bottom)) 10px; width: auto; height: 58px; border: 1px solid var(--writer-chat-border); border-radius: 13px; }
  .thread-rail { position: absolute; inset: 0 auto 0 0; z-index: 4; width: min(86vw, 330px); min-width: 0; box-shadow: 14px 0 40px rgb(0 0 0 / .45); }
  .thread-rail[hidden] { display: none; }
  .resize-handle { display: none; }
  .header { padding-top: calc(8px + env(safe-area-inset-top)); min-height: calc(58px + env(safe-area-inset-top)); }
  .header .desktop-secondary { display: none; }
  .message-main { max-width: 88%; }
  .icon-button, .text-button, .primary-button, .danger-button { min-width: 44px; min-height: 44px; }
  .thread-menu-button { opacity: 1; }
  .message-actions { opacity: 1; overflow-x: auto; max-width: 100%; }
  .composer-area { padding-inline: 8px; }
  .composer-tools .optional-tool { display: none; }
  .model-button { max-width: 120px; min-width: 44px; }
  .model-button span { display: none; }
  .popover, .menu { max-width: calc(100vw - 20px); }
}
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after { scroll-behavior: auto !important; animation-duration: .01ms !important; animation-iteration-count: 1 !important; transition-duration: .01ms !important; }
}
`;

export class WriterChatWidget extends HTMLElement {
  static get observedAttributes() { return ['placement', 'theme']; }

  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this.instanceId = this.id || createId('writer-chat');
    this.userId = 'anonymous';
    this.adapter = null;
    this.scope = { id: 'default', type: 'workspace', title: 'Workspace', surface: 'unknown', activeEntityId: null };
    this.capabilities = { ...DEFAULT_CAPABILITIES };
    this.ui = { ...DEFAULT_STATE };
    this.threads = [];
    this.messagesByThread = new Map();
    this.messageCursors = new Map();
    this.drafts = new Map();
    this.attachmentsByThread = new Map();
    this.models = [];
    this.modelCatalogState = 'idle';
    this.activeThreadId = null;
    this.threadLoading = false;
    this.messageLoading = false;
    this.searchQuery = '';
    this.streams = new Map();
    this.threadRequestIds = new Map();
    this.deltaQueues = new Map();
    this.deltaFrame = null;
    this.selectedVariants = new Map();
    this.scrollPositions = new Map();
    this.destroyed = false;
    this.online = globalThis.navigator?.onLine !== false;
    this.configurationBanner = null;
    this.lastFocusedBeforeDialog = null;
    this.menuContext = null;
    this.dialogResolve = null;
    this.loadThreadsAbort = null;
    this.loadMessagesAbort = null;
    this.resizeState = null;
    this.sendingLocks = new Set();
    this._bound = false;
    this._searchDebounced = debounce(() => this.loadThreads(), 220);
  }

  connectedCallback() {
    if (this.destroyed) return;
    if (!this.shadowRoot.firstChild) this.renderShell();
    this.restoreUiState();
    this.applyAttributes();
    this.bindEvents();
    this.renderAll();
    if (this.ui.open && !this.ui.minimized) queueMicrotask(() => this.focusComposer());
    this.dispatchWidgetEvent('writer-chat:ready', { version: VERSION });
  }

  disconnectedCallback() {
    this.unbindEvents();
    this.loadThreadsAbort?.abort();
    this.loadMessagesAbort?.abort();
    if (this.deltaFrame) cancelAnimationFrame(this.deltaFrame);
  }

  attributeChangedCallback() {
    if (this.isConnected) {
      this.applyAttributes();
      this.persistUiState();
    }
  }

  renderShell() {
    this.shadowRoot.innerHTML = `
      <style>${WIDGET_CSS}</style>
      <button class="launcher" type="button" aria-label="Open Writer AI" aria-expanded="false" data-action="toggle-widget">
        ${icon('chat')}
        <span class="launcher-status" hidden></span>
      </button>
      <section class="drawer" aria-label="Writer AI chat" hidden>
        <aside class="thread-rail" aria-label="Chat threads">
          <div class="rail-header">
            <button class="text-button new-chat" type="button" data-action="new-thread">${icon('plus')}<span>New chat</span></button>
          </div>
          <div class="search-wrap">
            ${icon('search')}
            <label class="sr-only" for="thread-search-${this.instanceId}">Search conversations</label>
            <input id="thread-search-${this.instanceId}" type="search" placeholder="Search conversations" autocomplete="off">
          </div>
          <div class="thread-list" role="list" aria-live="polite"></div>
          <div class="rail-footer">
            <button class="text-button archived-toggle" type="button" data-action="toggle-archived">${icon('archive')}<span>Archived chats</span></button>
          </div>
        </aside>

        <div class="main-panel">
          <header class="header">
            <button class="icon-button" type="button" data-action="toggle-rail" aria-label="Toggle thread list" aria-expanded="true">${icon('rail')}</button>
            <div class="header-title">
              <strong class="active-thread-title">Writer AI</strong>
              <small><span class="connection-dot"></span><span class="connection-label">Ready</span><span class="desktop-secondary model-provider"></span></small>
            </div>
            <button class="text-button model-button" type="button" data-action="open-models" aria-haspopup="listbox" aria-expanded="false">${icon('chevronDown')}<span class="current-model">Automatic</span></button>
            <button class="icon-button desktop-secondary" type="button" data-action="open-settings" aria-label="Thread settings" aria-haspopup="dialog">${icon('settings')}</button>
            <button class="icon-button" type="button" data-action="minimize" aria-label="Minimize chat">${icon('minus')}</button>
            <button class="icon-button maximize-button" type="button" data-action="maximize" aria-label="Maximize chat">${icon('maximize')}</button>
            <button class="icon-button" type="button" data-action="close" aria-label="Close chat">${icon('close')}</button>
            <button class="icon-button" type="button" data-action="open-overflow" aria-label="More chat actions" aria-haspopup="menu">${icon('more')}</button>
          </header>
          <div class="scope-row"><span>Scope</span><strong class="scope-title">Workspace</strong><span class="scope-surface"></span></div>
          <div class="banner" hidden>${icon('warning')}<span class="banner-text"></span></div>
          <div class="conversation">
            <div class="timeline-wrap">
              <div class="timeline" role="log" aria-live="off" aria-relevant="additions text" tabindex="0"></div>
              <button class="scroll-button" type="button" data-action="scroll-bottom" aria-label="Scroll to latest message" hidden>${icon('chevronDown')}</button>
            </div>
            <div class="composer-area">
              <div class="attachment-list" hidden></div>
              <div class="composer-shell">
                <div class="composer-tools">
                  <button class="icon-button attachment-button" type="button" data-action="attach" aria-label="Attach a file" hidden>${icon('paperclip')}</button>
                  <button class="icon-button context-button optional-tool" type="button" data-action="request-context" aria-label="Add selected Writer context" hidden>${icon('context')}</button>
                  <input class="attachment-input" type="file" multiple hidden>
                </div>
                <label class="sr-only" for="composer-${this.instanceId}">Message Writer AI</label>
                <textarea id="composer-${this.instanceId}" class="composer" rows="1" placeholder="Message Writer AI" spellcheck="true"></textarea>
                <button class="send-button" type="button" data-action="send" aria-label="Send message">${icon('send')}</button>
              </div>
              <div class="composer-meta">
                <span class="composer-hint">Enter to send · Shift+Enter for a new line</span>
                <span><span class="count">0 chars · ~0 tokens</span> <button class="text-button clear-draft" type="button" data-action="clear-draft" hidden>Clear</button></span>
              </div>
            </div>
          </div>
        </div>
        <div class="resize-handle" role="separator" aria-orientation="vertical" aria-label="Resize chat drawer" tabindex="0"></div>
      </section>

      <div class="menu context-menu" role="menu" hidden></div>
      <div class="popover model-popover" role="dialog" aria-label="Select model" hidden>
        <div class="popover-search"><input type="search" class="model-search" placeholder="Search models" aria-label="Search models"></div>
        <div class="model-list" role="listbox"></div>
      </div>
      <div class="popover settings-panel" role="dialog" aria-label="Thread settings" hidden></div>

      <div class="dialog-backdrop" hidden>
        <section class="dialog" role="dialog" aria-modal="true" aria-labelledby="writer-chat-dialog-title">
          <header class="dialog-header"><h2 id="writer-chat-dialog-title"></h2><button class="icon-button" type="button" data-dialog-action="cancel" aria-label="Close dialog">${icon('close')}</button></header>
          <div class="dialog-body"></div>
          <footer class="dialog-footer"></footer>
        </section>
      </div>
      <div class="toast-region" aria-live="polite" aria-atomic="true"></div>
      <div class="sr-only completion-live" aria-live="polite" aria-atomic="true"></div>
    `;
    this.cacheElements();
  }

  cacheElements() {
    const q = selector => this.shadowRoot.querySelector(selector);
    this.els = {
      launcher: q('.launcher'), launcherStatus: q('.launcher-status'), drawer: q('.drawer'), rail: q('.thread-rail'),
      threadList: q('.thread-list'), search: q('.search-wrap input'), timeline: q('.timeline'), scrollButton: q('.scroll-button'),
      composer: q('.composer'), send: q('.send-button'), count: q('.count'), clearDraft: q('.clear-draft'),
      attachmentButton: q('.attachment-button'), attachmentInput: q('.attachment-input'), attachmentList: q('.attachment-list'), contextButton: q('.context-button'),
      threadTitle: q('.active-thread-title'), currentModel: q('.current-model'), modelProvider: q('.model-provider'),
      scopeTitle: q('.scope-title'), scopeSurface: q('.scope-surface'), connectionDot: q('.connection-dot'), connectionLabel: q('.connection-label'),
      banner: q('.banner'), bannerText: q('.banner-text'), maximizeButton: q('.maximize-button'), railToggle: q('[data-action="toggle-rail"]'),
      menu: q('.context-menu'), modelPopover: q('.model-popover'), modelSearch: q('.model-search'), modelList: q('.model-list'), settings: q('.settings-panel'),
      dialogBackdrop: q('.dialog-backdrop'), dialogTitle: q('#writer-chat-dialog-title'), dialogBody: q('.dialog-body'), dialogFooter: q('.dialog-footer'),
      toastRegion: q('.toast-region'), completionLive: q('.completion-live'), resizeHandle: q('.resize-handle')
    };
  }

  bindEvents() {
    if (this._bound) return;
    this._bound = true;
    this._onClick = event => this.handleClick(event);
    this._onInput = event => this.handleInput(event);
    this._onKeyDown = event => this.handleKeyDown(event);
    this._onTimelineScroll = () => this.handleTimelineScroll();
    this._onPointerDown = event => this.beginResize(event);
    this._onPointerMove = event => this.performResize(event);
    this._onPointerUp = () => this.endResize();
    this._onOnline = () => { this.online = true; this.renderConnection(); this.renderBanner(); };
    this._onOffline = () => { this.online = false; this.renderConnection(); this.renderBanner(); };
    this._onDocumentPointer = event => this.handleOutsidePointer(event);
    this._onDragOver = event => { if (this.capabilities.attachments) event.preventDefault(); };
    this._onDrop = event => { if (!this.capabilities.attachments) return; event.preventDefault(); this.handleFiles([...event.dataTransfer.files]); };
    this._onPaste = event => { if (!this.capabilities.attachments) return; const files = [...(event.clipboardData?.files || [])]; if (files.length) this.handleFiles(files); };

    this.shadowRoot.addEventListener('click', this._onClick);
    this.shadowRoot.addEventListener('input', this._onInput);
    this.shadowRoot.addEventListener('keydown', this._onKeyDown);
    this.els.timeline.addEventListener('scroll', this._onTimelineScroll, { passive: true });
    this.els.resizeHandle.addEventListener('pointerdown', this._onPointerDown);
    this.shadowRoot.querySelector('.composer-shell').addEventListener('dragover', this._onDragOver);
    this.shadowRoot.querySelector('.composer-shell').addEventListener('drop', this._onDrop);
    this.els.composer.addEventListener('paste', this._onPaste);
    globalThis.addEventListener('pointermove', this._onPointerMove);
    globalThis.addEventListener('pointerup', this._onPointerUp);
    globalThis.addEventListener('online', this._onOnline);
    globalThis.addEventListener('offline', this._onOffline);
    document.addEventListener('pointerdown', this._onDocumentPointer, true);
  }

  unbindEvents() {
    if (!this._bound) return;
    this._bound = false;
    this.shadowRoot.removeEventListener('click', this._onClick);
    this.shadowRoot.removeEventListener('input', this._onInput);
    this.shadowRoot.removeEventListener('keydown', this._onKeyDown);
    this.els?.timeline?.removeEventListener('scroll', this._onTimelineScroll);
    this.els?.resizeHandle?.removeEventListener('pointerdown', this._onPointerDown);
    this.shadowRoot.querySelector('.composer-shell')?.removeEventListener('dragover', this._onDragOver);
    this.shadowRoot.querySelector('.composer-shell')?.removeEventListener('drop', this._onDrop);
    this.els?.composer?.removeEventListener('paste', this._onPaste);
    globalThis.removeEventListener('pointermove', this._onPointerMove);
    globalThis.removeEventListener('pointerup', this._onPointerUp);
    globalThis.removeEventListener('online', this._onOnline);
    globalThis.removeEventListener('offline', this._onOffline);
    document.removeEventListener('pointerdown', this._onDocumentPointer, true);
  }

  applyAttributes() {
    if (this.hasAttribute('placement')) this.ui.placement = this.getAttribute('placement') === 'left' ? 'left' : 'right';
    if (this.hasAttribute('theme')) this.ui.theme = this.getAttribute('theme') === 'light' ? 'light' : 'dark';
    if (this.getAttribute('placement') !== this.ui.placement) this.setAttribute('placement', this.ui.placement);
    if (this.getAttribute('theme') !== this.ui.theme) this.setAttribute('theme', this.ui.theme);
    this.style.setProperty('--drawer-width', `${clamp(this.ui.width, 420, Math.max(420, globalThis.innerWidth - 24))}px`);
  }

  configure({ adapter, scope, capabilities, userId, instanceId, theme, placement, contextAction = false } = {}) {
    if (instanceId) this.instanceId = String(instanceId);
    if (userId) this.userId = String(userId);
    if (adapter) this.adapter = adapter;
    if (capabilities) this.capabilities = { ...DEFAULT_CAPABILITIES, ...capabilities };
    if (scope) this.scope = this.normalizeScope(scope);
    this.restoreUiState();
    if (theme) this.ui.theme = theme === 'light' ? 'light' : 'dark';
    if (placement) this.ui.placement = placement === 'left' ? 'left' : 'right';
    this.applyAttributes();
    if (this.els) {
      this.els.contextButton.hidden = !contextAction;
      this.renderAll();
    }
    return this.initializeAdapter();
  }

  async initializeAdapter() {
    if (!this.adapter) {
      this.configurationBanner = 'No chat adapter is configured.';
      this.renderBanner();
      return;
    }
    try {
      if (this.adapter.getCapabilities) {
        const adapterCaps = await this.adapter.getCapabilities();
        this.capabilities = { ...this.capabilities, ...adapterCaps };
      }
      this.configurationBanner = null;
      await Promise.all([this.loadThreads(), this.loadModels()]);
    } catch (error) {
      this.handleGlobalError(error);
    }
    this.renderAll();
  }

  normalizeScope(scope) {
    if (!scope?.id) throw new TypeError('Chat scope requires a non-empty id.');
    return {
      id: String(scope.id), type: scope.type || 'workspace', title: scope.title || '', surface: scope.surface || '', activeEntityId: scope.activeEntityId ?? null
    };
  }

  open() {
    this.ui.open = true;
    this.ui.minimized = false;
    this.persistUiState();
    this.renderVisibility();
    queueMicrotask(() => this.focusComposer());
    this.dispatchWidgetEvent('writer-chat:open', { scopeId: this.scope.id });
  }

  close() {
    this.saveActiveDraft();
    this.ui.open = false;
    this.ui.minimized = false;
    this.persistUiState();
    this.closeTransientUi();
    this.renderVisibility();
    queueMicrotask(() => this.els.launcher?.focus());
    this.dispatchWidgetEvent('writer-chat:close', { scopeId: this.scope.id });
  }

  toggle() { this.ui.open ? this.close() : this.open(); }

  minimize() {
    this.saveActiveDraft();
    this.ui.open = true;
    this.ui.minimized = true;
    this.ui.maximized = false;
    this.persistUiState();
    this.renderVisibility();
    this.dispatchWidgetEvent('writer-chat:minimize', { scopeId: this.scope.id });
  }

  maximize() {
    this.ui.open = true;
    this.ui.minimized = false;
    this.ui.maximized = true;
    this.persistUiState();
    this.renderVisibility();
    this.dispatchWidgetEvent('writer-chat:maximize', { scopeId: this.scope.id });
  }

  restore() {
    this.ui.open = true;
    this.ui.minimized = false;
    this.ui.maximized = false;
    this.persistUiState();
    this.renderVisibility();
    queueMicrotask(() => this.focusComposer());
  }

  focusComposer() { this.els?.composer?.focus({ preventScroll: true }); }

  async setScope(scope) {
    const next = this.normalizeScope(scope);
    if (next.id === this.scope.id && next.type === this.scope.type) {
      this.scope = next;
      this.renderHeader();
      return;
    }
    const previous = this.scope;
    this.saveActiveDraft();
    if (this.activeThreadId) this.scrollPositions.set(this.threadKey(this.activeThreadId), this.els.timeline.scrollTop);
    this.scope = next;
    this.activeThreadId = null;
    this.threads = [];
    this.searchQuery = '';
    if (this.els) {
      this.els.search.value = '';
      this.els.timeline.innerHTML = '';
    }
    this.restoreUiState();
    this.renderAll();
    await this.loadThreads();
    this.dispatchWidgetEvent('writer-chat:scope-change', { previousScope: previous, scope: next });
  }

  setDraft(text, { mode = 'replace', send = false } = {}) {
    if (send) throw new Error('setDraft() never sends automatically. Call send() explicitly after user confirmation.');
    const current = this.els?.composer?.value || this.getDraft(this.activeThreadId);
    const next = mode === 'append' ? `${current}${current && text ? '\n' : ''}${String(text ?? '')}` : String(text ?? '');
    this.setComposerValue(next);
    this.saveActiveDraft();
    this.open();
  }

  hasPendingWork() {
    return this.streams.size > 0 || [...this.drafts.values()].some(Boolean) || [...this.attachmentsByThread.values()].some(list => list?.length);
  }

  getState() {
    return {
      version: VERSION,
      open: this.ui.open,
      minimized: this.ui.minimized,
      maximized: this.ui.maximized,
      placement: this.ui.placement,
      width: this.ui.width,
      theme: this.ui.theme,
      railVisible: this.ui.railVisible,
      scope: { ...this.scope },
      activeThreadId: this.activeThreadId,
      threadCount: this.threads.length,
      streamingThreadIds: [...new Set([...this.streams.values()].map(stream => stream.threadId))],
      pendingWork: this.hasPendingWork()
    };
  }

  destroy() {
    for (const stream of this.streams.values()) stream.controller.abort();
    this.streams.clear();
    this.unbindEvents();
    this.destroyed = true;
    this.remove();
  }

  storagePrefix() {
    return `writer-chat:${this.instanceId}:${this.userId}`;
  }

  storageKey(kind, threadId = '') {
    const scopeId = encodeURIComponent(this.scope?.id || 'default');
    return `${this.storagePrefix()}:${scopeId}:${kind}${threadId ? `:${encodeURIComponent(threadId)}` : ''}`;
  }

  threadKey(threadId) { return `${this.scope.id}:${threadId || '__new__'}`; }

  safeStorageGet(key) {
    try { return localStorage.getItem(key); } catch { return null; }
  }

  safeStorageSet(key, value) {
    try { localStorage.setItem(key, value); } catch { /* storage may be unavailable */ }
  }

  safeStorageRemove(key) {
    try { localStorage.removeItem(key); } catch { /* storage may be unavailable */ }
  }

  restoreUiState() {
    const raw = this.safeStorageGet(`${this.storagePrefix()}:ui`);
    if (raw) {
      try {
        const saved = JSON.parse(raw);
        this.ui = { ...this.ui, ...saved };
      } catch { /* ignore corrupt preferences */ }
    }
    const active = this.safeStorageGet(this.storageKey('active-thread'));
    if (active) this.activeThreadId = active;
    const draftIndex = this.safeStorageGet(this.storageKey('draft-index'));
    if (draftIndex) {
      try {
        for (const threadId of JSON.parse(draftIndex)) {
          const value = this.safeStorageGet(this.storageKey('draft', threadId));
          if (value !== null) this.drafts.set(this.threadKey(threadId === '__new__' ? null : threadId), value);
        }
      } catch { /* ignore corrupt draft index */ }
    }
  }

  persistUiState() {
    this.safeStorageSet(`${this.storagePrefix()}:ui`, JSON.stringify({
      open: this.ui.open,
      minimized: this.ui.minimized,
      maximized: this.ui.maximized,
      railVisible: this.ui.railVisible,
      width: this.ui.width,
      placement: this.ui.placement,
      theme: this.ui.theme,
      archivedVisible: this.ui.archivedVisible
    }));
    if (this.activeThreadId) this.safeStorageSet(this.storageKey('active-thread'), this.activeThreadId);
    else this.safeStorageRemove(this.storageKey('active-thread'));
  }

  persistDraft(threadId, value) {
    const key = threadId || '__new__';
    const mapKey = this.threadKey(threadId);
    if (value) {
      this.drafts.set(mapKey, value);
      this.safeStorageSet(this.storageKey('draft', key), value);
    } else {
      this.drafts.delete(mapKey);
      this.safeStorageRemove(this.storageKey('draft', key));
    }
    const ids = [...this.drafts.keys()]
      .filter(valueKey => valueKey.startsWith(`${this.scope.id}:`))
      .map(valueKey => valueKey.slice(this.scope.id.length + 1))
      .map(id => id === '__new__' ? '__new__' : id);
    this.safeStorageSet(this.storageKey('draft-index'), JSON.stringify(ids));
    this.dispatchWidgetEvent('writer-chat:dirty-change', { dirty: this.hasPendingWork(), threadId });
  }

  getDraft(threadId) { return this.drafts.get(this.threadKey(threadId)) || ''; }

  saveActiveDraft() {
    if (!this.els?.composer) return;
    this.persistDraft(this.activeThreadId, this.els.composer.value);
  }

  async loadThreads({ append = false } = {}) {
    if (!this.adapter?.listThreads) return;
    this.loadThreadsAbort?.abort();
    this.loadThreadsAbort = new AbortController();
    const scopeId = this.scope.id;
    this.threadLoading = true;
    this.renderThreads();
    try {
      const result = await this.adapter.listThreads({
        scope: { ...this.scope },
        scopeId,
        query: this.searchQuery,
        archived: this.ui.archivedVisible,
        cursor: append ? this.threadCursor : undefined,
        limit: 50,
        signal: this.loadThreadsAbort.signal
      });
      if (scopeId !== this.scope.id) return;
      const items = Array.isArray(result) ? result : result?.items || [];
      this.threads = append ? [...this.threads, ...items] : items;
      this.threadCursor = result?.nextCursor || null;
      this.sortThreads();
      const preferred = this.activeThreadId && this.threads.some(thread => thread.id === this.activeThreadId)
        ? this.activeThreadId
        : this.threads.find(thread => !thread.archivedAt)?.id || this.threads[0]?.id || null;
      if (preferred && preferred !== this.activeThreadId) await this.selectThread(preferred, { preserveCurrent: false });
      else if (preferred && !this.messagesByThread.has(this.threadKey(preferred))) await this.loadMessages(preferred);
      else if (!preferred) {
        this.activeThreadId = null;
        this.setComposerValue(this.getDraft(null));
      }
    } catch (error) {
      if (error?.name !== 'AbortError') this.handleGlobalError(error);
    } finally {
      if (scopeId === this.scope.id) {
        this.threadLoading = false;
        this.renderThreads();
        this.renderConversation();
        this.renderHeader();
      }
    }
  }

  async loadModels() {
    if (!this.capabilities.modelCatalog || !this.adapter?.listModels) {
      this.modelCatalogState = 'unavailable';
      this.models = [];
      this.renderHeader();
      return;
    }
    this.modelCatalogState = 'loading';
    this.renderModels();
    try {
      const result = await this.adapter.listModels({ scope: { ...this.scope } });
      this.models = Array.isArray(result) ? result : result?.items || [];
      this.modelCatalogState = this.models.length ? 'ready' : 'empty';
    } catch (error) {
      this.models = [];
      this.modelCatalogState = 'error';
      this.toast(`Model catalog unavailable: ${normalizeError(error).message}`);
    }
    this.renderModels();
    this.renderHeader();
  }

  async loadMessages(threadId, { force = false, older = false } = {}) {
    if (!threadId || !this.adapter?.listMessages) return;
    const key = this.threadKey(threadId);
    if (!force && !older && this.messagesByThread.has(key)) {
      this.renderConversation();
      return;
    }
    this.loadMessagesAbort?.abort();
    this.loadMessagesAbort = new AbortController();
    const scopeId = this.scope.id;
    this.messageLoading = true;
    this.renderConversation();
    try {
      const result = await this.adapter.listMessages({ scopeId, threadId, limit: 100, cursor: older ? this.messageCursors.get(key) : undefined, signal: this.loadMessagesAbort.signal });
      if (scopeId !== this.scope.id) return;
      const items = Array.isArray(result) ? result : result?.items || [];
      const sorted = items.slice().sort((a, b) => (a.sequence ?? 0) - (b.sequence ?? 0));
      this.messagesByThread.set(key, older ? [...sorted, ...(this.messagesByThread.get(key) || [])] : sorted);
      this.messageCursors.set(key, result?.nextCursor || null);
      this.renderConversation();
      queueMicrotask(() => this.restoreReadingPosition(threadId));
    } catch (error) {
      if (error?.name !== 'AbortError') {
        const normalized = normalizeError(error);
        this.messagesByThread.set(key, [{
          id: createId('notice'), threadId, role: 'notice', content: normalized.message, sequence: 0, status: 'failed', createdAt: new Date().toISOString(), error: normalized
        }]);
      }
    } finally {
      if (scopeId === this.scope.id) {
        this.messageLoading = false;
        this.renderConversation();
      }
    }
  }

  async selectThread(threadId, { preserveCurrent = true } = {}) {
    if (!threadId || threadId === this.activeThreadId) return;
    if (preserveCurrent) {
      this.saveActiveDraft();
      if (this.activeThreadId && this.els?.timeline) this.scrollPositions.set(this.threadKey(this.activeThreadId), this.els.timeline.scrollTop);
    }
    this.activeThreadId = threadId;
    this.safeStorageSet(this.storageKey('active-thread'), threadId);
    this.closeTransientUi();
    this.setComposerValue(this.getDraft(threadId));
    this.renderAll();
    await this.loadMessages(threadId);
    this.dispatchWidgetEvent('writer-chat:thread-change', { scopeId: this.scope.id, threadId });
  }

  async createThread({ title = 'New chat', select = true, modelId } = {}) {
    if (!this.adapter?.createThread) {
      this.handleGlobalError({ code: 'adapter_missing', message: 'The adapter cannot create threads.', retryable: false });
      return null;
    }
    try {
      const thread = await this.adapter.createThread({
        scope: { ...this.scope }, scopeId: this.scope.id, title, modelId: modelId || this.currentThread()?.modelId || 'auto', settings: { ...DEFAULT_SETTINGS }
      });
      this.threads.unshift(thread);
      this.sortThreads();
      this.messagesByThread.set(this.threadKey(thread.id), []);
      if (select) {
        this.saveActiveDraft();
        const unsaved = this.getDraft(null);
        this.activeThreadId = thread.id;
        this.safeStorageSet(this.storageKey('active-thread'), thread.id);
        if (unsaved) {
          this.persistDraft(thread.id, unsaved);
          this.persistDraft(null, '');
        }
        this.setComposerValue(this.getDraft(thread.id));
      }
      this.renderAll();
      this.dispatchWidgetEvent('writer-chat:thread-create', { scopeId: this.scope.id, thread });
      return thread;
    } catch (error) {
      this.handleGlobalError(error);
      return null;
    }
  }

  currentThread() { return this.threads.find(thread => thread.id === this.activeThreadId) || null; }

  currentMessages() { return this.activeThreadId ? this.messagesByThread.get(this.threadKey(this.activeThreadId)) || [] : []; }

  setMessages(threadId, messages) {
    this.messagesByThread.set(this.threadKey(threadId), messages.slice().sort((a, b) => (a.sequence ?? 0) - (b.sequence ?? 0)));
    if (threadId === this.activeThreadId) this.renderConversation();
  }

  sortThreads() {
    this.threads.sort((a, b) => {
      if (Boolean(a.pinned) !== Boolean(b.pinned)) return a.pinned ? -1 : 1;
      return new Date(b.updatedAt || 0) - new Date(a.updatedAt || 0);
    });
  }

  updateThreadLocal(threadId, patch) {
    const index = this.threads.findIndex(thread => thread.id === threadId);
    if (index >= 0) {
      this.threads[index] = { ...this.threads[index], ...patch };
      this.sortThreads();
      this.renderThreads();
      this.renderHeader();
    }
  }

  renderAll() {
    if (!this.els) return;
    this.renderVisibility();
    this.renderHeader();
    this.renderBanner();
    this.renderThreads();
    this.renderConversation();
    this.renderComposer();
    this.renderModels();
  }

  renderVisibility() {
    if (!this.els) return;
    this.els.launcher.hidden = this.ui.open;
    this.els.launcher.setAttribute('aria-expanded', String(this.ui.open));
    this.els.drawer.hidden = !this.ui.open;
    this.els.drawer.classList.toggle('minimized', this.ui.minimized);
    this.els.drawer.classList.toggle('maximized', this.ui.maximized);
    this.els.rail.hidden = !this.ui.railVisible;
    this.els.railToggle.setAttribute('aria-expanded', String(this.ui.railVisible));
    this.els.maximizeButton.dataset.action = this.ui.maximized ? 'restore' : 'maximize';
    this.els.maximizeButton.setAttribute('aria-label', this.ui.maximized ? 'Restore chat size' : 'Maximize chat');
    this.els.maximizeButton.innerHTML = icon(this.ui.maximized ? 'restore' : 'maximize');
    const activeStreams = this.streams.size;
    this.els.launcherStatus.hidden = !activeStreams && !this.configurationBanner;
    this.els.launcherStatus.className = `launcher-status${activeStreams ? ' streaming' : this.configurationBanner ? ' error' : ''}`;
  }

  renderHeader() {
    if (!this.els) return;
    const thread = this.currentThread();
    const model = this.models.find(item => item.id === thread?.modelId);
    this.els.threadTitle.textContent = thread?.title || 'Writer AI';
    this.els.currentModel.textContent = model?.name || thread?.modelId || 'Automatic';
    this.els.modelProvider.textContent = model?.provider ? `· ${model.provider}` : '';
    this.els.scopeTitle.textContent = this.scope.title || this.scope.id;
    this.els.scopeSurface.textContent = this.scope.surface ? `· ${this.scope.surface}` : '';
    this.renderConnection();
  }

  renderConnection() {
    if (!this.els) return;
    const active = this.activeThreadId && [...this.streams.values()].some(stream => stream.threadId === this.activeThreadId);
    this.els.connectionDot.className = `connection-dot${!this.online ? ' offline' : active ? ' streaming' : ''}`;
    this.els.connectionLabel.textContent = !this.online ? 'Offline' : active ? 'Streaming' : 'Ready';
  }

  renderBanner() {
    if (!this.els) return;
    const text = !this.online ? 'You are offline. Drafts remain available, and sending will resume when connectivity returns.' : this.configurationBanner;
    this.els.banner.hidden = !text;
    this.els.bannerText.textContent = text || '';
  }

  renderThreads() {
    if (!this.els) return;
    if (this.threadLoading && !this.threads.length) {
      this.els.threadList.innerHTML = '<div class="loading-skeleton" aria-label="Loading conversations"><span></span><span></span><span></span><span></span></div>';
      return;
    }
    if (!this.threads.length) {
      const label = this.searchQuery ? 'No conversations match this search.' : this.ui.archivedVisible ? 'No archived conversations.' : 'No conversations yet.';
      this.els.threadList.innerHTML = `<div class="empty-state"><strong>${escapeHtml(label)}</strong><p>${this.searchQuery ? 'Try another title or model name.' : 'Create a chat and your conversations will appear here.'}</p></div>`;
      return;
    }
    const visible = this.threads.filter(thread => this.ui.archivedVisible ? Boolean(thread.archivedAt) : !thread.archivedAt);
    const pinned = visible.filter(thread => thread.pinned);
    const recent = visible.filter(thread => !thread.pinned);
    const section = (title, items) => items.length ? `<div class="thread-section-title">${title}</div>${items.map(thread => this.threadHtml(thread)).join('')}` : '';
    this.els.threadList.innerHTML = `${section('Pinned', pinned)}${section(this.ui.archivedVisible ? 'Archived' : 'Recent', recent)}${this.threadCursor ? '<button class="text-button" style="width:100%" data-action="load-more-threads">Load more</button>' : ''}`;
  }

  threadHtml(thread) {
    const streaming = [...this.streams.values()].some(stream => stream.threadId === thread.id);
    const indicator = streaming ? '<span class="thread-indicator streaming" aria-label="Streaming"></span>' : thread.error ? '<span class="thread-indicator error" aria-label="Error"></span>' : thread.unreadCount ? '<span class="thread-indicator" aria-label="Unread"></span>' : '';
    return `<div class="thread-item${thread.id === this.activeThreadId ? ' active' : ''}" role="listitem" data-thread-id="${escapeHtml(thread.id)}" tabindex="0" aria-current="${thread.id === this.activeThreadId ? 'true' : 'false'}">
      <div class="thread-copy">
        <div class="thread-title">${thread.pinned ? icon('pin') : ''}<span>${escapeHtml(thread.title || 'Untitled chat')}</span>${indicator}</div>
        <div class="thread-meta"><span>${escapeHtml(relativeTime(thread.updatedAt))}</span><span>·</span><span>${escapeHtml(thread.modelId || 'auto')}</span></div>
      </div>
      <button class="icon-button thread-menu-button" type="button" data-action="thread-menu" data-thread-id="${escapeHtml(thread.id)}" aria-label="Actions for ${escapeHtml(thread.title || 'Untitled chat')}" aria-haspopup="menu">${icon('more')}</button>
    </div>`;
  }

  visibleMessages(messages) {
    const groups = new Map();
    for (const message of messages) {
      if (message.variantGroupId) {
        if (!groups.has(message.variantGroupId)) groups.set(message.variantGroupId, []);
        groups.get(message.variantGroupId).push(message);
      }
    }
    const hidden = new Set();
    for (const [groupId, variants] of groups) {
      variants.sort((a, b) => (a.variantIndex ?? 1) - (b.variantIndex ?? 1));
      const selected = this.selectedVariants.get(groupId) ?? variants.length - 1;
      variants.forEach((message, index) => { if (index !== selected) hidden.add(message.id); });
    }
    return messages.filter(message => !hidden.has(message.id));
  }

  renderConversation() {
    if (!this.els) return;
    if (this.messageLoading && !this.currentMessages().length) {
      this.els.timeline.innerHTML = '<div class="loading-skeleton" aria-label="Loading messages"><span></span><span></span><span></span></div>';
      return;
    }
    const messages = this.currentMessages();
    if (!this.activeThreadId || !messages.length) {
      this.els.timeline.innerHTML = `<div class="empty-state"><strong>Start a new conversation</strong><p>Ask for an outline critique, review continuity questions, or paste context you selected deliberately.</p><button class="primary-button" type="button" data-action="focus-composer">Write a message</button></div>`;
      this.els.scrollButton.hidden = true;
      return;
    }
    const nearBottom = this.isNearBottom();
    const beforeHeight = this.els.timeline.scrollHeight;
    let lastDate = '';
    const olderButton = this.messageCursors.get(this.threadKey(this.activeThreadId)) ? '<button class="text-button" style="display:flex;margin:0 auto 14px" data-action="load-older-messages">Load older messages</button>' : '';
    const html = olderButton + this.visibleMessages(messages).map(message => {
      const date = formatDate(message.createdAt);
      const separator = date && date !== lastDate ? `<div class="date-separator"><span>${escapeHtml(date)}</span></div>` : '';
      lastDate = date;
      return `${separator}${this.messageHtml(message, messages)}`;
    }).join('');
    this.els.timeline.innerHTML = html;
    if (nearBottom) queueMicrotask(() => this.scrollToBottom(false));
    else if (this.els.timeline.scrollHeight !== beforeHeight) this.els.scrollButton.hidden = false;
  }

  messageHtml(message, allMessages) {
    const role = message.role || 'notice';
    const status = message.status || 'complete';
    const content = role === 'notice' ? `<p>${escapeHtml(message.content || '')}</p>` : markdownToHtml(message.content || '');
    const streamCursor = status === 'streaming' ? '<span class="streaming-cursor" aria-hidden="true"></span>' : '';
    const savedState = message.metadata?.persistenceFailed ? ' unsaved' : '';
    const variantNav = this.variantNavigationHtml(message, allMessages);
    const usage = message.usage?.totalTokens ? `${message.usage.totalTokens} tokens` : '';
    const meta = [formatTime(message.createdAt), message.modelId, status !== 'complete' ? status : '', message.editedAt ? 'edited' : '', usage].filter(Boolean);
    const error = message.error ? `<details class="inline-error"><summary>${escapeHtml(message.error.message || 'Request failed')}</summary><pre>${escapeHtml(JSON.stringify(message.error.details ?? message.error, null, 2))}</pre></details>` : '';
    return `<article class="message ${escapeHtml(role)} ${escapeHtml(status)}${savedState}" data-message-id="${escapeHtml(message.id)}" tabindex="-1">
      <div class="message-row">
        <div class="avatar" aria-hidden="true">${role === 'assistant' ? 'AI' : role === 'user' ? 'You' : role.slice(0, 2).toUpperCase()}</div>
        <div class="message-main">
          <div class="message-bubble"><div class="message-content">${content}${streamCursor}</div>${error}</div>
          <div class="message-meta"><span>${escapeHtml(meta.join(' · '))}</span>${variantNav}</div>
          ${this.messageActionsHtml(message)}
        </div>
      </div>
    </article>`;
  }

  variantNavigationHtml(message, allMessages) {
    if (!message.variantGroupId) return '';
    const variants = allMessages.filter(item => item.variantGroupId === message.variantGroupId).sort((a, b) => (a.variantIndex ?? 1) - (b.variantIndex ?? 1));
    if (variants.length < 2) return '';
    const selected = this.selectedVariants.get(message.variantGroupId) ?? variants.findIndex(item => item.id === message.id);
    return `<span class="variant-nav" aria-label="Response variant ${selected + 1} of ${variants.length}"><button class="icon-button" type="button" data-action="variant-prev" data-group-id="${escapeHtml(message.variantGroupId)}" aria-label="Previous response variant">${icon('chevronLeft')}</button><span>${selected + 1} / ${variants.length}</span><button class="icon-button" type="button" data-action="variant-next" data-group-id="${escapeHtml(message.variantGroupId)}" aria-label="Next response variant">${icon('chevronRight')}</button></span>`;
  }

  messageActionsHtml(message) {
    const buttons = [];
    if (this.capabilities.messageCopy) buttons.push(this.actionButton('copy-message', 'Copy', 'copy', message.id));
    buttons.push(this.actionButton('quote-message', 'Quote into composer', 'quote', message.id));
    if (this.capabilities.scratchpadSave && this.adapter?.saveMessageExternally) buttons.push(this.actionButton('save-message', 'Save to Scratchpad', 'save', message.id));
    if (message.role === 'user') {
      if (this.capabilities.editMessage) buttons.push(this.actionButton('edit-message', 'Edit and resend', 'edit', message.id));
      buttons.push(this.actionButton('resend-message', 'Resend', 'retry', message.id));
      if (this.capabilities.branching) buttons.push(this.actionButton('branch-message', 'Branch from message', 'branch', message.id));
    }
    if (message.role === 'assistant') {
      if (this.capabilities.regenerate) buttons.push(this.actionButton('regenerate-message', 'Regenerate', 'retry', message.id));
      if (message.status === 'failed' || message.status === 'stopped') buttons.push(this.actionButton('retry-message', 'Retry', 'retry', message.id));
      if (this.capabilities.messageFeedback && this.adapter?.submitFeedback) {
        buttons.push(this.actionButton('feedback-up', 'Helpful', 'thumbsUp', message.id));
        buttons.push(this.actionButton('feedback-down', 'Not helpful', 'thumbsDown', message.id));
      }
      if (this.capabilities.branching) buttons.push(this.actionButton('branch-message', 'Branch from response', 'branch', message.id));
    }
    buttons.push(this.actionButton('message-menu', 'More message actions', 'more', message.id));
    return `<div class="message-actions" aria-label="Message actions">${buttons.join('')}</div>`;
  }

  actionButton(action, label, iconName, messageId) {
    return `<button class="icon-button" type="button" data-action="${action}" data-message-id="${escapeHtml(messageId)}" aria-label="${escapeHtml(label)}" title="${escapeHtml(label)}">${icon(iconName)}</button>`;
  }

  renderComposer() {
    if (!this.els) return;
    const activeStream = this.activeThreadId && [...this.streams.values()].find(stream => stream.threadId === this.activeThreadId);
    this.els.send.dataset.action = activeStream ? 'stop' : 'send';
    this.els.send.classList.toggle('stop', Boolean(activeStream));
    this.els.send.innerHTML = icon(activeStream ? 'stop' : 'send');
    this.els.send.setAttribute('aria-label', activeStream ? 'Stop generation' : 'Send message');
    this.els.send.disabled = !activeStream && (!this.online || !this.els.composer.value.trim() || this.sendingLocks.has(this.activeThreadId || '__new__'));
    this.els.attachmentButton.hidden = !this.capabilities.attachments || !this.adapter?.uploadAttachment;
    this.renderAttachments();
    this.updateComposerMetrics();
  }

  renderAttachments() {
    const list = this.attachmentsByThread.get(this.threadKey(this.activeThreadId)) || [];
    this.els.attachmentList.hidden = !list.length;
    this.els.attachmentList.innerHTML = list.map((attachment, index) => `<span class="attachment-chip">${icon('paperclip')}<span>${escapeHtml(attachment.name || 'Attachment')}</span><button class="icon-button" type="button" data-action="remove-attachment" data-index="${index}" aria-label="Remove ${escapeHtml(attachment.name || 'attachment')}">${icon('close')}</button></span>`).join('');
  }

  renderModels() {
    if (!this.els) return;
    const query = this.els.modelSearch?.value?.trim().toLowerCase() || '';
    if (this.modelCatalogState === 'loading') {
      this.els.modelList.innerHTML = '<div class="empty-state"><p>Loading model catalog…</p></div>';
      return;
    }
    const automatic = { id: 'auto', name: 'Automatic routing', provider: 'Adapter', description: 'Let the adapter select an available model.' };
    const filtered = [automatic, ...this.models].filter(model => !query || `${model.name} ${model.id} ${model.provider || ''}`.toLowerCase().includes(query));
    if (!filtered.length) {
      this.els.modelList.innerHTML = '<div class="empty-state"><p>No matching models.</p></div>';
      return;
    }
    const groups = new Map();
    for (const model of filtered) {
      const provider = model.provider || 'Other';
      if (!groups.has(provider)) groups.set(provider, []);
      groups.get(provider).push(model);
    }
    const current = this.currentThread()?.modelId || 'auto';
    this.els.modelList.innerHTML = [...groups].map(([provider, models]) => `<div class="model-group-title">${escapeHtml(provider)}</div>${models.map(model => `<button class="model-option${model.id === current ? ' active' : ''}" type="button" role="option" aria-selected="${model.id === current}" data-action="select-model" data-model-id="${escapeHtml(model.id)}" ${model.available === false ? 'disabled' : ''}><div class="model-option-copy"><strong>${escapeHtml(model.name || model.id)}</strong><small>${escapeHtml(model.id)}${model.contextWindow ? ` · ${Number(model.contextWindow).toLocaleString()} context` : ''}</small></div>${model.free === true ? '<span class="badge">Free</span>' : model.free === false ? '<span class="badge">Paid</span>' : ''}</button>`).join('')}`).join('');
  }

  async handleClick(event) {
    if (this.handleDialogClick(event)) return;
    const button = event.target.closest('[data-action]');
    if (!button) {
      const item = event.target.closest('.thread-item');
      if (item && !event.target.closest('button')) await this.selectThread(item.dataset.threadId);
      return;
    }
    const action = button.dataset.action;
    const messageId = button.dataset.messageId;
    const threadId = button.dataset.threadId;
    const actions = {
      'toggle-widget': () => this.toggle(),
      close: () => this.close(),
      minimize: () => this.minimize(),
      maximize: () => this.maximize(),
      restore: () => this.restore(),
      'toggle-rail': () => this.toggleRail(),
      'new-thread': () => this.newChat(),
      'toggle-archived': () => this.toggleArchived(),
      'load-more-threads': () => this.loadThreads({ append: true }),
      'load-older-messages': () => this.loadMessages(this.activeThreadId, { older: true }),
      'thread-menu': () => this.openThreadMenu(threadId, button),
      send: () => this.send(),
      stop: () => this.stopActiveStream(),
      'focus-composer': () => this.focusComposer(),
      'scroll-bottom': () => this.scrollToBottom(),
      'open-models': () => this.togglePopover(this.els.modelPopover, button),
      'open-settings': () => this.openSettings(button),
      'open-overflow': () => this.openOverflowMenu(button),
      'select-model': () => this.selectModel(button.dataset.modelId),
      'clear-draft': () => this.clearDraft(),
      attach: () => this.els.attachmentInput.click(),
      'request-context': () => this.dispatchWidgetEvent('writer-chat:request-context', { scope: { ...this.scope }, threadId: this.activeThreadId }),
      'remove-attachment': () => this.removeAttachment(Number(button.dataset.index)),
      'copy-message': () => this.copyMessage(messageId),
      'quote-message': () => this.quoteMessage(messageId),
      'save-message': () => this.saveMessage(messageId),
      'edit-message': () => this.editMessage(messageId),
      'resend-message': () => this.resendMessage(messageId),
      'branch-message': () => this.branchFromMessage(messageId),
      'regenerate-message': () => this.regenerateMessage(messageId),
      'retry-message': () => this.retryMessage(messageId),
      'feedback-up': () => this.submitFeedback(messageId, 'up'),
      'feedback-down': () => this.submitFeedback(messageId, 'down'),
      'message-menu': () => this.openMessageMenu(messageId, button),
      'variant-prev': () => this.changeVariant(button.dataset.groupId, -1),
      'variant-next': () => this.changeVariant(button.dataset.groupId, 1),
      'copy-code': () => this.copyCode(button),
      'save-settings': () => this.saveSettings(),
      'reset-settings': () => this.resetSettings(),
      'export-conversation': () => this.exportConversation(),
      'copy-conversation': () => this.copyConversation(),
      'save-conversation': () => this.saveConversation(),
      'toggle-theme': () => this.toggleTheme(),
      'toggle-placement': () => this.togglePlacement(),
      'close-transient': () => this.closeTransientUi(),
      'retry-persist': () => this.retryPersistence(messageId)
    };
    if (actions[action]) {
      event.preventDefault();
      event.stopPropagation();
      await actions[action]();
      return;
    }
    if (action?.startsWith('thread-')) await this.handleThreadAction(action, threadId || this.menuContext?.threadId);
    if (action?.startsWith('message-')) await this.handleMessageMenuAction(action, messageId || this.menuContext?.messageId);
  }

  handleInput(event) {
    if (event.target === this.els.composer) {
      this.autoGrowComposer();
      this.saveActiveDraft();
      this.renderComposer();
    } else if (event.target === this.els.search) {
      this.searchQuery = event.target.value.trim();
      this._searchDebounced();
    } else if (event.target === this.els.modelSearch) {
      this.renderModels();
    } else if (event.target === this.els.attachmentInput) {
      this.handleFiles([...event.target.files]);
      event.target.value = '';
    }
  }

  handleKeyDown(event) {
    if (!this.els.dialogBackdrop.hidden && event.key === 'Tab') {
      const focusable = [...this.els.dialogBackdrop.querySelectorAll('button:not([disabled]), input:not([disabled]), textarea:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])')];
      if (focusable.length) {
        const first = focusable[0], last = focusable[focusable.length - 1];
        if (event.shiftKey && this.shadowRoot.activeElement === first) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && this.shadowRoot.activeElement === last) { event.preventDefault(); first.focus(); }
      }
      return;
    }
    if (event.target === this.els.composer) {
      if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) {
        event.preventDefault();
        this.send();
      } else if (event.key === 'Escape') {
        this.closeTransientUi();
      }
      event.stopPropagation();
      return;
    }
    if (event.key === 'Escape') {
      if (!this.els.dialogBackdrop.hidden) this.resolveDialog(null);
      else this.closeTransientUi();
      event.stopPropagation();
    }
    if ((event.key === 'Enter' || event.key === ' ') && event.target.classList?.contains('thread-item')) {
      event.preventDefault();
      this.selectThread(event.target.dataset.threadId);
    }
    if (event.target === this.els.resizeHandle && ['ArrowLeft', 'ArrowRight'].includes(event.key)) {
      const direction = event.key === 'ArrowLeft' ? -1 : 1;
      const placementMultiplier = this.ui.placement === 'right' ? -1 : 1;
      this.ui.width = clamp(this.ui.width + direction * placementMultiplier * 20, 420, Math.max(420, innerWidth - 24));
      this.style.setProperty('--drawer-width', `${this.ui.width}px`);
      this.persistUiState();
    }
  }

  handleOutsidePointer(event) {
    const path = event.composedPath();
    if (!path.includes(this) && this.ui.open) this.closeTransientUi();
  }

  handleTimelineScroll() {
    if (!this.activeThreadId) return;
    this.scrollPositions.set(this.threadKey(this.activeThreadId), this.els.timeline.scrollTop);
    this.els.scrollButton.hidden = this.isNearBottom();
  }

  isNearBottom() {
    const el = this.els?.timeline;
    if (!el) return true;
    return el.scrollHeight - el.scrollTop - el.clientHeight < 90;
  }

  scrollToBottom(smooth = true) {
    this.els.timeline.scrollTo({ top: this.els.timeline.scrollHeight, behavior: smooth ? 'smooth' : 'auto' });
    this.els.scrollButton.hidden = true;
  }

  restoreReadingPosition(threadId) {
    const saved = this.scrollPositions.get(this.threadKey(threadId));
    if (Number.isFinite(saved)) this.els.timeline.scrollTop = saved;
    else this.scrollToBottom(false);
  }

  autoGrowComposer() {
    const composer = this.els.composer;
    composer.style.height = 'auto';
    composer.style.height = `${Math.min(composer.scrollHeight, 180)}px`;
  }

  updateComposerMetrics() {
    const length = this.els.composer.value.length;
    this.els.count.textContent = `${length.toLocaleString()} chars · ~${Math.ceil(length / 4).toLocaleString()} tokens`;
    this.els.clearDraft.hidden = length === 0;
  }

  setComposerValue(value) {
    if (!this.els?.composer) return;
    this.els.composer.value = value || '';
    this.autoGrowComposer();
    this.renderComposer();
  }

  clearDraft() {
    this.setComposerValue('');
    this.persistDraft(this.activeThreadId, '');
    this.focusComposer();
  }

  toggleRail() {
    this.ui.railVisible = !this.ui.railVisible;
    this.persistUiState();
    this.renderVisibility();
  }

  async toggleArchived() {
    this.ui.archivedVisible = !this.ui.archivedVisible;
    this.persistUiState();
    await this.loadThreads();
  }

  async newChat() {
    this.saveActiveDraft();
    this.activeThreadId = null;
    this.safeStorageRemove(this.storageKey('active-thread'));
    this.setComposerValue(this.getDraft(null));
    this.renderAll();
    if (matchMedia('(max-width: 700px)').matches) {
      this.ui.railVisible = false;
      this.renderVisibility();
    }
    this.focusComposer();
  }

  beginResize(event) {
    if (this.ui.maximized || matchMedia('(max-width: 700px)').matches) return;
    event.preventDefault();
    this.resizeState = { startX: event.clientX, startWidth: this.ui.width };
    this.els.resizeHandle.setPointerCapture?.(event.pointerId);
  }

  performResize(event) {
    if (!this.resizeState) return;
    const delta = event.clientX - this.resizeState.startX;
    const adjusted = this.ui.placement === 'right' ? -delta : delta;
    this.ui.width = clamp(this.resizeState.startWidth + adjusted, 420, Math.max(420, innerWidth - 24));
    this.style.setProperty('--drawer-width', `${this.ui.width}px`);
  }

  endResize() {
    if (!this.resizeState) return;
    this.resizeState = null;
    this.persistUiState();
  }

  positionFloating(element, anchor, { align = 'end' } = {}) {
    const rect = anchor.getBoundingClientRect();
    element.hidden = false;
    element.style.visibility = 'hidden';
    const box = element.getBoundingClientRect();
    const margin = 8;
    let left = align === 'end' ? rect.right - box.width : rect.left;
    let top = rect.bottom + 6;
    if (top + box.height > innerHeight - margin) top = Math.max(margin, rect.top - box.height - 6);
    left = clamp(left, margin, Math.max(margin, innerWidth - box.width - margin));
    element.style.left = `${left}px`;
    element.style.top = `${top}px`;
    element.style.visibility = '';
  }

  togglePopover(element, anchor) {
    const opening = element.hidden;
    this.closeTransientUi(element);
    if (opening) {
      this.positionFloating(element, anchor);
      anchor.setAttribute('aria-expanded', 'true');
      queueMicrotask(() => element.querySelector('input, button')?.focus());
    }
  }

  closeTransientUi(except = null) {
    for (const element of [this.els.menu, this.els.modelPopover, this.els.settings]) {
      if (element && element !== except) element.hidden = true;
    }
    this.shadowRoot.querySelectorAll('[aria-expanded="true"]').forEach(element => {
      if (!element.matches('[data-action="toggle-rail"]')) element.setAttribute('aria-expanded', 'false');
    });
    this.menuContext = null;
  }

  openThreadMenu(threadId, anchor) {
    const thread = this.threads.find(item => item.id === threadId);
    if (!thread) return;
    this.menuContext = { threadId };
    this.els.menu.innerHTML = `
      ${this.capabilities.threadRename ? `<button type="button" role="menuitem" data-action="thread-rename" data-thread-id="${escapeHtml(threadId)}">${icon('edit')}Rename</button>` : ''}
      ${this.capabilities.threadPin ? `<button type="button" role="menuitem" data-action="thread-pin" data-thread-id="${escapeHtml(threadId)}">${icon('pin')}${thread.pinned ? 'Unpin' : 'Pin'}</button>` : ''}
      ${this.capabilities.threadArchive ? `<button type="button" role="menuitem" data-action="thread-archive" data-thread-id="${escapeHtml(threadId)}">${icon('archive')}${thread.archivedAt ? 'Unarchive' : 'Archive'}</button>` : ''}
      ${this.capabilities.threadDuplicate && this.adapter?.duplicateThread ? `<button type="button" role="menuitem" data-action="thread-duplicate" data-thread-id="${escapeHtml(threadId)}">${icon('branch')}Duplicate</button>` : ''}
      <div class="menu-separator"></div>
      ${this.capabilities.conversationExport ? `<button type="button" role="menuitem" data-action="thread-export" data-thread-id="${escapeHtml(threadId)}">${icon('download')}Export Markdown</button>` : ''}
      ${this.capabilities.threadDelete ? `<button class="danger" type="button" role="menuitem" data-action="thread-delete" data-thread-id="${escapeHtml(threadId)}">${icon('trash')}Delete</button>` : ''}
    `;
    this.positionFloating(this.els.menu, anchor);
    queueMicrotask(() => this.els.menu.querySelector('button')?.focus());
  }

  openMessageMenu(messageId, anchor) {
    const message = this.findMessage(messageId);
    if (!message) return;
    this.menuContext = { messageId };
    this.els.menu.innerHTML = `
      <button type="button" role="menuitem" data-action="message-export" data-message-id="${escapeHtml(messageId)}">${icon('download')}Export message</button>
      ${message.metadata?.persistenceFailed ? `<button type="button" role="menuitem" data-action="message-retry-persist" data-message-id="${escapeHtml(messageId)}">${icon('save')}Retry save</button>` : ''}
      ${message.role === 'user' && this.adapter?.deleteMessage ? `<button class="danger" type="button" role="menuitem" data-action="message-delete" data-message-id="${escapeHtml(messageId)}">${icon('trash')}Delete message</button>` : ''}
    `;
    this.positionFloating(this.els.menu, anchor);
  }

  openOverflowMenu(anchor) {
    this.menuContext = { kind: 'overflow' };
    this.els.menu.innerHTML = `
      <button type="button" role="menuitem" data-action="copy-conversation">${icon('copy')}Copy conversation</button>
      ${this.capabilities.conversationExport ? `<button type="button" role="menuitem" data-action="export-conversation">${icon('download')}Export Markdown</button>` : ''}
      ${this.capabilities.scratchpadSave && this.adapter?.saveConversationExternally ? `<button type="button" role="menuitem" data-action="save-conversation">${icon('save')}Save conversation</button>` : ''}
      <div class="menu-separator"></div>
      <button type="button" role="menuitem" data-action="toggle-theme">${icon('settings')}Use ${this.ui.theme === 'dark' ? 'light' : 'dark'} theme</button>
      <button type="button" role="menuitem" data-action="toggle-placement">${icon('rail')}Dock on ${this.ui.placement === 'right' ? 'left' : 'right'}</button>
      <button type="button" role="menuitem" data-action="open-settings">${icon('settings')}Advanced settings</button>
    `;
    this.positionFloating(this.els.menu, anchor);
  }

  async handleThreadAction(action, threadId) {
    this.closeTransientUi();
    const thread = this.threads.find(item => item.id === threadId);
    if (!thread) return;
    try {
      if (action === 'thread-rename') {
        const title = await this.showDialog({
          title: 'Rename conversation',
          body: `<label for="rename-thread-input">Conversation title</label><input id="rename-thread-input" value="${escapeHtml(thread.title)}" maxlength="120">`,
          confirmLabel: 'Rename', initialFocus: '#rename-thread-input', valueSelector: '#rename-thread-input'
        });
        if (!title?.trim()) return;
        const updated = await this.adapter.updateThread(threadId, { title: title.trim() });
        this.updateThreadLocal(threadId, updated || { title: title.trim(), updatedAt: new Date().toISOString() });
      } else if (action === 'thread-pin') {
        const updated = await this.adapter.updateThread(threadId, { pinned: !thread.pinned });
        this.updateThreadLocal(threadId, updated || { pinned: !thread.pinned });
      } else if (action === 'thread-archive') {
        const archivedAt = thread.archivedAt ? null : new Date().toISOString();
        const updated = await this.adapter.updateThread(threadId, { archivedAt });
        this.updateThreadLocal(threadId, updated || { archivedAt });
        if (threadId === this.activeThreadId && archivedAt && !this.ui.archivedVisible) await this.loadThreads();
      } else if (action === 'thread-duplicate') {
        const duplicated = await this.adapter.duplicateThread(threadId);
        this.threads.unshift(duplicated);
        await this.selectThread(duplicated.id);
      } else if (action === 'thread-export') {
        await this.exportConversation(threadId);
      } else if (action === 'thread-delete') {
        const confirmed = await this.showDialog({
          title: 'Delete conversation',
          body: `Delete <strong>${escapeHtml(thread.title)}</strong>? This action cannot be undone.`,
          confirmLabel: 'Delete', danger: true
        });
        if (!confirmed) return;
        await this.adapter.deleteThread(threadId);
        this.threads = this.threads.filter(item => item.id !== threadId);
        this.messagesByThread.delete(this.threadKey(threadId));
        this.persistDraft(threadId, '');
        if (this.activeThreadId === threadId) {
          this.activeThreadId = null;
          const next = this.threads.find(item => !item.archivedAt) || this.threads[0];
          if (next) await this.selectThread(next.id, { preserveCurrent: false });
          else this.setComposerValue(this.getDraft(null));
        }
        this.renderAll();
        this.dispatchWidgetEvent('writer-chat:thread-delete', { scopeId: this.scope.id, threadId });
      }
    } catch (error) {
      this.handleGlobalError(error);
    }
  }

  async handleMessageMenuAction(action, messageId) {
    this.closeTransientUi();
    const message = this.findMessage(messageId);
    if (!message) return;
    if (action === 'message-export') this.downloadText(`message-${message.id}.md`, this.messageMarkdown(message));
    if (action === 'message-retry-persist') await this.retryPersistence(messageId);
    if (action === 'message-delete' && this.adapter?.deleteMessage) {
      const confirmed = await this.showDialog({ title: 'Delete message', body: 'Delete this message from the conversation?', confirmLabel: 'Delete', danger: true });
      if (!confirmed) return;
      await this.adapter.deleteMessage({ threadId: this.activeThreadId, messageId });
      this.setMessages(this.activeThreadId, this.currentMessages().filter(item => item.id !== messageId));
    }
  }

  showDialog({ title, body, confirmLabel = 'Save', cancelLabel = 'Cancel', danger = false, valueSelector = null, initialFocus = null } = {}) {
    if (this.dialogResolve) this.resolveDialog(null);
    this.lastFocusedBeforeDialog = this.shadowRoot.activeElement;
    this.els.dialogTitle.textContent = title || 'Confirm';
    this.els.dialogBody.innerHTML = body || '';
    this.els.dialogFooter.innerHTML = `<button class="text-button" type="button" data-dialog-action="cancel">${escapeHtml(cancelLabel)}</button><button class="${danger ? 'danger-button' : 'primary-button'}" type="button" data-dialog-action="confirm">${escapeHtml(confirmLabel)}</button>`;
    this.els.dialogBackdrop.hidden = false;
    this.els.dialogBackdrop.dataset.valueSelector = valueSelector || '';
    return new Promise(resolve => {
      this.dialogResolve = resolve;
      const focusTarget = initialFocus ? this.els.dialogBackdrop.querySelector(initialFocus) : this.els.dialogFooter.querySelector('[data-dialog-action="confirm"]');
      queueMicrotask(() => { focusTarget?.focus(); focusTarget?.select?.(); });
    });
  }

  resolveDialog(value) {
    if (!this.dialogResolve) return;
    const resolve = this.dialogResolve;
    this.dialogResolve = null;
    this.els.dialogBackdrop.hidden = true;
    this.els.dialogBody.innerHTML = '';
    this.els.dialogFooter.innerHTML = '';
    resolve(value);
    queueMicrotask(() => this.lastFocusedBeforeDialog?.focus?.());
  }

  handleDialogClick(event) {
    const action = event.target.closest('[data-dialog-action]')?.dataset.dialogAction;
    if (!action) return false;
    if (action === 'cancel') this.resolveDialog(null);
    if (action === 'confirm') {
      const selector = this.els.dialogBackdrop.dataset.valueSelector;
      const value = selector ? this.els.dialogBackdrop.querySelector(selector)?.value : true;
      this.resolveDialog(value);
    }
    return true;
  }

  openSettings(anchor) {
    if (anchor?.closest?.('.menu')) anchor = this.shadowRoot.querySelector('.header [data-action="open-settings"]') || this.els.maximizeButton;
    this.closeTransientUi(this.els.settings);
    const thread = this.currentThread();
    const settings = { ...DEFAULT_SETTINGS, ...(thread?.settings || {}) };
    this.els.settings.innerHTML = `
      <h3>Thread settings</h3>
      <div class="field-row">
        <div class="field"><label for="temperature-${this.instanceId}">Temperature</label><input id="temperature-${this.instanceId}" class="setting-temperature" type="number" min="0" max="2" step="0.1" value="${escapeHtml(settings.temperature)}" ${!this.capabilities.advancedSettings ? 'disabled' : ''}></div>
        <div class="field"><label for="max-tokens-${this.instanceId}">Maximum output tokens</label><input id="max-tokens-${this.instanceId}" class="setting-max-tokens" type="number" min="1" max="200000" step="1" value="${escapeHtml(settings.maxTokens)}" ${!this.capabilities.advancedSettings ? 'disabled' : ''}></div>
      </div>
      <div class="field"><label for="system-instruction-${this.instanceId}">System instruction</label><textarea id="system-instruction-${this.instanceId}" class="setting-system" ${!this.capabilities.advancedSettings ? 'disabled' : ''}>${escapeHtml(settings.systemInstruction || '')}</textarea></div>
      <div class="settings-footer"><button class="text-button" type="button" data-action="reset-settings">Reset defaults</button><span class="save-state">Changes apply to future requests</span><button class="primary-button" type="button" data-action="save-settings" ${thread ? '' : 'disabled'}>Save</button></div>
    `;
    this.positionFloating(this.els.settings, anchor || this.els.maximizeButton);
  }

  async saveSettings() {
    const thread = this.currentThread();
    if (!thread || !this.adapter?.updateThread) return;
    const temperature = Number(this.els.settings.querySelector('.setting-temperature')?.value);
    const maxTokens = Number(this.els.settings.querySelector('.setting-max-tokens')?.value);
    const systemInstruction = this.els.settings.querySelector('.setting-system')?.value || '';
    if (!Number.isFinite(temperature) || temperature < 0 || temperature > 2) {
      this.toast('Temperature must be between 0 and 2.');
      return;
    }
    if (!Number.isInteger(maxTokens) || maxTokens < 1 || maxTokens > 200000) {
      this.toast('Maximum output tokens must be a whole number between 1 and 200,000.');
      return;
    }
    const saveState = this.els.settings.querySelector('.save-state');
    saveState.textContent = 'Saving…';
    try {
      const settings = { ...thread.settings, temperature, maxTokens, systemInstruction };
      const updated = await this.adapter.updateThread(thread.id, { settings });
      this.updateThreadLocal(thread.id, updated || { settings });
      saveState.textContent = 'Saved';
      setTimeout(() => this.closeTransientUi(), 450);
    } catch (error) {
      saveState.textContent = 'Save failed';
      this.handleGlobalError(error);
    }
  }

  resetSettings() {
    const temperature = this.els.settings.querySelector('.setting-temperature');
    const maxTokens = this.els.settings.querySelector('.setting-max-tokens');
    const system = this.els.settings.querySelector('.setting-system');
    if (temperature) temperature.value = DEFAULT_SETTINGS.temperature;
    if (maxTokens) maxTokens.value = DEFAULT_SETTINGS.maxTokens;
    if (system) system.value = '';
  }

  async selectModel(modelId) {
    this.closeTransientUi();
    let thread = this.currentThread();
    if (!thread) thread = await this.createThread({ modelId });
    if (!thread || !this.adapter?.updateThread) return;
    try {
      const updated = await this.adapter.updateThread(thread.id, { modelId });
      this.updateThreadLocal(thread.id, updated || { modelId });
      this.rememberModel(modelId);
    } catch (error) {
      this.handleGlobalError(error);
    }
  }

  rememberModel(modelId) {
    const key = `${this.storagePrefix()}:recent-models`;
    let values = [];
    try { values = JSON.parse(this.safeStorageGet(key) || '[]'); } catch { /* no-op */ }
    values = [modelId, ...values.filter(item => item !== modelId)].slice(0, 8);
    this.safeStorageSet(key, JSON.stringify(values));
  }

  toggleTheme() {
    this.ui.theme = this.ui.theme === 'dark' ? 'light' : 'dark';
    this.setAttribute('theme', this.ui.theme);
    this.persistUiState();
    this.closeTransientUi();
  }

  togglePlacement() {
    this.ui.placement = this.ui.placement === 'right' ? 'left' : 'right';
    this.setAttribute('placement', this.ui.placement);
    this.persistUiState();
    this.closeTransientUi();
  }

  async send({ content, threadId, regenerateFromMessageId = null, retryOfMessageId = null, branchFromMessageId = null } = {}) {
    const input = String(content ?? this.els.composer.value).trim();
    if (!input || !this.online || !this.adapter?.sendMessage) return;
    let targetThreadId = threadId || this.activeThreadId;
    const lockKey = targetThreadId || '__new__';
    if (this.sendingLocks.has(lockKey)) return;
    this.sendingLocks.add(lockKey);
    this.renderComposer();

    try {
      if (!targetThreadId) {
        const thread = await this.createThread({ title: this.deriveThreadTitle(input) });
        if (!thread) return;
        targetThreadId = thread.id;
      }
      const scopeId = this.scope.id;
      const thread = this.threads.find(item => item.id === targetThreadId);
      const messages = this.messagesByThread.get(`${scopeId}:${targetThreadId}`) || [];
      const maxSequence = messages.reduce((max, message) => Math.max(max, message.sequence || 0), 0);
      const clientId = createId('client');
      const userMessage = {
        id: createId('user-local'), clientId, threadId: targetThreadId, role: 'user', content: input,
        sequence: maxSequence + 1, status: 'sending', modelId: thread?.modelId || 'auto', createdAt: new Date().toISOString(),
        metadata: { local: true, retryOfMessageId, branchFromMessageId }
      };
      const assistantMessage = {
        id: createId('assistant-local'), threadId: targetThreadId, role: 'assistant', content: '',
        sequence: maxSequence + 2, status: 'streaming', modelId: thread?.modelId || 'auto', createdAt: new Date().toISOString(),
        parentMessageId: userMessage.id, metadata: { local: true }
      };
      this.messagesByThread.set(`${scopeId}:${targetThreadId}`, [...messages, userMessage, assistantMessage]);
      this.updateThreadLocal(targetThreadId, { updatedAt: new Date().toISOString(), streaming: true, unreadCount: targetThreadId === this.activeThreadId ? 0 : (thread?.unreadCount || 0) });
      if (targetThreadId === this.activeThreadId) {
        this.persistDraft(targetThreadId, input);
        this.setComposerValue('');
        this.renderConversation();
        queueMicrotask(() => this.scrollToBottom(false));
      }

      const controller = new AbortController();
      const localRequestId = createId('request-local');
      const streamKey = `${scopeId}:${targetThreadId}:${localRequestId}`;
      const record = {
        key: streamKey, scopeId, threadId: targetThreadId, requestId: localRequestId,
        assistantMessageId: assistantMessage.id, userMessageId: userMessage.id, input, controller,
        started: false, completed: false, stopped: false, regenerateFromMessageId, createdAt: Date.now()
      };
      this.streams.set(streamKey, record);
      this.renderAll();
      this.dispatchWidgetEvent('writer-chat:message-send', { scopeId, threadId: targetThreadId, clientId, modelId: thread?.modelId || 'auto' });
      this.dispatchWidgetEvent('writer-chat:stream-start', { scopeId, threadId: targetThreadId, requestId: localRequestId });

      const streamInput = {
        scope: { ...this.scope }, scopeId, threadId: targetThreadId, content: input, clientId,
        modelId: thread?.modelId || 'auto', settings: { ...DEFAULT_SETTINGS, ...(thread?.settings || {}) },
        attachments: this.attachmentsByThread.get(`${scopeId}:${targetThreadId}`) || [],
        regenerateFromMessageId, retryOfMessageId, branchFromMessageId
      };
      const iterable = regenerateFromMessageId && this.adapter.regenerateMessage
        ? this.adapter.regenerateMessage({ ...streamInput, messageId: regenerateFromMessageId }, { signal: controller.signal })
        : this.adapter.sendMessage(streamInput, { signal: controller.signal });
      this.consumeStream(record, iterable);
    } catch (error) {
      this.handleGlobalError(error);
      this.persistDraft(targetThreadId, input);
      if (targetThreadId === this.activeThreadId) this.setComposerValue(input);
    } finally {
      this.sendingLocks.delete(lockKey);
      this.sendingLocks.delete(targetThreadId);
      this.renderComposer();
    }
  }

  async consumeStream(record, iterable) {
    try {
      for await (const event of iterable) {
        if (record.completed) continue;
        if (!this.streams.has(record.key) && ![...this.streams.values()].includes(record)) break;
        await this.handleStreamEvent(record, event);
      }
      if (!record.completed && !record.controller.signal.aborted) {
        await this.finalizeImplicitStream(record);
      }
    } catch (error) {
      if (record.controller.signal.aborted || error?.name === 'AbortError') {
        this.markStreamStopped(record);
      } else {
        this.markStreamFailed(record, normalizeError(error));
        if (!record.started && record.scopeId === this.scope.id && record.threadId === this.activeThreadId && !this.els.composer.value) {
          this.setComposerValue(record.input);
          this.persistDraft(record.threadId, record.input);
        }
      }
    } finally {
      this.finishStreamRecord(record);
    }
  }

  async handleStreamEvent(record, event = {}) {
    if (event.requestId && record.started && event.requestId !== record.requestId) return;
    if (event.type === 'start') {
      record.started = true;
      if (event.requestId) record.requestId = event.requestId;
      if (event.message?.id) {
        const oldId = record.assistantMessageId;
        record.assistantMessageId = event.message.id;
        this.replaceMessage(record.scopeId, record.threadId, oldId, { ...event.message, status: 'streaming', content: event.message.content || '' });
      }
      this.updateMessage(record.scopeId, record.threadId, record.userMessageId, { status: 'complete', metadata: { local: false } });
      if (record.scopeId === this.scope.id && record.threadId === this.activeThreadId && !this.els.composer.value) this.persistDraft(record.threadId, '');
      this.threadRequestIds.set(`${record.scopeId}:${record.threadId}:${record.assistantMessageId}`, record.requestId);
      return;
    }
    const ownershipKey = `${record.scopeId}:${record.threadId}:${event.messageId || record.assistantMessageId}`;
    const authoritative = this.threadRequestIds.get(ownershipKey);
    if (authoritative && event.requestId && authoritative !== event.requestId) return;

    if (event.type === 'delta') {
      if (event.messageId && event.messageId !== record.assistantMessageId) {
        const existing = this.findMessageIn(record.scopeId, record.threadId, event.messageId);
        if (!existing) return;
        record.assistantMessageId = event.messageId;
      }
      this.queueDelta(record, event.text || '');
    } else if (event.type === 'usage') {
      this.updateMessage(record.scopeId, record.threadId, record.assistantMessageId, { usage: event.usage });
    } else if (event.type === 'complete') {
      this.flushDeltas(record);
      const message = event.message || {};
      const current = this.findMessageIn(record.scopeId, record.threadId, record.assistantMessageId);
      const complete = { ...current, ...message, id: message.id || record.assistantMessageId, status: 'complete', metadata: { ...(current?.metadata || {}), ...(message.metadata || {}), local: false } };
      this.replaceMessage(record.scopeId, record.threadId, record.assistantMessageId, complete);
      record.assistantMessageId = complete.id;
      record.completed = true;
      this.announceCompletion(record);
      this.dispatchWidgetEvent('writer-chat:stream-complete', { scopeId: record.scopeId, threadId: record.threadId, requestId: record.requestId, messageId: complete.id });
    } else if (event.type === 'stopped') {
      this.flushDeltas(record);
      if (event.message) this.replaceMessage(record.scopeId, record.threadId, record.assistantMessageId, { ...event.message, status: 'stopped' });
      else this.updateMessage(record.scopeId, record.threadId, record.assistantMessageId, { status: 'stopped' });
      record.completed = true;
      record.stopped = true;
      this.dispatchWidgetEvent('writer-chat:stream-stop', { scopeId: record.scopeId, threadId: record.threadId, requestId: record.requestId });
    } else if (event.type === 'error') {
      this.flushDeltas(record);
      if (event.partialMessage) this.replaceMessage(record.scopeId, record.threadId, record.assistantMessageId, { ...event.partialMessage, status: 'failed', error: event.error });
      else this.updateMessage(record.scopeId, record.threadId, record.assistantMessageId, { status: 'failed', error: normalizeError(event.error) });
      record.completed = true;
      this.dispatchWidgetEvent('writer-chat:error', { scopeId: record.scopeId, threadId: record.threadId, requestId: record.requestId, error: normalizeError(event.error) });
    }
  }

  queueDelta(record, text) {
    if (!text) return;
    const key = `${record.scopeId}:${record.threadId}:${record.assistantMessageId}`;
    this.deltaQueues.set(key, (this.deltaQueues.get(key) || '') + text);
    if (!this.deltaFrame) {
      this.deltaFrame = requestAnimationFrame(() => {
        this.deltaFrame = null;
        for (const stream of this.streams.values()) this.flushDeltas(stream);
      });
    }
  }

  flushDeltas(record) {
    const key = `${record.scopeId}:${record.threadId}:${record.assistantMessageId}`;
    const delta = this.deltaQueues.get(key);
    if (!delta) return;
    this.deltaQueues.delete(key);
    const message = this.findMessageIn(record.scopeId, record.threadId, record.assistantMessageId);
    if (!message || ['complete', 'stopped', 'failed'].includes(message.status)) return;
    this.updateMessage(record.scopeId, record.threadId, record.assistantMessageId, { content: `${message.content || ''}${delta}`, status: 'streaming' });
  }

  async finalizeImplicitStream(record) {
    this.flushDeltas(record);
    const message = this.findMessageIn(record.scopeId, record.threadId, record.assistantMessageId);
    if (message?.status === 'streaming') {
      this.updateMessage(record.scopeId, record.threadId, record.assistantMessageId, { status: 'complete' });
      record.completed = true;
      this.announceCompletion(record);
    }
  }

  markStreamStopped(record) {
    this.flushDeltas(record);
    this.updateMessage(record.scopeId, record.threadId, record.assistantMessageId, { status: 'stopped' });
    record.completed = true;
    record.stopped = true;
    this.dispatchWidgetEvent('writer-chat:stream-stop', { scopeId: record.scopeId, threadId: record.threadId, requestId: record.requestId });
  }

  markStreamFailed(record, error) {
    this.flushDeltas(record);
    this.updateMessage(record.scopeId, record.threadId, record.assistantMessageId, { status: 'failed', error });
    record.completed = true;
    this.dispatchWidgetEvent('writer-chat:error', { scopeId: record.scopeId, threadId: record.threadId, requestId: record.requestId, error });
  }

  finishStreamRecord(record) {
    for (const [key, value] of this.streams) if (value === record) this.streams.delete(key);
    this.updateThreadLocal(record.threadId, { streaming: false, updatedAt: new Date().toISOString(), unreadCount: record.threadId === this.activeThreadId ? 0 : 1 });
    this.attachmentsByThread.delete(`${record.scopeId}:${record.threadId}`);
    this.renderAll();
    this.dispatchWidgetEvent('writer-chat:unread-change', { scopeId: record.scopeId, threadId: record.threadId, unreadCount: record.threadId === this.activeThreadId ? 0 : 1 });
  }

  stopActiveStream() {
    const stream = [...this.streams.values()].find(item => item.scopeId === this.scope.id && item.threadId === this.activeThreadId);
    if (stream) stream.controller.abort();
  }

  findMessageIn(scopeId, threadId, messageId) {
    return (this.messagesByThread.get(`${scopeId}:${threadId}`) || []).find(message => message.id === messageId);
  }

  findMessage(messageId) { return this.currentMessages().find(message => message.id === messageId); }

  updateMessage(scopeId, threadId, messageId, patch) {
    const key = `${scopeId}:${threadId}`;
    const messages = this.messagesByThread.get(key) || [];
    const index = messages.findIndex(message => message.id === messageId);
    if (index < 0) return;
    const next = messages.slice();
    next[index] = { ...next[index], ...patch, metadata: patch.metadata ? { ...(next[index].metadata || {}), ...patch.metadata } : next[index].metadata };
    this.messagesByThread.set(key, next);
    if (scopeId === this.scope.id && threadId === this.activeThreadId) this.renderConversation();
    this.renderConnection();
  }

  replaceMessage(scopeId, threadId, oldId, message) {
    const key = `${scopeId}:${threadId}`;
    const messages = this.messagesByThread.get(key) || [];
    const index = messages.findIndex(item => item.id === oldId);
    if (index < 0) {
      if (!messages.some(item => item.id === message.id)) this.messagesByThread.set(key, [...messages, message]);
    } else {
      const next = messages.slice();
      const duplicateIndex = next.findIndex((item, i) => i !== index && item.id === message.id);
      if (duplicateIndex >= 0) next.splice(duplicateIndex, 1);
      const adjustedIndex = duplicateIndex >= 0 && duplicateIndex < index ? index - 1 : index;
      next[adjustedIndex] = message;
      this.messagesByThread.set(key, next);
    }
    if (scopeId === this.scope.id && threadId === this.activeThreadId) this.renderConversation();
  }

  announceCompletion(record) {
    if (record.scopeId === this.scope.id && record.threadId === this.activeThreadId) this.els.completionLive.textContent = 'Writer AI response complete.';
    else this.toast(`Response finished in ${this.threads.find(thread => thread.id === record.threadId)?.title || 'another conversation'}.`);
  }

  deriveThreadTitle(text) {
    const compact = text.replace(/\s+/g, ' ').trim();
    return compact.length > 56 ? `${compact.slice(0, 53)}…` : compact || 'New chat';
  }

  async copyMessage(messageId) {
    const message = this.findMessage(messageId);
    if (!message) return;
    await this.copyText(message.content || '');
    this.toast('Message copied.');
  }

  quoteMessage(messageId) {
    const message = this.findMessage(messageId);
    if (!message) return;
    const quote = (message.content || '').split('\n').map(line => `> ${line}`).join('\n');
    const current = this.els.composer.value.trim();
    this.setComposerValue(`${current}${current ? '\n\n' : ''}${quote}\n\n`);
    this.saveActiveDraft();
    this.focusComposer();
  }

  async saveMessage(messageId) {
    const message = this.findMessage(messageId);
    if (!message || !this.adapter?.saveMessageExternally) return;
    try {
      await this.adapter.saveMessageExternally({ scope: { ...this.scope }, scopeId: this.scope.id, threadId: this.activeThreadId, message });
      this.toast('Message saved.');
      this.dispatchWidgetEvent('writer-chat:save-message', { scopeId: this.scope.id, threadId: this.activeThreadId, messageId });
    } catch (error) { this.handleGlobalError(error); }
  }

  async editMessage(messageId) {
    const message = this.findMessage(messageId);
    if (!message || message.role !== 'user') return;
    const content = await this.showDialog({
      title: 'Edit message',
      body: `<label for="edit-message-input">Message</label><textarea id="edit-message-input">${escapeHtml(message.content)}</textarea><p>Editing older history creates a branch so later messages remain intact.</p>`,
      confirmLabel: 'Continue', valueSelector: '#edit-message-input', initialFocus: '#edit-message-input'
    });
    if (!content?.trim() || content.trim() === message.content.trim()) return;
    const messages = this.currentMessages();
    const hasLater = messages.some(item => (item.sequence || 0) > (message.sequence || 0));
    try {
      if (this.adapter?.editMessage) {
        const result = await this.adapter.editMessage({
          scope: { ...this.scope }, scopeId: this.scope.id, threadId: this.activeThreadId,
          messageId, content: content.trim(), mode: hasLater ? 'branch' : 'replace'
        });
        await this.applyEditResult(result, content.trim(), messageId);
      } else if (hasLater && this.capabilities.branching) {
        await this.branchWithContent(messageId, content.trim());
      } else {
        await this.send({ content: content.trim(), retryOfMessageId: messageId });
      }
      this.dispatchWidgetEvent('writer-chat:message-edit', { scopeId: this.scope.id, threadId: this.activeThreadId, messageId, branched: hasLater });
    } catch (error) { this.handleGlobalError(error); }
  }

  async applyEditResult(result, content, sourceMessageId) {
    if (result?.thread) {
      const existing = this.threads.find(item => item.id === result.thread.id);
      if (existing) this.updateThreadLocal(result.thread.id, result.thread);
      else this.threads.unshift(result.thread);
      if (result.messages) this.messagesByThread.set(this.threadKey(result.thread.id), result.messages);
      await this.selectThread(result.thread.id);
      if (content && result.requiresSend !== false) await this.send({ content, threadId: result.thread.id, branchFromMessageId: sourceMessageId });
    } else if (result?.messages) {
      this.setMessages(this.activeThreadId, result.messages);
    } else if (result?.message) {
      this.updateMessage(this.scope.id, this.activeThreadId, sourceMessageId, result.message);
      await this.send({ content, threadId: this.activeThreadId, retryOfMessageId: sourceMessageId });
    } else {
      await this.send({ content, retryOfMessageId: sourceMessageId });
    }
  }

  async resendMessage(messageId) {
    const message = this.findMessage(messageId);
    if (message?.role === 'user') await this.send({ content: message.content, retryOfMessageId: messageId });
  }

  async retryMessage(messageId) {
    const message = this.findMessage(messageId);
    if (!message) return;
    if (message.role === 'assistant') await this.startRegeneration(messageId, { retry: true });
    else await this.resendMessage(messageId);
  }

  async regenerateMessage(messageId) { await this.startRegeneration(messageId); }

  async startRegeneration(messageId, { retry = false } = {}) {
    if (!this.adapter?.regenerateMessage || this.sendingLocks.has(this.activeThreadId)) return;
    const target = this.findMessage(messageId);
    if (!target || target.role !== 'assistant') return;
    const messages = this.currentMessages();
    const precedingUser = [...messages].reverse().find(message => message.role === 'user' && (message.sequence || 0) < (target.sequence || 0));
    if (!precedingUser) return;
    const scopeId = this.scope.id;
    const threadId = this.activeThreadId;
    const groupId = target.variantGroupId || createId('variant');
    const existingVariants = messages.filter(message => message.id === target.id || message.variantGroupId === groupId);
    const variantIndex = existingVariants.length + 1;
    const normalizedMessages = messages.map(message => message.id === target.id ? { ...message, variantGroupId: groupId, variantIndex: message.variantIndex || 1, variantCount: variantIndex } : message.variantGroupId === groupId ? { ...message, variantCount: variantIndex } : message);
    const placeholder = {
      id: createId('assistant-local'), threadId, role: 'assistant', content: '', sequence: (target.sequence || 0) + variantIndex / 1000,
      status: 'streaming', modelId: this.currentThread()?.modelId || target.modelId, createdAt: new Date().toISOString(),
      parentMessageId: precedingUser.id, variantGroupId: groupId, variantIndex, variantCount: variantIndex, metadata: { local: true, retry }
    };
    this.messagesByThread.set(this.threadKey(threadId), [...normalizedMessages, placeholder]);
    this.selectedVariants.set(groupId, variantIndex - 1);
    this.renderConversation();
    const controller = new AbortController();
    const localRequestId = createId('request-local');
    const record = {
      key: `${scopeId}:${threadId}:${localRequestId}`, scopeId, threadId, requestId: localRequestId,
      assistantMessageId: placeholder.id, userMessageId: precedingUser.id, input: precedingUser.content,
      controller, started: false, completed: false, stopped: false, regenerateFromMessageId: messageId, createdAt: Date.now()
    };
    this.streams.set(record.key, record);
    this.updateThreadLocal(threadId, { streaming: true });
    this.dispatchWidgetEvent('writer-chat:stream-start', { scopeId, threadId, requestId: localRequestId, regenerateFromMessageId: messageId });
    try {
      const iterable = this.adapter.regenerateMessage({
        scope: { ...this.scope }, scopeId, threadId, messageId, content: precedingUser.content,
        modelId: this.currentThread()?.modelId || 'auto', settings: { ...DEFAULT_SETTINGS, ...(this.currentThread()?.settings || {}) },
        variantGroupId: groupId, variantIndex, retry
      }, { signal: controller.signal });
      this.consumeStream(record, iterable);
    } catch (error) {
      this.markStreamFailed(record, normalizeError(error));
      this.finishStreamRecord(record);
    }
  }

  async branchFromMessage(messageId) {
    const message = this.findMessage(messageId);
    if (!message) return;
    await this.branchWithContent(messageId, message.role === 'user' ? message.content : null);
  }

  async branchWithContent(messageId, content = null) {
    try {
      if (this.adapter?.editMessage) {
        const result = await this.adapter.editMessage({
          scope: { ...this.scope }, scopeId: this.scope.id, threadId: this.activeThreadId,
          messageId, content, mode: 'branch'
        });
        if (result?.thread) {
          this.threads.unshift(result.thread);
          if (result.messages) this.messagesByThread.set(this.threadKey(result.thread.id), result.messages);
          await this.selectThread(result.thread.id);
          if (content && !result.messages?.some(item => item.content === content && item.role === 'user')) await this.send({ content, threadId: result.thread.id, branchFromMessageId: messageId });
          return;
        }
      }
      if (this.adapter?.duplicateThread) {
        const thread = await this.adapter.duplicateThread(this.activeThreadId, { branchFromMessageId: messageId });
        this.threads.unshift(thread);
        await this.selectThread(thread.id);
        if (content) await this.send({ content, threadId: thread.id, branchFromMessageId: messageId });
      }
    } catch (error) { this.handleGlobalError(error); }
  }

  changeVariant(groupId, direction) {
    const variants = this.currentMessages().filter(message => message.variantGroupId === groupId).sort((a, b) => (a.variantIndex ?? 1) - (b.variantIndex ?? 1));
    if (!variants.length) return;
    const current = this.selectedVariants.get(groupId) ?? variants.length - 1;
    this.selectedVariants.set(groupId, (current + direction + variants.length) % variants.length);
    this.renderConversation();
  }

  async submitFeedback(messageId, rating) {
    try {
      await this.adapter.submitFeedback({ scopeId: this.scope.id, threadId: this.activeThreadId, messageId, rating });
      this.toast('Feedback recorded.');
      this.dispatchWidgetEvent('writer-chat:feedback', { scopeId: this.scope.id, threadId: this.activeThreadId, messageId, rating });
    } catch (error) { this.handleGlobalError(error); }
  }

  messageMarkdown(message) {
    const role = (message.role || 'notice').toUpperCase();
    const timestamp = message.createdAt ? ` · ${message.createdAt}` : '';
    return `## ${role}${timestamp}\n\n${message.content || ''}\n`;
  }

  conversationMarkdown(threadId = this.activeThreadId) {
    const thread = this.threads.find(item => item.id === threadId);
    const messages = this.messagesByThread.get(this.threadKey(threadId)) || [];
    return `# ${thread?.title || 'Conversation'}\n\n${messages.map(message => this.messageMarkdown(message)).join('\n---\n\n')}`;
  }

  async exportConversation(threadId = this.activeThreadId) {
    if (!threadId) return;
    if (!this.messagesByThread.has(this.threadKey(threadId))) await this.loadMessages(threadId);
    const thread = this.threads.find(item => item.id === threadId);
    this.downloadText(`${this.slugify(thread?.title || 'conversation')}.md`, this.conversationMarkdown(threadId));
  }

  async copyConversation() {
    if (!this.activeThreadId) return;
    await this.copyText(this.conversationMarkdown());
    this.toast('Conversation copied.');
    this.closeTransientUi();
  }

  async saveConversation() {
    if (!this.adapter?.saveConversationExternally || !this.activeThreadId) return;
    const thread = this.currentThread();
    const messages = this.currentMessages();
    try {
      await this.adapter.saveConversationExternally({ scope: { ...this.scope }, scopeId: this.scope.id, thread, messages });
      this.toast('Conversation saved.');
      this.dispatchWidgetEvent('writer-chat:save-conversation', { scopeId: this.scope.id, threadId: this.activeThreadId });
    } catch (error) { this.handleGlobalError(error); }
    this.closeTransientUi();
  }

  downloadText(filename, text) {
    const blob = new Blob([text], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = filename;
    anchor.style.display = 'none';
    document.body.append(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 0);
  }

  slugify(value) {
    return String(value).toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'conversation';
  }

  async copyText(text) {
    if (navigator.clipboard?.writeText) return navigator.clipboard.writeText(text);
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.append(textarea);
    textarea.select();
    document.execCommand('copy');
    textarea.remove();
  }

  async copyCode(button) {
    const code = button.closest('.code-block')?.querySelector('code')?.textContent || '';
    await this.copyText(code);
    const original = button.textContent;
    button.textContent = 'Copied';
    setTimeout(() => { button.textContent = original; }, 1200);
  }

  async handleFiles(files) {
    if (!this.capabilities.attachments || !this.adapter?.uploadAttachment || !files.length) return;
    const key = this.threadKey(this.activeThreadId);
    const current = this.attachmentsByThread.get(key) || [];
    for (const file of files) {
      if (file.size > 25 * 1024 * 1024) {
        await this.showDialog({ title: 'Attachment too large', body: `<strong>${escapeHtml(file.name)}</strong> exceeds the 25 MB demo limit.`, confirmLabel: 'Close', cancelLabel: 'Close' });
        continue;
      }
      const controller = new AbortController();
      try {
        const attachment = await this.adapter.uploadAttachment(file, { signal: controller.signal, onProgress: progress => this.toast(`Uploading ${file.name}: ${Math.round(progress)}%`) });
        current.push(attachment);
        this.attachmentsByThread.set(key, current);
        this.renderAttachments();
      } catch (error) { this.handleGlobalError(error); }
    }
  }

  removeAttachment(index) {
    const key = this.threadKey(this.activeThreadId);
    const list = [...(this.attachmentsByThread.get(key) || [])];
    const [removed] = list.splice(index, 1);
    if (removed?.objectUrl) URL.revokeObjectURL(removed.objectUrl);
    this.attachmentsByThread.set(key, list);
    this.renderAttachments();
  }

  async retryPersistence(messageId) {
    const message = this.findMessage(messageId);
    if (!message || !this.adapter?.saveMessageExternally) return;
    try {
      await this.adapter.saveMessageExternally({ scope: { ...this.scope }, scopeId: this.scope.id, threadId: this.activeThreadId, message, mode: 'retry-persistence' });
      this.updateMessage(this.scope.id, this.activeThreadId, messageId, { metadata: { persistenceFailed: false } });
      this.toast('Response saved.');
    } catch (error) { this.handleGlobalError(error); }
  }

  handleGlobalError(error) {
    const normalized = normalizeError(error);
    const persistentCodes = new Set(['authentication_expired', 'provider_key_not_configured', 'permission_denied']);
    if (persistentCodes.has(normalized.code)) this.configurationBanner = normalized.message;
    this.renderBanner();
    this.toast(normalized.message);
    this.dispatchWidgetEvent('writer-chat:error', { scopeId: this.scope.id, threadId: this.activeThreadId, error: normalized });
  }

  toast(message) {
    if (!this.els?.toastRegion || !message) return;
    const node = document.createElement('div');
    node.className = 'toast';
    node.textContent = message;
    this.els.toastRegion.append(node);
    setTimeout(() => node.remove(), 3200);
  }

  dispatchWidgetEvent(type, detail = {}) {
    this.dispatchEvent(new CustomEvent(type, { detail, bubbles: true, composed: true }));
  }
}

if (!customElements.get('writer-chat-widget')) customElements.define('writer-chat-widget', WriterChatWidget);

export { VERSION, WIDGET_CSS };
