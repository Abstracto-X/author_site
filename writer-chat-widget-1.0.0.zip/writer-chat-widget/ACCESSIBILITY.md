# Accessibility Notes

The component targets WCAG 2.1 AA and includes:

- Keyboard operation for launcher, header controls, thread entries, menus, dialogs, model options, message actions, composer, and resize handle.
- `Enter` to send, `Shift+Enter` for a newline, and `Escape` to close transient UI.
- A modal focus loop only for component dialogs. The normal drawer remains nonmodal and does not trap focus.
- Focus restoration to the launcher after closing and to the prior control after a dialog closes.
- Screen-reader labels for icon-only buttons and status indicators.
- `aria-expanded` on the launcher, thread rail toggle, and popover triggers.
- A polite completion announcement after a response finishes. Stream tokens are not announced individually.
- Visible focus rings, non-colour status text, reduced-motion support, browser zoom support, and 44-pixel mobile touch targets.
- Full-screen mobile behavior with the thread rail presented as an overlay sheet.

Integration testing should verify contrast after host theme overrides and should include VoiceOver/Safari, NVDA/Firefox, and keyboard-only passes in the final Writer shell.
