import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

if (!globalThis.HTMLElement) globalThis.HTMLElement = class HTMLElement {};
if (!globalThis.customElements) {
  const registry = new Map();
  globalThis.customElements = {
    get: name => registry.get(name),
    define: (name, value) => registry.set(name, value)
  };
}
if (!globalThis.requestAnimationFrame) globalThis.requestAnimationFrame = callback => setTimeout(() => callback(Date.now()), 0);
if (!globalThis.cancelAnimationFrame) globalThis.cancelAnimationFrame = clearTimeout;

const module = await import('../src/writer-chat-widget.js');
const { WriterChatWidget, markdownToHtml, safeUrl, escapeHtml, DEFAULT_CAPABILITIES } = module;
const { MockWriterChatAdapter } = await import('../demo/mock-chat-adapter.js');

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

function bareWidget() {
  const widget = Object.create(WriterChatWidget.prototype);
  widget.messagesByThread = new Map();
  widget.scope = { id: 'scope-a' };
  widget.activeThreadId = 'thread-a';
  widget.threadRequestIds = new Map();
  widget.deltaQueues = new Map();
  widget.streams = new Map();
  widget.deltaFrame = null;
  widget.renderConversation = () => {};
  widget.renderConnection = () => {};
  widget.dispatchWidgetEvent = () => {};
  widget.els = { composer: { value: '' }, completionLive: { textContent: '' } };
  return widget;
}

test('HTML is escaped and Markdown remains functional', () => {
  const output = markdownToHtml('# Heading\n\n<script>alert(1)</script>\n\n**bold** and `code`');
  assert.match(output, /<h1>Heading<\/h1>/);
  assert.doesNotMatch(output, /<script>/);
  assert.match(output, /&lt;script&gt;/);
  assert.match(output, /<strong>bold<\/strong>/);
  assert.match(output, /<code>code<\/code>/);
  const highlighted = markdownToHtml("```js\nconst x = 'hi';\n```");
  assert.doesNotMatch(highlighted, /<span <span/);
  assert.match(highlighted, /tok-str/);
});

test('dangerous URLs are rejected and safe URLs survive', () => {
  assert.equal(safeUrl('javascript:alert(1)'), null);
  assert.equal(safeUrl('data:text/html,<h1>x</h1>'), null);
  assert.equal(safeUrl('https://example.com/path'), 'https://example.com/path');
  assert.equal(safeUrl('/relative/path'), '/relative/path');
});

test('escaping covers all HTML-sensitive characters', () => {
  assert.equal(escapeHtml(`<>&"'`), '&lt;&gt;&amp;&quot;&#039;');
});

test('capability defaults expose all required feature gates', () => {
  for (const key of ['streaming', 'stop', 'threadSearch', 'threadRename', 'threadDelete', 'threadArchive', 'threadPin', 'threadDuplicate', 'editMessage', 'regenerate', 'branching', 'responseVariants', 'messageCopy', 'conversationExport', 'scratchpadSave', 'messageFeedback', 'attachments', 'images', 'tools', 'modelCatalog', 'advancedSettings']) {
    assert.equal(typeof DEFAULT_CAPABILITIES[key], 'boolean', `${key} must be boolean`);
  }
});

test('late stream deltas from superseded requests are rejected', async () => {
  const widget = bareWidget();
  const message = { id: 'assistant-1', threadId: 'thread-a', role: 'assistant', content: 'safe', sequence: 1, status: 'streaming', createdAt: new Date().toISOString() };
  widget.messagesByThread.set('scope-a:thread-a', [message]);
  widget.threadRequestIds.set('scope-a:thread-a:assistant-1', 'request-current');
  const record = { scopeId: 'scope-a', threadId: 'thread-a', requestId: 'request-current', assistantMessageId: 'assistant-1', started: true, completed: false };
  await widget.handleStreamEvent(record, { type: 'delta', requestId: 'request-old', messageId: 'assistant-1', text: ' contaminated' });
  assert.equal(widget.findMessageIn('scope-a', 'thread-a', 'assistant-1').content, 'safe');
});

test('matching deltas are batched and accumulated', async () => {
  const widget = bareWidget();
  const message = { id: 'assistant-2', threadId: 'thread-a', role: 'assistant', content: '', sequence: 1, status: 'streaming', createdAt: new Date().toISOString() };
  widget.messagesByThread.set('scope-a:thread-a', [message]);
  widget.threadRequestIds.set('scope-a:thread-a:assistant-2', 'request-current');
  const record = { scopeId: 'scope-a', threadId: 'thread-a', requestId: 'request-current', assistantMessageId: 'assistant-2', started: true, completed: false };
  widget.streams.set('stream', record);
  await widget.handleStreamEvent(record, { type: 'delta', requestId: 'request-current', messageId: 'assistant-2', text: 'Hello ' });
  await widget.handleStreamEvent(record, { type: 'delta', requestId: 'request-current', messageId: 'assistant-2', text: 'world' });
  await sleep(10);
  assert.equal(widget.findMessageIn('scope-a', 'thread-a', 'assistant-2').content, 'Hello world');
});

test('mock adapter scopes, creates, updates, duplicates, and deletes threads', async () => {
  const adapter = new MockWriterChatAdapter();
  adapter.setSimulation({ latency: 1 });
  const created = await adapter.createThread({ scopeId: 'scope-x', title: 'Alpha', modelId: 'auto', settings: {} });
  let listed = await adapter.listThreads({ scopeId: 'scope-x' });
  assert.equal(listed.items.length, 1);
  const updated = await adapter.updateThread(created.id, { pinned: true, title: 'Beta' });
  assert.equal(updated.title, 'Beta');
  assert.equal(updated.pinned, true);
  const duplicate = await adapter.duplicateThread(created.id);
  assert.equal(duplicate.parentThreadId, created.id);
  await adapter.deleteThread(created.id);
  listed = await adapter.listThreads({ scopeId: 'scope-x' });
  assert.equal(listed.items.length, 1);
  assert.equal(listed.items[0].id, duplicate.id);
});

test('mock adapter emits start, deltas, usage, and complete', async () => {
  const adapter = new MockWriterChatAdapter();
  adapter.setSimulation({ latency: 1 });
  const thread = await adapter.createThread({ scopeId: 'scope-x', title: 'Stream', modelId: 'mock/quick-pen', settings: {} });
  const events = [];
  for await (const event of adapter.sendMessage({ scope: { id: 'scope-x', title: 'Scope X' }, scopeId: 'scope-x', threadId: thread.id, content: 'Hello', clientId: 'client-1', modelId: thread.modelId, settings: {}, attachments: [] }, { signal: new AbortController().signal })) events.push(event);
  assert.equal(events[0].type, 'start');
  assert.ok(events.some(event => event.type === 'delta'));
  assert.ok(events.some(event => event.type === 'usage'));
  assert.equal(events.at(-1).type, 'complete');
  assert.match(events.at(-1).message.content, /scopeId/);
});

test('mock adapter abort produces a stopped event with partial content', async () => {
  const adapter = new MockWriterChatAdapter();
  adapter.setSimulation({ latency: 4 });
  const thread = await adapter.createThread({ scopeId: 'scope-x', title: 'Stop', modelId: 'mock/quick-pen', settings: {} });
  const controller = new AbortController();
  const events = [];
  for await (const event of adapter.sendMessage({ scope: { id: 'scope-x', title: 'Scope X' }, scopeId: 'scope-x', threadId: thread.id, content: 'Stop this generated response after a few chunks', clientId: 'client-2', modelId: thread.modelId, settings: {}, attachments: [] }, { signal: controller.signal })) {
    events.push(event);
    if (events.filter(item => item.type === 'delta').length === 2) controller.abort();
  }
  assert.equal(events.at(-1).type, 'stopped');
  assert.ok(events.at(-1).message.content.length > 0);
});

test('source contains no native prompt dialogs or provider globals', async () => {
  const source = await readFile(new URL('../src/writer-chat-widget.js', import.meta.url), 'utf8');
  assert.doesNotMatch(source, /\b(?:prompt|confirm|alert)\s*\(/);
  assert.doesNotMatch(source, /\b(?:supabaseClient|SUPABASE_URL|SUPABASE_ANON_KEY|OpenRouter)\b/);
});
