import http from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8' };
let resolveResults;
const resultsPromise = new Promise(resolve => { resolveResults = resolve; });
const server = http.createServer(async (request, response) => {
  if (request.method === 'POST' && request.url === '/__test-results') {
    let body = '';
    request.setEncoding('utf8');
    request.on('data', chunk => { body += chunk; });
    request.on('end', () => {
      try { resolveResults(JSON.parse(body)); }
      catch (error) { resolveResults({ failures: 1, results: [{ name: 'test result parser', status: 'FAIL', error: error.message }] }); }
      response.writeHead(204);
      response.end();
    });
    return;
  }
  try {
    const pathname = decodeURIComponent(new URL(request.url, `http://${request.headers.host}`).pathname);
    let file = path.join(root, pathname.replace(/^\//, '') || 'tests/browser-tests.html');
    const info = await stat(file);
    if (info.isDirectory()) file = path.join(file, 'index.html');
    response.writeHead(200, { 'content-type': types[path.extname(file)] || 'application/octet-stream', 'cache-control': 'no-store' });
    response.end(await readFile(file));
  } catch {
    response.writeHead(404);
    response.end('Not found');
  }
});

await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const { port } = server.address();
const chromium = process.env.CHROMIUM || '/usr/bin/chromium';
const child = spawn(chromium, [
  '--headless=new', '--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage', '--disable-background-networking',
  '--no-first-run', '--no-default-browser-check', `http://127.0.0.1:${port}/tests/browser-tests.html`
], { stdio: ['ignore', 'ignore', 'pipe'] });
let stderr = '';
child.stderr.on('data', chunk => { stderr += chunk; });

const timeout = new Promise(resolve => setTimeout(() => resolve({ timeout: true, failures: 1, results: [] }), 30000));
const payload = await Promise.race([resultsPromise, timeout]);
child.kill('SIGKILL');
server.close();

if (payload.timeout) {
  console.error('Browser tests timed out.');
  console.error(stderr.slice(-2000));
  process.exit(1);
}
for (const result of payload.results) {
  console.log(`${result.status} ${result.name}`);
  if (result.error) console.log(result.error);
}
if (payload.failures) process.exitCode = 1;
