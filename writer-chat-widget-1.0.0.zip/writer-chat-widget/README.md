# Writer Chat Widget

A framework-independent, floating AI chat Web Component for Writer surfaces and unrelated host pages. The browser bundle has no runtime dependencies, uses Shadow DOM for style isolation, and delegates authentication, persistence, provider calls, model catalogs, attachments, and external save actions to a host-supplied adapter.

## Package contents

```text
writer-chat-widget/
├── dist/
│   ├── writer-chat-widget.js
│   └── writer-chat-widget.css
├── src/
│   └── writer-chat-widget.js
├── types/
│   └── writer-chat-widget.d.ts
├── demo/
│   ├── index.html
│   ├── mock-chat-adapter.js
│   └── server.mjs
├── tests/
├── ADAPTER.md
├── ACCESSIBILITY.md
├── KNOWN_LIMITATIONS.md
├── LICENSE
├── LICENSES.md
└── package.json
```

## Run the demo

```bash
npm run build
npm run demo
```

Open `http://127.0.0.1:4173/demo/`.

The demo includes controls for latency, rate limiting, expired authentication, network timeout, stream interruption, response persistence failure, offline mode, unavailable models, an empty model catalog, scope switching, attachments, Scratchpad callbacks, and background streams.

## Basic embedding

```html
<script type="module" src="/components/writer-chat-widget.js"></script>

<writer-chat-widget
  id="writer-chat"
  placement="right"
  theme="dark">
</writer-chat-widget>

<script type="module">
  const chat = document.querySelector('#writer-chat');

  await chat.configure({
    adapter: writerChatAdapter,
    userId: currentUserId,
    scope: {
      id: activeStoryId,
      type: 'story',
      title: activeStoryTitle,
      surface: 'chapter-editor',
      activeEntityId: activeChapterId
    },
    capabilities: {
      attachments: false,
      branching: true,
      scratchpadSave: true,
      messageFeedback: true
    },
    contextAction: true
  });
</script>
```

Mount the custom element once under `document.body`. Keep it outside route-level containers that the host replaces.

## Public API

```js
chat.open();
chat.close();
chat.toggle();
chat.minimize();
chat.maximize();
chat.restore();
chat.focusComposer();

await chat.setScope({
  id: storyId,
  type: 'story',
  title: storyTitle,
  surface: 'context-workspace',
  activeEntityId: null
});

chat.setDraft('Text placed in the composer', {
  mode: 'replace', // or "append"
  send: false
});

chat.hasPendingWork();
chat.getState();
chat.destroy();
```

`setDraft()` rejects `send: true`. Draft insertion is always editable and never submits automatically.

## Host context integration

The component never reads the editor DOM. The host may respond to an explicit context request:

```js
chat.addEventListener('writer-chat:request-context', () => {
  const selected = getExplicitlySelectedContext();
  if (!selected) return;

  chat.setDraft(`Selected context:\n\n${selected}`, {
    mode: 'append',
    send: false
  });
});
```

## Theming

Set `theme="dark"` or `theme="light"`, then override CSS custom properties on the element:

```css
writer-chat-widget {
  --writer-chat-accent: #7c3aed;
  --writer-chat-accent-hover: #6d28d9;
  --writer-chat-z-index: 1200;
  --writer-chat-launcher-size: 56px;
  --writer-chat-right: 20px;
  --writer-chat-bottom: 20px;
}
```

The complete stylesheet is embedded in the Shadow DOM. `dist/writer-chat-widget.css` is supplied as a readable theme/reference copy and is not required at runtime.

## Persistence behavior

Local storage contains UI preferences, per-scope active thread IDs, per-thread unsent drafts, and recent model selections. Keys are namespaced by widget instance, user, scope, and thread.

Local storage never contains canonical threads, canonical messages, assistant responses, authentication tokens, provider credentials, uploaded attachments, or Scratchpad data.

## Streaming ownership

Each active stream is keyed by scope ID, thread ID, request ID, and assistant message ID. Deltas are queued and applied with `requestAnimationFrame`. Switching threads or scopes does not redirect a stream. Completion updates the originating thread and raises an unread indicator when appropriate.

## Security posture

Message text is escaped before Markdown conversion. Raw HTML is disabled. Links are protocol-checked, and external links receive `target="_blank"` and `rel="noopener noreferrer"`. Code is rendered as text. The component uses no `eval`, native prompt dialogs, provider keys, or direct Supabase/OpenRouter integration.

## Browser support

Current Chrome, Edge, Firefox, and Safari. The component uses custom elements, Shadow DOM, async iterables, `AbortController`, CSS custom properties, and modern JavaScript modules.

## Tests

```bash
npm test
```

`npm test` runs dependency-free Node contract tests for Markdown safety, URL filtering, stream ownership, delta accumulation, adapter CRUD, streaming, abort, and capability defaults.

`npm run test:browser` starts a local HTTP server and executes the full interaction suite in an installed Chromium browser. It covers lifecycle, independent instances, thread selection, drafts, send deduplication, streaming deltas, abort, thread/scope switching during streams, keyboard behavior, focus restoration, mobile rules, missing capabilities, adapter failures, and local-storage exclusions.

## Integration handoff

Implement `WriterChatAdapter` from `ADAPTER.md`, map Writer thread/message records into the exported types, and replace the existing chat mount with one body-level `<writer-chat-widget>`. No changes to chapter editing or Context Workspace internals are required by this package.
