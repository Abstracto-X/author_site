import type { Meta, StoryObj } from '@storybook/react';
import { AetherTheme } from '../components/AetherTheme';
import { Button } from '../components/Button';
import { GlassPanel } from '../components/GlassPanel';

const meta = { title: 'Foundations/Design Tokens' } satisfies Meta;
export default meta;
type Story = StoryObj<typeof meta>;

export const Tokens: Story = {
  render: () => (
    <AetherTheme>
      <div style={{ minHeight: '100vh', background: '#07100c', padding: 32 }}>
        <GlassPanel style={{ maxWidth: 760, margin: '0 auto', padding: 28 }}>
          <div style={{ fontFamily: 'var(--aether-font-display)', fontSize: 32, letterSpacing: '.12em', color: '#fff' }}>AETHER UI</div>
          <p style={{ color: '#aaa', lineHeight: 1.6 }}>A small token layer extracted from the public Aether Archives UI: cinematic black surfaces, translucent panels, thin borders, display serif headings, and a story-level accent color.</p>
          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}><Button>Primary action</Button><Button variant="quiet">Quiet action</Button><Button variant="ghost">Ghost action</Button></div>
        </GlassPanel>
      </div>
    </AetherTheme>
  )
};
