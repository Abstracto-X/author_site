import { useMemo, useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { AetherTheme } from '../components/AetherTheme';
import { AetherTopBar } from '../components/AetherTopBar';
import { CinematicBackground } from '../components/CinematicBackground';
import { CharacterHeader } from '../components/CharacterHeader';
import { GalleryToolbar } from '../components/GalleryToolbar';
import { MasonryGallery } from '../components/MasonryGallery';
import { ArtworkCard } from '../components/ArtworkCard';

const meta = { title: 'Patterns/Character Gallery' } satisfies Meta;
export default meta;
type Story = StoryObj<typeof meta>;

const artworks = [
  { image: '/demo/art-1.svg', caption: 'Quiet watch beneath the archive lights', tags: ['Portrait', 'Casual'] },
  { image: '/demo/art-2.svg', caption: 'A room built from old memories', tags: ['Interior', 'Portrait'] },
  { image: '/demo/art-3.svg', caption: 'Night market study', tags: ['City', 'Casual'] },
  { image: '/demo/art-4.svg', caption: 'Maintenance corridor', tags: ['Sci-Fi', 'Portrait'] },
  { image: '/demo/art-5.svg', caption: 'Field notes from a vanished station', tags: ['Sci-Fi'] },
  { image: '/demo/art-6.svg', caption: 'Dawn after the signal', tags: ['Landscape'] }
];

function GalleryDemo() {
  const [query, setQuery] = useState('');
  const [sort, setSort] = useState('curated');
  const [tag, setTag] = useState('All');
  const [mode, setMode] = useState<'grid' | 'deck'>('grid');
  const visible = useMemo(() => artworks.filter((art) => (tag === 'All' || art.tags.includes(tag)) && `${art.caption} ${art.tags.join(' ')}`.toLowerCase().includes(query.toLowerCase())), [query, tag]);

  return (
    <AetherTheme accent="#c5d8eb">
      <CinematicBackground imageUrl="/demo/background.svg" dim={0.55}>
        <div style={{ minHeight: '100vh', padding: '20px 28px 60px' }}>
          <AetherTopBar backLabel="Roster" actions={[{label:'Customize',icon:'✣'},{label:'Wallpaper',icon:'◒'},{label:'Settings',icon:'⚙'}]} />
          <main style={{ paddingTop: 26, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 28 }}>
            <CharacterHeader portrait="/demo/portrait.svg" name="Mara Venn" role="The Wayfinder" artworkCount={40} biography="Mara Venn is a field cartographer who maps unstable routes through abandoned systems. Her archive gathers portraits, mission studies, and the visual fragments recovered from each expedition." />
            <GalleryToolbar query={query} onQueryChange={setQuery} sort={sort} onSortChange={setSort} viewMode={mode} onViewModeChange={setMode} resultCount={visible.length} tags={['All','Portrait','Casual','City','Sci-Fi','Landscape']} activeTag={tag} onTagChange={setTag} onShuffle={() => setQuery('')} />
            <MasonryGallery columns={3}>{visible.map((art, index) => <ArtworkCard key={art.image} image={art.image} caption={art.caption} label={art.tags[0]} score={index - 1} onOpen={() => {}} onVote={() => {}} onComment={() => {}} />)}</MasonryGallery>
          </main>
        </div>
      </CinematicBackground>
    </AetherTheme>
  );
}

export const Default: Story = { render: () => <GalleryDemo /> };
