import type { Meta, StoryObj } from '@storybook/react';
import { AetherTheme } from '../components/AetherTheme';
import { ArchiveFeature } from '../components/ArchiveFeature';

const meta = { title: 'Patterns/Archive Feature', component: ArchiveFeature } satisfies Meta<typeof ArchiveFeature>;
export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  render: () => <AetherTheme accent="#d4b66f"><div style={{minHeight:'100vh',background:'#07100c',padding:40}}><div style={{maxWidth:980,margin:'0 auto'}}><ArchiveFeature portrait="/demo/portrait.svg" name="Mara Venn" role="Archive subject" biography="A featured archive panel for the gallery landing page. Data stays outside the presentation layer, so a story, character, or collection can drive the same visual shell." artworkCount={40} collectionCount={8} onOpen={() => {}} /></div></div></AetherTheme>
};
