import type { Meta, StoryObj } from '@storybook/react';
import { AetherTheme } from '../components/AetherTheme';
import { AetherTopBar } from '../components/AetherTopBar';
import { CinematicBackground } from '../components/CinematicBackground';
import { StoryHero } from '../components/StoryHero';
import { WorldHubBar } from '../components/WorldHubBar';

const meta = { title: 'Patterns/Story Hub' } satisfies Meta;
export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  render: () => (
    <AetherTheme accent="#b8d0e8">
      <CinematicBackground imageUrl="/demo/background.svg" blur={1.5} dim={0.52}>
        <div style={{ minHeight: '100vh', padding: '20px 28px', display: 'flex', flexDirection: 'column', gap: 24 }}>
          <AetherTopBar backLabel="Archives" actions={[{label:'Customize',icon:'✣'},{label:'Wallpaper',icon:'◒'},{label:'Audio',icon:'◁'},{label:'Settings',icon:'⚙'}]} />
          <main style={{ flex: 1, display: 'grid', placeItems: 'center', padding: 24 }}>
            <div className="aether-story-stack">
              <StoryHero cover="/demo/cover.svg" title="The Cartographer's Wake" status="Ongoing" genre="Sci-Fi" description="A wandering archivist wakes beneath a ruined observatory with a map that redraws itself every night. Each route leads deeper into a forgotten network of worlds and a mystery buried inside the archive itself." actions={[{label:'Read'},{label:'Gallery'}]} />
              <WorldHubBar actions={[{label:'Timelines',icon:'☷'},{label:'Maps',icon:'⌖'},{label:'Lore',icon:'▣'}]} />
            </div>
          </main>
        </div>
      </CinematicBackground>
    </AetherTheme>
  )
};
