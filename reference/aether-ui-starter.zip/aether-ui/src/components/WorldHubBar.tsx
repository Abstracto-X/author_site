import type { ReactNode } from 'react';
import { Button } from './Button';
import { GlassPanel } from './GlassPanel';

export interface WorldHubAction {
  label: string;
  icon?: ReactNode;
  onClick?: () => void;
  href?: string;
}

export interface WorldHubBarProps {
  title?: string;
  actions: WorldHubAction[];
}

export function WorldHubBar({ title = 'A Galaxy Far Far Away', actions }: WorldHubBarProps) {
  return (
    <GlassPanel className="aether-worldbar">
      <div className="aether-worldbar__title">{title}</div>
      <div className="aether-worldbar__actions">
        {actions.map((action) => action.href
          ? <Button key={action.label} href={action.href} variant="quiet" size="sm" icon={action.icon}>{action.label}</Button>
          : <Button key={action.label} variant="quiet" size="sm" icon={action.icon} onClick={action.onClick}>{action.label}</Button>)}
      </div>
    </GlassPanel>
  );
}
