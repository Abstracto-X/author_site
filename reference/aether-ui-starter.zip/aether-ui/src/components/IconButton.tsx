import type { ButtonHTMLAttributes, ReactNode } from 'react';
import { cx } from './utils';

export interface IconButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  label: string;
  icon: ReactNode;
}

export function IconButton({ label, icon, className, ...props }: IconButtonProps) {
  return <button type="button" className={cx('aether-icon-button', className)} aria-label={label} title={label} {...props}>{icon}</button>;
}
