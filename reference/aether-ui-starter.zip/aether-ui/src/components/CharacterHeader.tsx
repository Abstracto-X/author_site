import { GlassPanel } from './GlassPanel';

export interface CharacterHeaderProps {
  portrait: string;
  portraitAlt?: string;
  name: string;
  role?: string;
  biography?: string;
  artworkCount?: number;
}

export function CharacterHeader({ portrait, portraitAlt = '', name, role, biography, artworkCount }: CharacterHeaderProps) {
  return (
    <GlassPanel className="aether-character">
      <div className="aether-character__portrait-wrap"><img className="aether-character__portrait" src={portrait} alt={portraitAlt || `${name} portrait`} /></div>
      <div>
        {typeof artworkCount === 'number' && <div className="aether-character__count">{artworkCount} published artworks</div>}
        <div className="aether-character__name">{name}</div>
        {role && <div className="aether-character__role">{role}</div>}
        {biography && <div className="aether-character__bio">{biography}</div>}
      </div>
    </GlassPanel>
  );
}
