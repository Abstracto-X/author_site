import type { ReactNode } from 'react';
import { GlassPanel } from './GlassPanel';
import { IconButton } from './IconButton';

export interface TopBarAction {
  label: string;
  icon: ReactNode;
  onClick?: () => void;
}

export interface AetherTopBarProps {
  logo?: string;
  backLabel?: string;
  onBack?: () => void;
  actions?: TopBarAction[];
  className?: string;
}

export function AetherTopBar({ logo = 'AETHER', backLabel = 'Archives', onBack, actions = [], className }: AetherTopBarProps) {
  return (
    <GlassPanel className={['aether-topbar', className].filter(Boolean).join(' ')}>
      <button type="button" className="aether-topbar__back" onClick={onBack}><span aria-hidden="true">←</span><span>{backLabel}</span></button>
      <div className="aether-topbar__logo">{logo}</div>
      <div className="aether-topbar__actions">
        {actions.map((action) => <IconButton key={action.label} label={action.label} icon={action.icon} onClick={action.onClick} />)}
      </div>
    </GlassPanel>
  );
}
