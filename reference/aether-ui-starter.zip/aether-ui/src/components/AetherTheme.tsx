import type { CSSProperties, HTMLAttributes, PropsWithChildren } from 'react';
import { cx } from './utils';

export interface AetherThemeProps extends HTMLAttributes<HTMLDivElement> {
  accent?: string;
  glassBackground?: string;
  background?: string;
}

type AetherVars = CSSProperties & {
  '--aether-accent'?: string;
  '--aether-surface'?: string;
  '--aether-bg'?: string;
};

export function AetherTheme({ accent, glassBackground, background, className, style, children, ...props }: PropsWithChildren<AetherThemeProps>) {
  const vars: AetherVars = {
    ...(accent ? { '--aether-accent': accent } : {}),
    ...(glassBackground ? { '--aether-surface': glassBackground } : {}),
    ...(background ? { '--aether-bg': background } : {}),
    ...style
  };

  return <div className={cx('aether-theme', className)} style={vars} {...props}>{children}</div>;
}
