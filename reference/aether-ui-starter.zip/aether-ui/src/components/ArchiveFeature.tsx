import { Button } from './Button';

export interface ArchiveFeatureProps {
  portrait: string;
  portraitAlt?: string;
  eyebrow?: string;
  name: string;
  role?: string;
  biography?: string;
  artworkCount?: number;
  collectionCount?: number;
  onOpen?: () => void;
}

export function ArchiveFeature({ portrait, portraitAlt = '', eyebrow = 'Featured character', name, role, biography, artworkCount, collectionCount, onOpen }: ArchiveFeatureProps) {
  return (
    <section className="aether-archive-feature">
      <div className="aether-archive-feature__portrait"><img src={portrait} alt={portraitAlt || `${name} portrait`} /></div>
      <div className="aether-archive-feature__copy">
        <div className="aether-character__count">{eyebrow}</div>
        <h2>{name}</h2>
        {role && <div className="aether-archive-feature__role">{role}</div>}
        {biography && <p>{biography}</p>}
        {(typeof artworkCount === 'number' || typeof collectionCount === 'number') && <div className="aether-archive-feature__facts">
          {typeof artworkCount === 'number' && <span><b>{artworkCount}</b> artworks</span>}
          {typeof collectionCount === 'number' && <span><b>{collectionCount}</b> collections</span>}
        </div>}
        {onOpen && <div><Button type="button" onClick={onOpen} size="sm">Open archive →</Button></div>}
      </div>
    </section>
  );
}
