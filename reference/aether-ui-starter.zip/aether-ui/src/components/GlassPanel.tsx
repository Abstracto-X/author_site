import type { HTMLAttributes, PropsWithChildren } from 'react';
import { cx } from './utils';

export interface GlassPanelProps extends HTMLAttributes<HTMLDivElement> {
  interactive?: boolean;
}

export function GlassPanel({ interactive = false, className, children, ...props }: PropsWithChildren<GlassPanelProps>) {
  return <div className={cx('aether-glass', className)} data-interactive={interactive} {...props}>{children}</div>;
}
