import { Children, type CSSProperties, type PropsWithChildren } from 'react';

type MasonryVars = CSSProperties & { '--aether-columns'?: number };

export interface MasonryGalleryProps {
  columns?: number;
  className?: string;
}

export function MasonryGallery({ columns = 3, className, children }: PropsWithChildren<MasonryGalleryProps>) {
  const style: MasonryVars = { '--aether-columns': columns };
  return <div className={['aether-masonry', className].filter(Boolean).join(' ')} style={style}>{Children.map(children, (child) => <div className="aether-masonry__item">{child}</div>)}</div>;
}
