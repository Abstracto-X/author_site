import type { ChangeEvent } from 'react';
import { Button } from './Button';
import { GlassPanel } from './GlassPanel';

export interface GallerySortOption { value: string; label: string; }

export interface GalleryToolbarProps {
  query: string;
  onQueryChange: (value: string) => void;
  sort: string;
  onSortChange: (value: string) => void;
  sortOptions?: GallerySortOption[];
  viewMode?: 'grid' | 'deck';
  onViewModeChange?: (mode: 'grid' | 'deck') => void;
  resultCount: number;
  tags?: string[];
  activeTag?: string;
  onTagChange?: (tag: string) => void;
  onShuffle?: () => void;
}

const defaultSort: GallerySortOption[] = [
  { value: 'curated', label: 'Curated' },
  { value: 'newest', label: 'Newest' },
  { value: 'top', label: 'Top Rated' }
];

export function GalleryToolbar({ query, onQueryChange, sort, onSortChange, sortOptions = defaultSort, viewMode = 'grid', onViewModeChange, resultCount, tags = [], activeTag, onTagChange, onShuffle }: GalleryToolbarProps) {
  const changeQuery = (event: ChangeEvent<HTMLInputElement>) => onQueryChange(event.target.value);
  return (
    <>
      <GlassPanel className="aether-gallery-toolbar">
        <label className="aether-gallery-toolbar__search"><span aria-hidden="true">⌕</span><input type="search" value={query} onChange={changeQuery} placeholder="Search captions or tags" aria-label="Search gallery" /></label>
        <label className="aether-gallery-toolbar__sort">Sort<select value={sort} onChange={(event) => onSortChange(event.target.value)} aria-label="Sort gallery">{sortOptions.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}</select></label>
        {onViewModeChange && <Button type="button" variant="quiet" size="sm" onClick={() => onViewModeChange(viewMode === 'grid' ? 'deck' : 'grid')} icon={viewMode === 'grid' ? '▦' : '▤'}>{viewMode === 'grid' ? 'Grid View' : 'Deck View'}</Button>}
        <div className="aether-gallery-toolbar__count">{resultCount} artworks</div>
      </GlassPanel>
      {(tags.length > 0 || onShuffle) && <div className="aether-tag-row">
        {tags.map((tag) => <button key={tag} type="button" className="aether-tag" data-active={tag === activeTag} onClick={() => onTagChange?.(tag)}>{tag}</button>)}
        {onShuffle && <button type="button" className="aether-tag" onClick={onShuffle} aria-label="Shuffle artwork">↝</button>}
      </div>}
    </>
  );
}
