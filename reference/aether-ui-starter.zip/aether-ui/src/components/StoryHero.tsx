import type { ReactNode } from 'react';
import { Button } from './Button';
import { GlassPanel } from './GlassPanel';

export interface StoryHeroAction {
  label: string;
  onClick?: () => void;
  href?: string;
  icon?: ReactNode;
}

export interface StoryHeroProps {
  cover: string;
  coverAlt?: string;
  title: string;
  status?: string;
  genre?: string;
  description: string;
  actions?: StoryHeroAction[];
}

export function StoryHero({ cover, coverAlt = '', title, status, genre, description, actions = [] }: StoryHeroProps) {
  const meta = [status, genre].filter(Boolean).join(' • ');
  return (
    <GlassPanel className="aether-story-hero">
      <img className="aether-story-hero__cover" src={cover} alt={coverAlt || `${title} cover`} />
      <div className="aether-story-hero__details">
        <h1 className="aether-story-hero__title">{title}</h1>
        {meta && <div className="aether-story-hero__meta">{meta}</div>}
        <p className="aether-story-hero__synopsis">{description}</p>
        {actions.length > 0 && <div className="aether-story-hero__actions">{actions.map((action) => (
          action.href
            ? <Button key={action.label} href={action.href} icon={action.icon}>{action.label}</Button>
            : <Button key={action.label} onClick={action.onClick} icon={action.icon}>{action.label}</Button>
        ))}</div>}
      </div>
    </GlassPanel>
  );
}
