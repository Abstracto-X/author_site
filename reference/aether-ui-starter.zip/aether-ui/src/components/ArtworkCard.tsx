export interface ArtworkCardProps {
  image: string;
  alt?: string;
  caption?: string;
  label?: string;
  mature?: boolean;
  score?: number;
  onOpen?: () => void;
  onVote?: (direction: 1 | -1) => void;
  onComment?: () => void;
}

export function ArtworkCard({ image, alt = '', caption, label, mature = false, score = 0, onOpen, onVote, onComment }: ArtworkCardProps) {
  return (
    <article className="aether-artwork">
      <button type="button" className="aether-artwork__image-button" onClick={onOpen} aria-label={caption ? `Open artwork: ${caption}` : 'Open artwork'}>
        <img className="aether-artwork__image" src={image} alt={alt || caption || 'Artwork'} loading="lazy" />
      </button>
      {(label || mature) && <div className="aether-artwork__topline">{label ? <span className="aether-artwork__badge">{label}</span> : <span />}{mature && <span className="aether-artwork__badge" data-tone="danger">Mature</span>}</div>}
      {caption && <div className="aether-artwork__caption">{caption}</div>}
      {onVote && <div className="aether-artwork__vote" aria-label="Artwork voting"><button type="button" aria-label="Upvote" onClick={() => onVote(1)}>↑</button><span className="aether-artwork__score">{score}</span><button type="button" aria-label="Downvote" onClick={() => onVote(-1)}>↓</button></div>}
      {onComment && <button type="button" className="aether-artwork__comment" aria-label="Open discussion" onClick={onComment}>●</button>}
    </article>
  );
}
