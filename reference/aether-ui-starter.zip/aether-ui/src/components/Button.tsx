import type { ReactNode } from 'react';
import { cx } from './utils';

export type ButtonVariant = 'accent' | 'quiet' | 'ghost';
export type ButtonSize = 'sm' | 'md' | 'lg';

export interface ButtonProps {
  children?: ReactNode;
  variant?: ButtonVariant;
  size?: ButtonSize;
  icon?: ReactNode;
  href?: string;
  target?: string;
  rel?: string;
  type?: 'button' | 'submit' | 'reset';
  disabled?: boolean;
  className?: string;
  onClick?: () => void;
  'aria-label'?: string;
}

export function Button({ variant = 'accent', size = 'md', icon, className, children, href, target, rel, type = 'button', disabled, onClick, 'aria-label': ariaLabel }: ButtonProps) {
  const common = {
    className: cx('aether-button', className),
    'data-variant': variant,
    'data-size': size,
    'aria-label': ariaLabel
  };

  if (href) {
    return <a {...common} href={href} target={target} rel={rel} onClick={onClick}>{icon}{children}</a>;
  }

  return <button {...common} type={type} disabled={disabled} onClick={onClick}>{icon}{children}</button>;
}
