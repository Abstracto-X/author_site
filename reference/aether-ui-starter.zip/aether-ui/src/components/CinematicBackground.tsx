import type { CSSProperties, PropsWithChildren } from 'react';

export interface CinematicBackgroundProps {
  imageUrl?: string;
  position?: string;
  blur?: number;
  dim?: number;
  minHeight?: string | number;
}

type CinematicVars = CSSProperties & {
  '--aether-bg-blur'?: string;
  '--aether-bg-dim'?: number;
};

export function CinematicBackground({ imageUrl, position = 'center', blur = 2, dim = 0.48, minHeight = '100vh', children }: PropsWithChildren<CinematicBackgroundProps>) {
  const vars: CinematicVars = { minHeight, '--aether-bg-blur': `${blur}px`, '--aether-bg-dim': dim };
  return (
    <div className="aether-cinematic" style={vars}>
      <div className="aether-cinematic__image" style={{ backgroundImage: imageUrl ? `url(${imageUrl})` : undefined, backgroundPosition: position }} />
      <div className="aether-cinematic__scrim" />
      <div className="aether-cinematic__vignette" />
      <div className="aether-cinematic__content">{children}</div>
    </div>
  );
}
