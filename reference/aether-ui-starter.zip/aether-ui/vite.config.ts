import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import dts from 'vite-plugin-dts';
import { fileURLToPath } from 'node:url';

const entry = fileURLToPath(new URL('./src/index.ts', import.meta.url));

export default defineConfig({
  plugins: [react(), dts({ insertTypesEntry: true })],
  build: {
    lib: {
      entry,
      name: 'AetherUI',
      formats: ['es', 'umd'],
      fileName: (format) => format === 'es' ? 'aether-ui.js' : 'aether-ui.umd.cjs'
    },
    rollupOptions: {
      external: ['react', 'react-dom', 'react/jsx-runtime'],
      output: {
        globals: {
          react: 'React',
          'react-dom': 'ReactDOM',
          'react/jsx-runtime': 'jsxRuntime'
        },
        assetFileNames: (assetInfo) => assetInfo.name?.endsWith('.css') ? 'aether-ui.css' : '[name][extname]'
      }
    }
  }
});
