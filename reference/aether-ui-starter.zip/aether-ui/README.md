# Aether UI

A reusable React + TypeScript component library extracted from the public visual language of **The Aether Archives / abstracto_tales**.

The goal is to preserve the site's cinematic identity while cutting the dependency on global CSS classes, inline markup strings and application globals. Components are presentation-first and receive data/callbacks from the host app.

## Included

- Design tokens for the original palette, glass surfaces, typography, radii, shadows and motion
- `AetherTheme`
- `GlassPanel`
- `Button` and `IconButton`
- `AetherTopBar`
- `CinematicBackground`
- `StoryHero`
- `WorldHubBar`
- `CharacterHeader`
- `GalleryToolbar`
- `ArtworkCard`
- `MasonryGallery`
- `ArchiveFeature`
- Storybook examples for the story hub, character gallery and archive feature
- `docs/MIGRATION_MAP.md` mapping the original site patterns to the library

## Run it

```bash
npm install
npm run storybook
```

Build the distributable library with:

```bash
npm run build
```

Then consume it in another React app:

```tsx
import { AetherTheme, StoryHero } from 'aether-ui';
import 'aether-ui/styles.css';

export function StoryPage() {
  return (
    <AetherTheme accent="#b8d0e8">
      <StoryHero
        cover="/cover.webp"
        title="My Story"
        status="Ongoing"
        genre="Sci-Fi"
        description="..."
        actions={[{ label: 'Read' }, { label: 'Gallery' }]}
      />
    </AetherTheme>
  );
}
```

## Design notes

The source site uses `Cinzel`, `Lora`, and `Montserrat`. The library declares those font families as tokens but does not redistribute font files. Load them in the host application from your preferred source.

The source site's story-level accent color is represented by `--aether-accent`, so one library can support gold, ice-blue, red, or other story themes without copying component CSS.

Application concerns such as Supabase, routing, authentication, comments, mature-content policy and voting remain outside this package. `ArtworkCard` and `GalleryToolbar` expose callbacks instead.

## Source

Derived from the public repository `Abstracto-X/abstracto_tales`, especially `styles.css`, `index.html`, and `js/render.js`, plus the deployed Aether Archives interface. The repository is published under CC0-1.0. Third-party artwork, fonts, logos, character imagery and other assets may have separate rights, so this starter uses original placeholder SVGs rather than copying gallery assets.
