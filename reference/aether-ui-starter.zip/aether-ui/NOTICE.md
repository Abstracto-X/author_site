# Source notice

This starter was prepared from the public `Abstracto-X/abstracto_tales` repository and visual references from its deployed GitHub Pages site.

The original repository declares CC0-1.0. This package does not include the site's third-party character artwork or copyrighted franchise imagery. Demo images in `public/demo` are simple original SVG placeholders created for component previews.
