# Migration map from `abstracto_tales`

This starter deliberately separates rendering and presentation. The source site currently generates much of its markup inside `js/render.js` and keeps the visual system in a large global `styles.css`. The component library turns those recurring patterns into typed, data-driven React components.

| Source pattern | Library component | Notes |
| --- | --- | --- |
| `.glass-box` | `GlassPanel` | Keeps the translucent surface, border, blur and shadow in one primitive. |
| `.btn-large` | `Button` | Adds variants, sizes, links and focus-visible states. |
| `#main-header` | `AetherTopBar` | Back navigation, centered AETHER wordmark and utility action slots. |
| `.story-hub-layout` | `StoryHero` | Cover, metadata, synopsis and action slots. |
| `.world-hub-bar` | `WorldHubBar` | Reusable secondary story navigation. |
| `.char-profile-hero.gallery-character-masthead` | `CharacterHeader` | Portrait, artwork count, name, role and biography. |
| `.gallery-controls` + `.gallery-tag-row` | `GalleryToolbar` | Controlled search, sort, view mode, tags and shuffle. |
| `.gallery-art-card` | `ArtworkCard` | Presentation-only image card with vote/discussion callbacks. |
| `.sub-gallery-grid` | `MasonryGallery` | Responsive CSS-column masonry shell. |
| `.archive-feature` | `ArchiveFeature` | Featured-character landing pattern. |
| `.background-layer` | `CinematicBackground` | Background image, dimming, blur and vignette without application state. |

## State boundaries

Keep Supabase, router, voting, R18 filtering, comments and authentication outside the library. Components accept values and callbacks, which makes them testable and portable into Storybook, a new React app, or a gradual migration of the existing site.

## Suggested incremental migration

1. Add the library beside the existing app and import `aether-ui/styles.css`.
2. Replace `glass-box` and `btn-large` usages first because they have the widest visual reach.
3. Migrate the story hub to `StoryHero` and `WorldHubBar`.
4. Migrate character gallery masthead, controls and artwork cards.
5. Move interaction state out of global `Actions`/`UI` objects into route-level hooks or adapters.
6. Leave data access in the existing DB/Supabase layer until presentation migration is stable.
